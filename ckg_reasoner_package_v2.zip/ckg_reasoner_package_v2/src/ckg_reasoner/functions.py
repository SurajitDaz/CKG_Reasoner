"""Pluggable mathematical functions used by the CKG reasoning engine.

v0.8.0 deliberately keeps mathematical policy out of ``reasoning.py`` so
research variants can be registered and selected without rewriting the engine.
"""
from __future__ import annotations
from typing import Callable, Iterable
import math
import numpy as np

Function = Callable[..., float]
_REGISTRY: dict[str, dict[str, Function]] = {"activation": {}, "soft_and": {}, "relevancy": {}}


def register_function(category: str, name: str, function: Function, *, overwrite: bool = False) -> None:
    category = str(category).strip().lower(); name = str(name).strip().lower()
    if category not in _REGISTRY:
        raise ValueError(f"Unknown function category {category!r}; choose from {tuple(_REGISTRY)}")
    if not callable(function):
        raise TypeError("function must be callable")
    if name in _REGISTRY[category] and not overwrite:
        raise ValueError(f"Function {name!r} already registered in category {category!r}")
    _REGISTRY[category][name] = function


def get_function(category: str, name: str) -> Function:
    category = str(category).strip().lower(); name = str(name).strip().lower()
    try:
        return _REGISTRY[category][name]
    except KeyError as exc:
        available = sorted(_REGISTRY.get(category, {}))
        raise ValueError(f"Unknown {category!r} function {name!r}. Available: {available}") from exc


def available_functions(category: str | None = None):
    if category is None:
        return {k: tuple(sorted(v)) for k, v in _REGISTRY.items()}
    category = str(category).strip().lower()
    if category not in _REGISTRY:
        raise ValueError(f"Unknown function category {category!r}")
    return tuple(sorted(_REGISTRY[category]))


def legacy_l2_activation(values: Iterable[float], **_) -> float:
    """Archived unnormalised L2 aggregation (may exceed one)."""
    q = np.asarray(list(values), dtype=float)
    return 0.0 if q.size == 0 else float(np.linalg.norm(q))


def normalized_l2_activation(values: Iterable[float], **_) -> float:
    """RMS/normalised-L2 aggregation of bounded component activations.

    For q_c in [0,1], sqrt(sum(q_c^2)/m) is guaranteed to lie in [0,1].
    The norm is computed within one EFN for one patient/candidate only; patients
    are never combined.
    """
    q = np.asarray(list(values), dtype=float)
    if q.size == 0:
        return 0.0
    q = np.clip(q, 0.0, 1.0)
    return float(np.linalg.norm(q) / math.sqrt(q.size))


def patient_activation_relevancy(*, patient_activation: float, **_) -> float:
    """Default feature relevancy used by the v0.8 soft-AND rule.

    The corrected bounded candidate-conditioned patient activation is used as
    the feature-level relevancy score.  This selector is pluggable so a future
    independently defined relevancy function can be registered without changing
    the evidence engine.
    """
    return float(np.clip(patient_activation, 0.0, 1.0))


def legacy_linear_soft_and(*, relevancy: float, importance: float,
                           diagnostic_role: float, **_) -> float:
    """Archived positive knowledge factor max(g,0)*I."""
    return max(float(diagnostic_role), 0.0) * float(importance)


def relevancy_threshold_soft_and(*, relevancy: float, importance: float,
                                 diagnostic_role: float, threshold: float = 0.56,
                                 **_) -> float:
    """v0.8.0 relevancy-dependent Soft-AND knowledge factor.

    Let r be relevancy, i clinical importance, and g the non-negative diagnostic
    role used for positive support.  The requested rule is

        r < 0.56 : i * (g * exp(g))
        r >= 0.56: (i * exp(i)) * (g * exp(g))

    The function returns only the knowledge factor. Patient activation,
    reference magnitude and support are multiplied by the reasoning engine.
    Exclusionary/negative diagnostic roles cannot create positive evidence.
    """
    r = float(relevancy); i = max(float(importance), 0.0); g = max(float(diagnostic_role), 0.0)
    g_term = g * math.exp(g)
    if r < float(threshold):
        return float(i * g_term)
    return float((i * math.exp(i)) * g_term)


register_function("activation", "legacy_l2", legacy_l2_activation)
register_function("activation", "normalized_l2", normalized_l2_activation)
register_function("relevancy", "patient_activation", patient_activation_relevancy)
register_function("soft_and", "legacy_linear", legacy_linear_soft_and)
register_function("soft_and", "relevancy_threshold", relevancy_threshold_soft_and)

# ---------------------------------------------------------------------------
# Core mathematical functions used by the reasoning engine
# ---------------------------------------------------------------------------
def information_gate_geometry(values: Iterable[float]):
    """Compute p_ij, cos(theta_ij), rho_ij and bounded IG_ij for one EFN.

    The canonical vector is (1,...,1) on the observed/evaluable component axes.
    p_ij is intentionally an unnormalised geometric magnitude and may exceed 1;
    IG_ij is the bounded quantity used as the evidence gate.
    """
    q=np.asarray(list(values),dtype=float)
    if q.size == 0:
        return 0.0,0.0,0.0,0.0,0
    q=np.clip(q,0.0,1.0); m=int(q.size); p=float(np.linalg.norm(q)); e=math.sqrt(m)
    cos=0.0 if p == 0.0 else float(q.sum()/(p*e)); rho=float(p/e)
    ig=float(math.sqrt((cos*cos+rho*rho)/2.0))
    return p,float(np.clip(cos,0,1)),float(np.clip(rho,0,1)),float(np.clip(ig,0,1)),m


GATE_ALPHA = 0.05
GATE_BETA = 10.0
GATE_GAMMA = 0.85

def evidence_gate(x: float, *, alpha: float = GATE_ALPHA, beta: float = GATE_BETA,
                  gamma: float = GATE_GAMMA) -> float:
    """Parameterized nonlinear evidence gate.

    f(x; alpha, beta, gamma) = 1 / (1 + alpha * exp[-beta * (x - gamma)]).

    The reported experiments use alpha=0.05, beta=10, gamma=0.85. The same
    function is applied to IG for positive support and to 1-IG for the
    complementary mismatch proxy.
    """
    x=float(np.clip(x,0.0,1.0))
    alpha=float(alpha); beta=float(beta); gamma=float(gamma)
    if alpha <= 0.0 or beta <= 0.0:
        raise ValueError("alpha and beta must be positive")
    return float(1.0/(1.0 + alpha*math.exp(-beta*(x-gamma))))

def positive_similarity_gate(x: float) -> float:
    """Backward-compatible alias for the active evidence gate."""
    return evidence_gate(x)


def manuscript_evidence_contributions(*, information_gate: float, diagnostic_role: float,
                                      importance: float, support: float, contradiction: float):
    """Final pcon/ncon equations using the same nonlinear transform on both channels.

    Positive support:
        pcon = f(IG) * max(g, 0) * I * S

    Present contradiction proxy:
        ncon = f(1 - IG) * C

    Important: 1-IG is currently a complementary mismatch proxy, not an
    independently measured contradictory-reference similarity.  Applying f to
    it prevents the raw complement from being penalized on a different scale
    from positive similarity.
    """
    ig=float(np.clip(information_gate,0.0,1.0)); g=float(diagnostic_role)
    gated_ig=evidence_gate(ig)
    gated_mismatch=evidence_gate(1.0-ig)
    pcon=gated_ig*max(g,0.0)*float(importance)*max(float(support),0.0)
    ncon=gated_mismatch*abs(float(contradiction))
    return float(pcon),float(ncon)



CONTRADICTION_TOTAL_FACTOR = 1.0

def reduce_total_contradiction(total_ncon: float) -> float:
    """Return aggregate contradiction under the active unit scaling.

    Feature-level ncon is f(1-IG)*C and the disease-level negative evidence is
    E- = sum_i(ncon_i). No additional contradiction discount is applied.
    """
    return float(CONTRADICTION_TOTAL_FACTOR * float(total_ncon))


def canonical_net_evidence(feature_parameters: Iterable[tuple[float,float,float,float]]) -> float:
    """Perfect-match disease net-evidence denominator under the active equations.

    Every canonical disease feature is assigned IG=1 and evaluated with the
    exact same contribution equations as a patient:
        pcon_canonical = f(1) * max(g,0) * I * S
        ncon_canonical = f(0) * C
    Hence canonical contradiction is usually very small, but is not forced to
    exactly zero because f(0) is non-zero.
    Tuples are (diagnostic_role, importance, support, contradiction).
    """
    pos=0.0
    raw_neg=0.0
    for g,i,s,c in feature_parameters:
        pcon,ncon=manuscript_evidence_contributions(
            information_gate=1.0, diagnostic_role=g, importance=i,
            support=s, contradiction=c)
        pos += pcon
        raw_neg += ncon
    neg=reduce_total_contradiction(raw_neg)
    return float(pos-neg)


def normalized_evidence_probability(net_evidence: float, canonical_evidence: float) -> float:
    """Direct canonical normalization; intentionally no sigmoid and no clipping."""
    den=float(canonical_evidence)
    if den <= 0.0:
        return 0.0
    return float(net_evidence)/den

def disease_ranking_score(
    evidence_probability: float,
    magnitude_ratio: float,
    cosine_similarity: float,
    canonical_evidence_probability: float,
    canonical_magnitude_ratio: float,
    canonical_cosine_similarity: float,
) -> float:
    """Return the canonical-normalized three-component disease rank.

    The three disease-level components are compared directly by summation; no
    product, square, or square root is used.  Patient support is divided by the
    corresponding total obtained from the canonical disease representation:

        P+_j = max(0, P_evidence(D_j))
        R(D_j) = (P+_j + r_j + c_j)
                 / (P_can_j + r_can_j + c_can_j)

    The canonical components must be generated by the same reasoning/profile
    machinery as the patient components.  A non-positive canonical denominator
    is treated as undefined support and returns 0.
    """
    p=max(0.0,float(evidence_probability))
    r=max(0.0,float(magnitude_ratio))
    c=max(0.0,float(cosine_similarity))
    pc=max(0.0,float(canonical_evidence_probability))
    rc=max(0.0,float(canonical_magnitude_ratio))
    cc=max(0.0,float(canonical_cosine_similarity))
    den=pc+rc+cc
    if den <= 0.0:
        return 0.0
    return float((p+r+c)/den)


def disease_profile_similarity(patient_magnitudes: Iterable[float], canonical_magnitudes: Iterable[float]):
    """Return disease-level (c_j, r_j) from p_j and e_j."""
    p=np.asarray(list(patient_magnitudes),dtype=float); e=np.asarray(list(canonical_magnitudes),dtype=float)
    npv=float(np.linalg.norm(p)); nev=float(np.linalg.norm(e))
    cos=0.0 if npv==0 or nev==0 else float(np.dot(p,e)/(npv*nev))
    ratio=0.0 if max(npv,nev)==0 else min(npv,nev)/max(npv,nev)
    return float(cos),float(ratio)

# ---------------------------------------------------------------------------
# Variable transforms (kept here so mathematical functions are editable
# independently of the reasoning engine).
# ---------------------------------------------------------------------------
def identity_transform(x: float, **_) -> float:
    return float(x)


def f_xe3(x: float, **_) -> float:
    """f(x) = x * exp(3), as specified for v0.9.1."""
    return float(x) * math.exp(3.0)

# A dedicated transform registry allows any registered function to be assigned
# to diagnostic_role, clinical_importance, or future variables via policy YAML.
_REGISTRY.setdefault("transform", {})
register_function("transform", "identity", identity_transform)
register_function("transform", "f_xe3", f_xe3)
