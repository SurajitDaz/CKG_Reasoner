from dataclasses import dataclass

@dataclass(frozen=True)
class ReasoningConfig:
    pathognomonic_threshold: float = 0.8
    exclusionary_threshold: float = 0.8
    negative_threshold: float = 0.20
    positive_threshold: float = 0.80
    missing_aware: bool = True
    # Compatibility metadata only; the core scorer computes
    # q_ijc -> (cos(theta_ij), rho_ij) -> IG_ij directly.
    activation_function: str = "information_gate"
    relevancy_function: str = "information_gate"
    soft_and_function: str = "manuscript_direct"
    relevancy_threshold: float = 0.56
