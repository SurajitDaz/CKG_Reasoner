from __future__ import annotations
from dataclasses import dataclass, asdict
import math

@dataclass(frozen=True)
class CandidateHit:
    key: str
    disease: str
    retrieval_score: float
    matched_features: tuple[str, ...]
    matched_count: int
    observed_count: int
    disease_feature_count: int

    def to_dict(self):
        d=asdict(self); d['matched_features']=list(self.matched_features); return d

class CandidateGraphRetriever:
    """Training-free inverted index for candidate disease-graph retrieval.

    Ranking uses only ontology-feature overlap and inverse disease frequency (IDF).
    Patient outcome labels and Framework-2 diagnostic scores are never used here.
    Retrieval is therefore a computational preselection stage, not a learned diagnosis.
    """
    def __init__(self, kb):
        self.kb=kb; self.feature_to_diseases={}; self.disease_features={}; self.idf={}
        self.rebuild()

    @staticmethod
    def _base_feature(name: str) -> str:
        # mapped component headings such as FEV_temperature_c should retrieve FEV.
        return str(name).split('_',1)[0]

    def rebuild(self):
        self.feature_to_diseases.clear(); self.disease_features.clear()
        for key,vectors in self.kb.reference_vectors.items():
            fs={str(v.get('feature_name', k.split('_',1)[0])) for k,v in vectors.items()}
            self.disease_features[key]=fs
            for f in fs: self.feature_to_diseases.setdefault(f,set()).add(key)
        n=max(1,len(self.disease_features))
        self.idf={f: math.log((n+1)/(len(ds)+1))+1.0 for f,ds in self.feature_to_diseases.items()}
        return self

    def observed_features(self, patient: dict) -> set[str]:
        out=set()
        for k,v in patient.items():
            if v is None: continue
            try:
                if v != v: continue
            except Exception: pass
            out.add(self._base_feature(k))
        return out

    def retrieve(self, patient: dict, top_k: int|None=None, min_score: float=0.0, min_matches: int=1):
        obs=self.observed_features(patient)
        raw={}
        for f in obs:
            for d in self.feature_to_diseases.get(f,()): raw[d]=raw.get(d,0.0)+self.idf.get(f,1.0)
        hits=[]
        denom=sum(self.idf.get(f,1.0) for f in obs) or 1.0
        for d,score in raw.items():
            matched=tuple(sorted(obs & self.disease_features[d]))
            normalized=float(score/denom)
            if len(matched)>=min_matches and normalized>=min_score:
                hits.append(CandidateHit(d,self.kb.disease_names[d],normalized,matched,len(matched),len(obs),len(self.disease_features[d])))
        hits.sort(key=lambda h:(h.retrieval_score,h.matched_count),reverse=True)
        return hits[:int(top_k)] if top_k else hits
