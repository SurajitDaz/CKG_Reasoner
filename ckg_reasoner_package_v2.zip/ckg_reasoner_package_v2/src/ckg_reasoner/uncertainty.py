from __future__ import annotations
from dataclasses import dataclass, asdict
from itertools import product
from typing import Any, Mapping
import numpy as np
from scipy.optimize import shgo
from .functions import (get_function, manuscript_evidence_contributions,
                        canonical_net_evidence, normalized_evidence_probability,
                        reduce_total_contradiction, disease_ranking_score)


@dataclass(frozen=True)
class AdmissibleDomain:
    """Patient-activation admissible domain for one EFN.

    Bounds are expressed on the candidate-conditioned activation p_i. In the bounded
    activation domain, p_i is bounded to [0,1].
    A future raw-value domain adapter can map clinical units/states through the same
    activation machinery before optimization. `source` makes inferred/default domains
    auditable rather than silently treating them as clinical declarations.
    """
    lower: float
    upper: float
    source: str = "declared"
    values: tuple[float, ...] | None = None

    def __post_init__(self):
        lo=float(self.lower); hi=float(self.upper)
        if not (np.isfinite(lo) and np.isfinite(hi) and 0.0 <= lo <= hi):
            raise ValueError("Admissible activation domains must be finite and satisfy 0 <= lower <= upper.")
        if self.values is not None:
            vals=tuple(float(v) for v in self.values)
            if any(v < lo or v > hi for v in vals):
                raise ValueError("Discrete values must lie inside [lower, upper].")
            object.__setattr__(self,"values",vals)

    @property
    def exact(self) -> bool:
        return self.lower == self.upper or (self.values is not None and len(self.values) == 1)

    def to_dict(self):
        return asdict(self)


@dataclass
class SupportInterval:
    disease: str
    lower: float
    upper: float
    width: float
    decision: int | None
    decision_label: str
    method: str
    uncertain_features: list[str]
    domains: dict[str, dict[str, Any]]
    lower_state: dict[str, float]
    upper_state: dict[str, float]
    exact_extrema: bool = True
    certified_outer_bound: bool = True

    def to_dict(self):
        return asdict(self)


def _sigmoid(x: float) -> float:
    return float(1.0/(1.0+np.exp(-np.clip(x,-700,700))))


def score_from_activations(feature_rows: list[dict[str, Any]], activations: Mapping[str,float], config) -> float:
    """Re-evaluate the finalized manuscript score from supplied feature IG states.

    This compatibility helper is exact for the evidence/rule layer. For disease-level
    magnitude similarity, a changed IG is mapped to rho with the feature direction
    held at its traced value. Full missing-component propagation is handled
    conservatively by ``bounded_support`` unless exact component domains are supplied
    by a future raw-component adapter.
    """
    pos=neg=0.0; p=[]; e=[]; patho=False; excl=False; canonical_params=[]
    for r in feature_rows:
        f=r["feature"]; ig=float(np.clip(activations.get(f,r.get("information_gate",r.get("patient_activation",0.0))),0,1))
        ri=float(r.get("diagnostic_role",0.0) or 0.0); ii=float(r.get("clinical_importance",0.0) or 0.0)
        si=max(0.0,float(r.get("support",0.0) or 0.0)); ci=abs(float(r.get("contradiction",0.0) or 0.0))
        em=float(r.get("canonical_magnitude",r.get("reference_magnitude",0.0)) or 0.0)
        old_ig=float(r.get("information_gate",r.get("patient_activation",0.0)) or 0.0)
        old_rho=float(r.get("feature_rho",0.0) or 0.0)
        rho=old_rho if abs(ig-old_ig)<1e-12 else min(1.0,max(0.0,ig))
        # Keep disease-level similarity restricted to Hallmark (0.85) and Major (0.70).
        if ri in (0.85, 0.70):
            p.append(rho*em); e.append(em)
        canonical_params.append((ri,ii,si,ci))
        pcon,ncon=manuscript_evidence_contributions(
            information_gate=ig, diagnostic_role=ri, importance=ii, support=si, contradiction=ci
        )
        pos += pcon; neg += ncon
        patho = patho or (ri == 1.0 and ig >= config.pathognomonic_threshold)
        excl = excl or (ri == -0.5 and ig >= config.exclusionary_threshold)
    neg=reduce_total_contradiction(neg)
    canonical_enet=canonical_net_evidence(canonical_params)
    pe=normalized_evidence_probability(pos-neg,canonical_enet)
    pv=np.asarray(p,float); ev=np.asarray(e,float); npv=float(np.linalg.norm(pv)); nev=float(np.linalg.norm(ev))
    cos=0.0 if npv==0 or nev==0 else float(np.dot(pv,ev)/(npv*nev))
    ratio=0.0 if max(npv,nev)==0 else min(npv,nev)/max(npv,nev)
    pe_can=normalized_evidence_probability(canonical_enet,canonical_enet)
    cos_can=0.0 if nev==0 else 1.0
    ratio_can=0.0 if nev==0 else 1.0
    ranking=disease_ranking_score(
        pe, ratio, cos, pe_can, ratio_can, cos_can
    )
    return 1.0 if patho else 0.0 if excl else ranking

def _decision(lower: float, upper: float, config):
    if lower >= config.positive_threshold:
        return 1,"positive"
    if upper <= config.negative_threshold:
        return 0,"negative"
    return None,"indeterminate"


def _inferred_missing_upper(row: Mapping[str,Any], config) -> float:
    """Infer a feasible upper p_i under the selected activation function."""
    sq=0.0
    for cname,c in (row.get("components",{}) or {}).items():
        if cname == "main":
            continue
        if cname == "default":
            # Legacy default components are AND-gated with the canonical reference state.
            vmax=max(0.0,float(c.get("reference_score",0.0) or 0.0))
        else:
            # Numeric/categorical component scorers are bounded by 1 before L2 aggregation.
            vmax=1.0
        sq += vmax*vmax
    legacy=float(np.sqrt(sq)) if sq > 0 else 1.0
    return 1.0


def build_domains(trace, declared: Mapping[str,Any] | None = None, config=None) -> dict[str,AdmissibleDomain]:
    """Build auditable activation domains.

    Observed evidence is exact. Missing evidence receives either a declared domain or
    a component-derived activation envelope. Declared entries may be:
      scalar -> exact; (lo,hi) -> interval; iterable >2 -> discrete states;
      AdmissibleDomain -> used directly.
    """
    declared=declared or {}
    out={}
    for r in trace.feature_rows:
        f=r["feature"]
        if r.get("observed",False):
            v=float(r.get("patient_activation",0.0))
            dom=AdmissibleDomain(v,v,"observed_exact")
        elif f in declared:
            x=declared[f]
            if isinstance(x,AdmissibleDomain): dom=x
            elif np.isscalar(x): dom=AdmissibleDomain(float(x),float(x),"declared")
            else:
                vals=tuple(float(v) for v in x)
                if len(vals)==2: dom=AdmissibleDomain(min(vals),max(vals),"declared_interval")
                else: dom=AdmissibleDomain(min(vals),max(vals),"declared_discrete",tuple(sorted(set(vals))))
        else:
            dom=AdmissibleDomain(0.0,_inferred_missing_upper(r,config),"inferred_component_activation_envelope")
        out[f]=dom
    return out


def bounded_support(trace, config, declared=None, exact_discrete_limit: int = 14, shgo_samples: int = 96, max_continuous_dimensions: int = 8) -> SupportInterval:
    domains=build_domains(trace,declared,config)
    uncertain=[f for f,d in domains.items() if not d.exact]
    base={r["feature"]:float(r.get("patient_activation",0.0)) for r in trace.feature_rows}
    if not uncertain:
        s=score_from_activations(trace.feature_rows,base,config)
        dec,label=_decision(s,s,config)
        return SupportInterval(trace.disease,s,s,0.0,dec,label,"exact",[],{k:v.to_dict() for k,v in domains.items()},base.copy(),base.copy(),True,True)

    discrete=all(domains[f].values is not None or domains[f].lower==domains[f].upper or {domains[f].lower,domains[f].upper}=={0.0,1.0} for f in uncertain)
    states=[]
    if discrete and len(uncertain) <= exact_discrete_limit:
        grids=[]
        for f in uncertain:
            d=domains[f]; grids.append(d.values if d.values is not None else (d.lower,d.upper))
        for vals in product(*grids):
            state=base.copy(); state.update(dict(zip(uncertain,vals)))
            states.append((score_from_activations(trace.feature_rows,state,config),state))
        method="exact_enumeration"
        lo_s,lo_state=min(states,key=lambda z:z[0]); hi_s,hi_state=max(states,key=lambda z:z[0])
    elif len(uncertain) <= max_continuous_dimensions:
        bounds=[(domains[f].lower,domains[f].upper) for f in uncertain]
        def obj(x):
            state=base.copy(); state.update({f:float(v) for f,v in zip(uncertain,x)})
            return score_from_activations(trace.feature_rows,state,config)
        # SHGO is deterministic for fixed bounds/objective and suitable for bounded global search.
        rmin=shgo(obj,bounds,n=shgo_samples,iters=2,sampling_method="simplicial")
        rmax=shgo(lambda x:-obj(x),bounds,n=shgo_samples,iters=2,sampling_method="simplicial")
        lo_s=float(rmin.fun); hi_s=float(-rmax.fun)
        lo_state=base.copy(); lo_state.update({f:float(v) for f,v in zip(uncertain,rmin.x)})
        hi_state=base.copy(); hi_state.update({f:float(v) for f,v in zip(uncertain,rmax.x)})
        method="deterministic_shgo"
        exact=True
    else:
        # The final score is mathematically bounded to [0,1]. When the admissible
        # configuration space is too large for exact enumeration/global optimization,
        # return this certified outer enclosure rather than mislabel a heuristic result
        # as the min/max defined by the manuscript. Supplying tighter/exact declared
        # domains can reduce dimensionality and enable exact extrema.
        lo_s,hi_s=0.0,1.0
        lo_state={}; hi_state={}
        method="certified_outer_score_range"
        exact=False
    if method == "exact_enumeration": exact=True
    dec,label=_decision(lo_s,hi_s,config)
    return SupportInterval(trace.disease,float(lo_s),float(hi_s),float(hi_s-lo_s),dec,label,method,uncertain,{k:v.to_dict() for k,v in domains.items()},lo_state,hi_state,exact,True)
