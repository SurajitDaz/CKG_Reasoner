"""Mahalanobis partitioning and diagnostics on [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] only."""
from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score
from sklearn.preprocessing import StandardScaler
from .separation import MahalanobisPartition, _score_frame


def diagnose_mahalanobis(score_matrix: pd.DataFrame, target_disease: str, min_clusters=2, max_clusters=10,
                         random_state=42, n_init=20, ridge=1e-6, show=True, variables=None) -> pd.DataFrame:
    """Covariance-aware suitability diagnostics for choosing reference-group count.

    There is no universally accepted 'Mahalanobis elbow'. We therefore report the
    label-free K-means seed diagnostics (inertia/silhouette) plus covariance condition
    number, mean assigned Mahalanobis distance, Davies-Bouldin and Calinski-Harabasz.
    """
    _,valid,cols=_score_frame(score_matrix,target_disease,variables=variables); x=valid[cols].to_numpy(float); z=StandardScaler().fit_transform(x)
    unique_rows=len(np.unique(np.round(z,12),axis=0)); lo=max(2,int(min_clusters)); hi=min(int(max_clusters),unique_rows,len(valid)-1)
    if hi<lo: raise ValueError(f"Mahalanobis diagnostics require at least {lo} candidate group counts.")
    rows=[]
    for k in range(lo,hi+1):
        km=KMeans(n_clusters=k,random_state=random_state,n_init=n_init).fit(z); lab=km.labels_
        cents=np.vstack([x[lab==j].mean(axis=0) for j in range(k)]); resid=np.vstack([x[lab==j]-cents[j] for j in range(k)])
        cov=np.atleast_2d(np.cov(resid,rowvar=False)).astype(float); scale=float(np.trace(cov)/max(cov.shape[0],1)); cov += np.eye(cov.shape[0])*max(ridge,ridge*max(scale,1.0)); inv=np.linalg.pinv(cov)
        dist=np.empty((len(x),k))
        for j in range(k):
            delta=x-cents[j]; dist[:,j]=np.sqrt(np.maximum(0,np.einsum('ij,jk,ik->i',delta,inv,delta)))
        rows.append({"n":k,"k":k,"inertia":float(km.inertia_),"silhouette":float(silhouette_score(z,lab)),"davies_bouldin":float(davies_bouldin_score(z,lab)),"calinski_harabasz":float(calinski_harabasz_score(z,lab)),"covariance_condition":float(np.linalg.cond(cov)),"mean_assigned_mahalanobis":float(dist.min(axis=1).mean())})
    d=pd.DataFrame(rows); rec=int(d.sort_values(["silhouette","k"],ascending=[False,True]).iloc[0].k); d.attrs["recommended_n"]=rec; d.attrs["basis"]=("4-D [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] vectors" if list(cols)==["P_evidence","r","c","Confidence_Score"] else f"selected post-KG variables {list(cols)}"); d.attrs["variables"]=list(cols); d.attrs["note"]="No universal Mahalanobis cluster-count criterion; silhouette is the default recommendation."
    if show:
        fig,ax=plt.subplots(figsize=(8,5)); ax.plot(d.k,d.silhouette,"o-",label="Silhouette"); ax.axvline(rec,ls="--",label=f"Recommendation={rec}"); ax.set(xlabel="Reference groups",ylabel="Silhouette",title="Mahalanobis seed-partition diagnostic"); ax.legend(); ax.grid(alpha=.25); plt.show()
        fig,ax=plt.subplots(figsize=(8,5)); ax.plot(d.k,d.mean_assigned_mahalanobis,"o-"); ax.set(xlabel="Reference groups",ylabel="Mean assigned Mahalanobis distance",title="Mahalanobis compactness diagnostic"); ax.grid(alpha=.25); plt.show()
        fig,ax=plt.subplots(figsize=(8,5)); ax.plot(d.k,d.covariance_condition,"o-"); ax.set(xlabel="Reference groups",ylabel="Covariance condition number",title="Mahalanobis covariance stability diagnostic"); ax.grid(alpha=.25); plt.show()
    return d

__all__=["MahalanobisPartition","diagnose_mahalanobis"]
