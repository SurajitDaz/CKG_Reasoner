"""CKG Reasoner: training-free hybrid clinical knowledge-graph reasoning."""
from .model import CKGModel
from .config import ReasoningConfig
from .functions import register_function, get_function, available_functions
from .uncertainty import AdmissibleDomain, SupportInterval
from .explanation import ExplanationObject
from .reporting import deterministic_report, verify_explanation_object
from .clinical_transformer import ClinicalReportTransformer
from .retrieval import CandidateGraphRetriever, CandidateHit
from .separation import (
    BasePartitionMethod, HardAssignment, KMeansPartition,
    GaussianPartition, MahalanobisPartition,
)
from .kmeans import diagnose_kmeans
from .gaussian import diagnose_gaussian
from .mahalanobis import diagnose_mahalanobis


__all__ = [
    "CKGModel", "ReasoningConfig", "register_function", "get_function", "available_functions", "AdmissibleDomain", "SupportInterval",
    "ExplanationObject", "ClinicalReportTransformer", "deterministic_report", "verify_explanation_object",
    "CandidateGraphRetriever", "CandidateHit", "BasePartitionMethod",
    "HardAssignment", "KMeansPartition", "GaussianPartition", "MahalanobisPartition",
    "diagnose_kmeans", "diagnose_gaussian", "diagnose_mahalanobis",
]
__version__ = "2"
