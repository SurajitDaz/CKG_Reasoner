"""Variable-to-function assignment policy for the CKG reasoner.

The assignment sheet is intentionally separate from reasoning.py. Researchers
can change which registered transform is assigned to a variable without
rewriting the inference engine.
"""
from __future__ import annotations
from importlib.resources import files
import yaml
from .functions import get_function


def load_function_assignments(path: str | None = None) -> dict:
    if path is None:
        p = files("ckg_reasoner").joinpath("data/function_assignments.yaml")
        with p.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def apply_variable_function(variable: str, value: float, policy: dict | None = None) -> tuple[float, str]:
    policy = policy or load_function_assignments()
    spec = (policy.get("variables", {}) or {}).get(variable, {}) or {}
    x = float(value)
    fn_name = str(spec.get("function", "identity"))
    condition = str(spec.get("condition", "always")).lower()
    apply = True
    if condition == "less_than":
        apply = x < float(spec["threshold"])
    elif condition == "less_than_or_equal":
        apply = x <= float(spec["threshold"])
    elif condition == "greater_than":
        apply = x > float(spec["threshold"])
    elif condition == "greater_than_or_equal":
        apply = x >= float(spec["threshold"])
    elif condition != "always":
        raise ValueError(f"Unsupported function-policy condition: {condition!r}")
    selected = fn_name if apply else str(spec.get("else_function", "identity"))
    return float(get_function("transform", selected)(x)), selected
