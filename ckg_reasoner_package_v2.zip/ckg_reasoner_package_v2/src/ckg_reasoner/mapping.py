from __future__ import annotations
import re
from difflib import SequenceMatcher
from .units import normalize_mapped_dataframe
from typing import Any
import numpy as np
import pandas as pd

# Columns that are metadata, outcomes, or identifiers rather than diagnostic evidence.
IGNORE_ALIASES = {
    "id","id_original","patientid","patient_id","age","gender","sex","target","label","outcome",
    "diagnosis","diagnosistype","area","areatype","housetype","district",
    "collectiondate","collection_site","year","month","vaccine12mo_yn","sec2_medic_01_specify",
    "dengue_outcome","flu_final_posneg","result"
}

# Canonical CKG headings -> common raw-column aliases. Composite headings are preferred for
# continuous measurements because the legacy activation code can then compare the raw value
# to the correct profile component in the disease YAML.
COMMON_ALIASES = {
    "FEV": ["fev", "fever", "pyrexia", "sec3_fever"],
    "FEV_temperature_c": ["fev_temperature_c", "fever_temperature", "temperature", "temperature_c", "body_temperature", "temp"],
    "FEV_dura_dy": ["fev_dura_dy", "fever_duration", "fever_duration_days", "duration_of_fever", "duration_fever", "duration_days"],
    "HDH": ["hdh", "headache", "head_ache", "sec3_headache"],
    "ROP": ["rop", "retro_orbital_pain", "retroorbitalpain", "pain_behind_eyes"],
    "MYA": ["mya", "myalgia", "muscle_pain", "body_ache"],
    "ART": ["art", "arthralgia", "joint_pain"],
    "ART_severity": ["art_severity", "arthralgia_severity", "joint_pain_severity"],
    "RSH": ["rsh", "rash", "skin_rash"],
    "MAL": ["mal", "malaise", "sec3_malaise"],
    "NS1": ["ns1", "ns1_antigen", "dengue_ns1"],
    "IGG": ["igg", "igg_antibody", "dengue_igg"],
    "IGM": ["igm", "igm_antibody", "dengue_igm"],
    "MTP_platelet_count": ["mtp_platelet_count", "mtp_platelet_count:", "total_platelet_count", "platelet_count", "platelets", "plt", "mtp"],
    "THR_platelet_count": ["thr_platelet_count", "thrombocytopenia_platelet_count"],
    "LEU_wbc": ["leu_wbc", "wbc", "wbc_count", "total_wbc_count", "white_blood_cell_count", "leukocyte_count", "leu"],
    "HGB_hemoglobin_g_dl": ["hgb", "hemoglobin", "haemoglobin", "hb", "hemoglobin_g_dl", "hemoglobin_hb"],
    "RBC1_rbc": ["rbc", "red_blood_cell_count"],
    "HCT_hematocrit": ["hct", "htc_pcv", "pcv", "hematocrit", "haematocrit"],
    "NEU_neutrophil_count": ["neu", "neutrophil", "neutrophils", "neutrophil_count"],
    "LYM_lymphocyte_count": ["lym", "lymphocyte", "lymphocytes", "lymphocyte_count"],
    "MON_monocyte_count": ["mon", "monocyte", "monocytes", "monocyte_count"],
    "EOS_eosinophil_count": ["eos", "eosinophil", "eosinophils", "eosinophil_count"],
    "MCV_mcv": ["mcv", "mean_corpuscular_volume"],
    "MCH_mch": ["mch", "mean_corpuscular_hemoglobin"],
    "MCHC_mchc": ["mchc", "mean_corpuscular_hemoglobin_concentration"],
    "RDW_rdw": ["rdw", "rdw_cv", "red_cell_distribution_width"],
    "MPV_mpv": ["mpv", "mean_platelet_volume"],
    "PDW_pdw": ["pdw", "platelet_distribution_width"],
    "PCT_pct": ["pct", "plateletcrit"],
    "COU": ["cou", "cough", "sec3_cough"],
    "SOR": ["sor", "sore_throat", "sorethroat", "sec3_sore"],
    "RHI": ["rhi", "rhinitis", "runny_nose", "sec3_runny"],
    "CHL": ["chl", "chills", "sec3_chill"],
    "GBA": ["gba", "generalized_body_aches", "generalized_aches", "sec3_generalized"],
    "DIA": ["dia", "diarrhea", "diarrhoea", "sec3_diarrhea"],
    "PHR": ["phr", "injected_pharynx", "sec3_injected_pharynx"],
    "TYM": ["tym", "injected_tympanic", "injected_tympanic_membrane", "sec3_injected_tympanic"],
    "DYS": ["dys", "dyspnea", "dyspnoea", "breathing_difficulty", "sec3_breathing"],
    "AGT_result": ["agt_result", "rapid_influenza_antigen", "rapid_flu_test", "sec4_ifrapid"],
    "PCR_virus_detected": ["pcr_virus_detected", "realtimepcrforinfluenzaabafrims", "influenza_pcr"],
}

# Exact signatures for the four frozen paper cohorts. They are used only to resolve ambiguous
# headings (not to train or score disease outcomes).
KNOWN_SCHEMAS = {
    "C1_Bangladesh_Dengue_1000": {
        "required": {"ns1","igg","igm","dengueoutcome","mtpplateletcount","leuwbc"},
        "target": "Dengue_Outcome",
        "disease": "Dengue",
    },
    "C2_D4_Dengue_Hematology_1523": {
        "required": {"totalplateletcountcumm","pdw","pct","totalwbccountcumm","result","monocytes"},
        "target": "Result",
        "disease": "Dengue",
    },
    "C3_M1_Malaria_2190": {
        "required": {"totalcireosinophils","htcpcv","plateletcount","totalwbccountcumm","result"},
        "target": "Result",
        "disease": "Malaria",
    },
    "C4_I1_Thailand_Influenza_4569": {
        "required": {"realtimepcrforinfluenzaabafrims","sec3fever","sec3cough","sec4ifrapid","flufinalposneg"},
        "target": "Flu_final_posneg",
        "disease": "Influenza",
    },
}

SCHEMA_OVERRIDES = {
    "C1_Bangladesh_Dengue_1000": {
        "mtpplateletcount": "MTP_platelet_count",
        "leuwbc": "LEU_wbc",
    },
    "C2_D4_Dengue_Hematology_1523": {
        "hemoglobingdl": "HGB_hemoglobin_g_dl",
        "neutrophils": "NEU_neutrophil_count",
        "lymphocytes": "LYM_lymphocyte_count",
        "monocytes": "MON_monocyte_count",
        "eosinophils": "EOS_eosinophil_count",
        "rbc": "RBC1_rbc",
        "hct": "HCT_hematocrit",
        "mcvfl": "MCV_mcv",
        "mchpg": "MCH_mch",
        "mchcgdl": "MCHC_mchc",
        "rdwcv": "RDW_rdw",
        "totalplateletcountcumm": "MTP_platelet_count",
        "mpvfl": "MPV_mpv",
        "pdw": "PDW_pdw",
        "pct": "PCT_pct",
        "totalwbccountcumm": "LEU_wbc",
    },
    "C3_M1_Malaria_2190": {
        "hemoglobinhb": "HGB_hemoglobin_g_dl",
        "totalwbccountcumm": "LEU_wbc",
        "neutrophils": "NEU_neutrophil_count",
        "lymphocytes": "LYM_lymphocyte_count",
        "totalcireosinophils": "EOS_eosinophil_count",
        "htcpcv": "HCT_hematocrit",
        "mchpg": "MCH_mch",
        "mchcgdl": "MCHC_mchc",
        "rdwcv": "RDW_rdw",
        "plateletcount": "THR_platelet_count",
    },
    "C4_I1_Thailand_Influenza_4569": {
        "realtimepcrforinfluenzaabafrims": "PCR_virus_detected",
        "sec3fever": "FEV",
        "sec3cough": "COU",
        "sec3sore": "SOR",
        "sec3breathing": "DYS",
        "sec3headache": "HDH",
        "sec3malaise": "MAL",
        "sec3runny": "RHI",
        "sec3generalized": "GBA",
        "sec3chill": "CHL",
        "sec3diarrhea": "DIA",
        "sec3injectedpharynx": "PHR",
        "sec3injectedtympanic": "TYM",
        "sec4ifrapid": "AGT_result",
    },
}

def norm(s: Any) -> str:
    """Aggressive normalization used only for heading matching."""
    return re.sub(r"[^a-z0-9]+", "", str(s).lower())


def _yes_no(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    s = str(v).strip().lower()
    if s in {"yes","y","1","true","present","positive","pos"}: return 1
    if s in {"no","n","0","false","absent","negative","neg"}: return 0
    if s in {"","na","n/a","nan","none","unknown","not done","invalid result"}: return None
    return v


def _influenza_pcr(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None
    s = str(v).strip().lower()
    if not s or s in {"nan","none","not done","invalid result"}: return None
    if s in {"neg","negative","not detected","not_detected"}: return "Not_Detected"
    # Any laboratory-confirmed influenza A/B subtype is normalized to the ontology state.
    if "flu" in s or "influenza" in s or "h1" in s or "h3" in s or s in {"a","b","pos","positive"}:
        return "Influenza_A_or_B"
    return v


def _rapid_flu(v):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return None

    s = str(v).strip().lower()

    # Missing / unusable test results
    if s in {
        "", "nan", "none", "invalid result",
        "not done", "unknown", "pending"
    }:
        return None

    # Negative rapid influenza test
    if s in {"negative", "neg", "not detected"}:
        return "Negative"

    # Simple positive representations
    if s in {"positive", "pos", "detected"}:
        return "Positive"

    # Normalize formatting so that, for example:
    # "Positive FluA", "Positive FLU A", "Positive FluA+B",
    # and "Positive FLU A+ FLU B" are all recognized.
    compact = re.sub(r"[^a-z0-9]+", "", s)

    if "positive" in compact and (
        "flua" in compact
        or "flub" in compact
        or "influenza" in compact
    ):
        return "Positive"

    return v
    
    

class HeadingMapper:
    def __init__(self, kb, aliases=None):
        self.kb = kb
        self.aliases = {k:list(v) for k,v in COMMON_ALIASES.items()}
        # Extend directly from ontology codes, names and profile component headings.
        for vectors in kb.reference_vectors.values():
            for item in vectors.values():
                code = item["feature_name"]; name = item.get("name", code)
                self.aliases.setdefault(code, []).extend([code, name])
                for comp in (item.get("profile") or {}):
                    canonical = f"{code}_{comp}"
                    self.aliases.setdefault(canonical, []).extend([canonical, f"{name}_{comp}", comp])
        if aliases:
            for k,v in aliases.items():
                self.aliases.setdefault(k, []).extend(v if isinstance(v,list) else [v])
        self.lookup = {}
        for k, vals in self.aliases.items():
            for a in [k, *vals]:
                self.lookup.setdefault(norm(a), k)  # stable first-match behavior
        self.last_schema = None
        self.last_target = None
        self.last_report = None

    def detect_schema(self, df: pd.DataFrame):
        cols = {norm(c) for c in df.columns}
        best = None; best_score = 0.0
        for name, spec in KNOWN_SCHEMAS.items():
            req = spec["required"]
            score = len(req & cols) / max(1, len(req))
            if req.issubset(cols):
                return name, 1.0
            if score > best_score:
                best, best_score = name, score
        return (best, best_score) if best_score >= 0.60 else (None, best_score)

    def _apply_schema_value_fixes(self, df: pd.DataFrame, schema: str | None, original_to_new: dict[str,str]):
        out = df.copy()
        if schema == "C3_M1_Malaria_2190":
            # M1 stores total circulating eosinophils as an absolute count while the supplied
            # ontology profile uses percentage. Convert deterministically when WBC is available.
            eos_raw = next((c for c in original_to_new if norm(c)=="totalcireosinophils"), None)
            wbc_raw = next((c for c in original_to_new if norm(c)=="totalwbccountcumm"), None)
            eos_new = original_to_new.get(eos_raw) if eos_raw else None
            wbc_new = original_to_new.get(wbc_raw) if wbc_raw else None
            if eos_new in out and wbc_new in out:
                eos = pd.to_numeric(out[eos_new], errors="coerce")
                wbc = pd.to_numeric(out[wbc_new], errors="coerce")
                out[eos_new] = np.where(wbc>0, eos/wbc*100.0, np.nan)
        elif schema == "C4_I1_Thailand_Influenza_4569":
            for c in ["FEV","COU","SOR","DYS","HDH","MAL","RHI","GBA","CHL","DIA","PHR","TYM"]:
                if c in out: out[c] = out[c].map(_yes_no)
            if "PCR_virus_detected" in out: out["PCR_virus_detected"] = out["PCR_virus_detected"].map(_influenza_pcr)
            if "AGT_result" in out: out["AGT_result"] = out["AGT_result"].map(_rapid_flu)
        return out

    def map(self, df: pd.DataFrame, interactive=True, fuzzy_threshold=0.88, disease_hint=None, target=None):
        schema, schema_conf = self.detect_schema(df)
        self.last_schema = schema
        if target is None and schema:
            target = KNOWN_SCHEMAS[schema].get("target")
        self.last_target = target

        mapping = {}; unmatched = []; ignored = []; match_type = {}; confidence = {}
        canonical_keys = list(self.aliases)
        alias_norms = list(self.lookup)
        override = SCHEMA_OVERRIDES.get(schema, {})
        ignore_norm = {norm(x) for x in IGNORE_ALIASES}
        target_norm = norm(target) if target else None

        for col in df.columns:
            n = norm(col)
            if target_norm and n == target_norm:
                ignored.append(col); match_type[col]="target"; confidence[col]=1.0; continue
            if n in ignore_norm or any(tok in n for tok in ("outcome","target","label","diagnosis")):
                ignored.append(col); match_type[col]="ignored"; confidence[col]=1.0; continue
            if n in override:
                mapping[col] = override[n]; match_type[col]="schema_exact"; confidence[col]=1.0; continue
            if n in self.lookup:
                mapping[col] = self.lookup[n]; match_type[col]="alias_exact"; confidence[col]=1.0; continue
            best = max(alias_norms, key=lambda a: SequenceMatcher(None,n,a).ratio(), default="")
            score = SequenceMatcher(None,n,best).ratio() if best else 0.0
            if score >= fuzzy_threshold:
                mapping[col] = self.lookup[best]; match_type[col]="fuzzy"; confidence[col]=score
            else:
                unmatched.append(col); match_type[col]="unmatched"; confidence[col]=score

        if interactive and unmatched:
            print("\nUnmatched dataset headings. Enter an ontology heading (e.g. FEV, HDH, FEV_temperature_c) or SKIP.")
            still=[]
            for col in unmatched:
                ans=input(f"  {col!r} -> ").strip()
                if not ans or ans.upper()=="SKIP": still.append(col); continue
                if ans not in canonical_keys:
                    close=max(canonical_keys,key=lambda x:SequenceMatcher(None,norm(ans),norm(x)).ratio())
                    print(f"    Using {close!r} for {ans!r}")
                    ans=close
                mapping[col]=ans; match_type[col]="manual"; confidence[col]=1.0
            unmatched=still

        renamed = df.rename(columns=mapping).copy()
        renamed, unit_audit = normalize_mapped_dataframe(renamed, mapping, schema=schema)
        renamed = self._apply_schema_value_fixes(renamed, schema, mapping)
        unit_by_heading = {r["dataset_heading"]: r for r in unit_audit}
        rows=[]
        for col in df.columns:
            rows.append({
                "dataset_heading": col,
                "ontology_heading": mapping.get(col),
                "status": match_type.get(col,"unmatched"),
                "confidence": float(confidence.get(col,0.0)),
                "source_unit": unit_by_heading.get(col,{}).get("source_unit"),
                "canonical_unit": unit_by_heading.get(col,{}).get("canonical_unit"),
                "unit_status": unit_by_heading.get(col,{}).get("unit_status","not_mapped"),
            })
        self.last_report = pd.DataFrame(rows)
        self.last_schema_confidence = schema_conf
        return renamed, mapping, unmatched, ignored
