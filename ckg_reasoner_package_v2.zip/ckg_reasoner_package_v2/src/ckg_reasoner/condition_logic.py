"""Recursive AND/OR condition evaluation for feature/component activations.

YAML conditions describe admissible evidence combinations; numerical operator
semantics are kept here and can be replaced independently of the knowledge files.
"""
from __future__ import annotations
from typing import Any, Callable
import math

def soft_and(values):
    vals=[max(0.0,min(1.0,float(v))) for v in values]
    if not vals: return 0.0
    return float(math.prod(vals))

def soft_or(values):
    vals=[max(0.0,min(1.0,float(v))) for v in values]
    if not vals: return 0.0
    return float(1.0-math.prod(1.0-v for v in vals))

def evaluate_condition(node: Any, resolver: Callable[[str], float]) -> float:
    """Evaluate a recursive condition tree. Leaves are resolved by name.

    Supported forms: ``"A"``; ``{operator: AND, components: [...]}``; and
    ``{operator: OR, components: [...]}``. Nested dictionaries are recursive.
    """
    if isinstance(node,str): return max(0.0,min(1.0,float(resolver(node))))
    if not isinstance(node,dict): raise ValueError(f"Invalid condition node: {node!r}")
    op=str(node.get("operator","")).upper().strip()
    children=node.get("components")
    if op not in {"AND","OR"}: raise ValueError(f"Unsupported condition operator {op!r}; use AND or OR")
    if not isinstance(children,list) or not children: raise ValueError("condition.components must be a non-empty list")
    vals=[evaluate_condition(c,resolver) for c in children]
    return soft_and(vals) if op=="AND" else soft_or(vals)
