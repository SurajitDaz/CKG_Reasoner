"""Human-readable manual-calculation audit logs for selected CKG records.

This module is deliberately separate from the reasoning engine.  It does not
recalculate decisions for inference; it renders the already stored trace and
shows arithmetic that independently reconstructs the stored disease quantities.
"""
from __future__ import annotations
from pathlib import Path
import math
import numpy as np


def _esc(x):
    s=str(x)
    return (s.replace('\\','\\textbackslash{}').replace('&','\\&').replace('%','\\%')
             .replace('$','\\$').replace('#','\\#').replace('_','\\_')
             .replace('{','\\{').replace('}','\\}'))


def _fmt(x, n=6):
    try:
        if x is None or (isinstance(x,float) and np.isnan(x)): return '--'
        return f"{float(x):.{n}f}"
    except Exception:
        return _esc(x)


def _component_q(row):
    vals=[]
    for name,c in (row.get('components') or {}).items():
        if name=='main' or not bool(c.get('from_patient')): continue
        if name=='default':
            try: actual=float(c.get('patient_value',0.0))
            except (TypeError,ValueError): actual=0.0
            v=float(c.get('reference_score',0.0) or 0.0)*actual
        else:
            v=float(c.get('patient_score',0.0) or 0.0)
        vals.append((name,float(np.clip(v,0.0,1.0)),c.get('patient_value'),c.get('ref_value')))
    return vals


def _record_section(model, rk, disease, actual, predicted, method_name, assignment=None, case_type='Mismatch'):
    tr=model.traces_[rk][disease]
    rid=model.source_df_.loc[rk,'id'] if 'id' in model.source_df_.columns else rk
    lines=[f"\\section{{{_esc(case_type)} record {_esc(rid)}}}",
           f"\\textbf{{Actual result:}} {_esc(actual)}\\\\",
           f"\\textbf{{Predicted result:}} {_esc(predicted)}\\\\",
           f"\\textbf{{Decision method:}} {_esc(method_name)}\\\\",
           f"\\textbf{{Candidate disease audited:}} {_esc(disease)}\\\\"]
    if assignment is not None:
        for k,v in assignment.items():
            lines.append(f"\\textbf{{{_esc(k)}:}} {_esc(v)}\\\\")
    lines += ["\\subsection{Feature-level calculations}",
              "For each observed feature, component activations $q_{ijc}$ are clipped to $[0,1]$. "
              "With $m$ observed/evaluable components, $p_{ij}=\\lVert q_{ij}\\rVert_2$, "
              "$\\cos\\theta_{ij}=\\sum_c q_{ijc}/(p_{ij}\\sqrt{m})$, "
              "$\\rho_{ij}=p_{ij}/\\sqrt{m}$, and "
              "$IG_{ij}=\\sqrt{(\\cos^2\\theta_{ij}+\\rho_{ij}^2)/2}$. "
              r"Positive evidence uses $f(IG;\alpha,\beta,\gamma)=1/[1+\alpha e^{-\beta(IG-\gamma)}], with \alpha=0.05, \beta=10, \gamma=0.85$ and the present contradiction proxy uses the same transform as $f(1-IG)$."]
    for r in tr.feature_rows:
        if not r.get('observed',False): continue
        qs=_component_q(r)
        qtxt=', '.join(f"{_esc(n)}={_fmt(q)}" for n,q,_,_ in qs) or 'stored conditioned activation'
        ig=float(r.get('information_gate',0.0) or 0.0); fg=float(r.get('positive_similarity_gate',0.0) or 0.0)
        g=float(r.get('diagnostic_role',0.0) or 0.0); I=float(r.get('clinical_importance',0.0) or 0.0)
        S=float(r.get('support',0.0) or 0.0); C=float(r.get('contradiction',0.0) or 0.0)
        pcon=float(r.get('positive_contribution',0.0) or 0.0); ncon=float(r.get('negative_contribution',0.0) or 0.0)
        lines += [f"\\paragraph{{{_esc(r.get('feature'))}: {_esc(r.get('name'))}}}",
                  f"Component activations: $q=[{qtxt}]$.\\\\",
                  f"$p_{{ij}}={_fmt(r.get('patient_magnitude'))}$, "
                  f"$\\cos\\theta_{{ij}}={_fmt(r.get('feature_cosine'))}$, "
                  f"$\\rho_{{ij}}={_fmt(r.get('feature_rho'))}$, "
                  f"$IG_{{ij}}={_fmt(ig)}$, $f(IG_{{ij}})={_fmt(fg)}$.\\\\",
                  f"$g={_fmt(g)}$, $I={_fmt(I)}$, $S={_fmt(S)}$, $C={_fmt(C)}$.\\\\",
                  f"$pcon=f(IG)\\max(g,0)IS={_fmt(fg)}\\times{_fmt(max(g,0))}\\times{_fmt(I)}\\times{_fmt(S)}={_fmt(pcon)}$.\\\\",
                  f"$ncon=f(1-IG)C=f(1-{_fmt(ig)})\\times{_fmt(C)}={_fmt(ncon)}$.\\\\"]
    hm=[r for r in tr.feature_rows if r.get('observed',False) and r.get('diagnostic_role') in (0.85,0.70)]
    pvec=[float(r.get('patient_magnitude',0.0) or 0.0) for r in hm]
    evec=[float(r.get('canonical_magnitude',0.0) or 0.0) for r in hm]
    lines += ["\\subsection{Disease-level reconstruction}",
              f"$E^+ = \\sum pcon = {_fmt(tr.positive_evidence)}$, $E^- = \\sum ncon = {_fmt(tr.negative_evidence)}$.\\\\",
              f"$E_{{net}}=E^+-E^-={_fmt(tr.positive_evidence)}-{_fmt(tr.negative_evidence)}={_fmt(tr.net_evidence)}$.\\\\",
              "$E_{net}(D_{canonical})=\\sum_i[f(1)\\max(g_i,0)I_iS_i-f(0)C_i]$ because every canonical $IG_i=1$.\\\\",
              f"$E_{{net}}(D_{{canonical}})={_fmt(tr.canonical_net_evidence)}$.\\\\",
              f"$P_{{evidence}}=E_{{net}}(D_j)/E_{{net}}(D_{{canonical}})={_fmt(tr.net_evidence)}/{_fmt(tr.canonical_net_evidence)}={_fmt(tr.evidence_probability)}$. No sigmoid or clipping is applied.\\\\",
              "Hallmark/Major-only disease-similarity vectors:\\quad " +
              f"$p^{{HM}}=[{', '.join(_fmt(v) for v in pvec)}]$, " +
              f"$e^{{HM}}=[{', '.join(_fmt(v) for v in evec)}]$.\\\\",
              f"$c_j={_fmt(tr.cosine_similarity)}$, $r_j={_fmt(tr.magnitude_ratio)}$.\\\\",
              f"$S_0(D_j)=[P_{{evidence}},r_j,c_j]^T=[{_fmt(tr.evidence_probability)},{_fmt(tr.magnitude_ratio)},{_fmt(tr.cosine_similarity)}]^T$.\\\\",
              f"Ranking score $R(D_j)$ uses the canonical-normalized additive formulation; score={_fmt(tr.pre_rule_score)}.\\\\",
              f"Pathognomonic triggered: {_esc(tr.pathognomonic_triggered)}; exclusionary triggered: {_esc(tr.exclusionary_triggered)}.\\\\",
              f"Final disease score $={_fmt(tr.final_score)}$.\\\\"]
    return '\n'.join(lines)


def _select_cases(out_df, mismatch_limit=10, match_limit=5):
    flags=out_df['Mismatch'].fillna(False).astype(bool)
    mismatches=out_df.index[flags].tolist()[:max(0,int(mismatch_limit))]
    matches=out_df.index[~flags].tolist()[:max(0,int(match_limit))]
    return mismatches,matches


def _assignment_for(method, rk):
    if hasattr(method,'assignments_') and method.assignments_ is not None and rk in method.assignments_.index:
        a=method.assignments_.loc[rk]
        keep=('P_evidence','M','P_Evidence','Similarity_M','Target_Disease_Score',
              'KMeans_Cluster','Gaussian_Cluster','Gaussian_Posterior',
              'Mahalanobis_Cluster','Mahalanobis_Distance','Mahalanobis_Relative_Proximity')
        return {str(k):a[k] for k in a.index if k in keep}
    return None


def build_manual_mismatch_latex(model, out_df, disease, method, path, limit=10, match_limit=5, mismatch_limit=None):
    """Write LaTeX audit for selected mismatched and correctly matched rows.

    ``limit`` is the backward-compatible mismatch limit. If ``mismatch_limit``
    is supplied it takes precedence.
    """
    ml=limit if mismatch_limit is None else mismatch_limit
    mismatch,matched=_select_cases(out_df,ml,match_limit)
    method_name=getattr(method,'name',str(method))
    body=['\\section*{A. Mismatched cases}']
    if mismatch:
        for rk in mismatch:
            body.append(_record_section(model,rk,disease,out_df.loc[rk,'Actual_Result'],out_df.loc[rk,'Predicted_Result'],method_name,_assignment_for(method,rk),'Mismatch'))
    else:
        body.append('No mismatched records were available for audit.')
    body.append('\\section*{B. Correctly matched cases}')
    if matched:
        for rk in matched:
            body.append(_record_section(model,rk,disease,out_df.loc[rk,'Actual_Result'],out_df.loc[rk,'Predicted_Result'],method_name,_assignment_for(method,rk),'Correct match'))
    else:
        body.append('No correctly matched records were available for audit.')
    tex=r'''\documentclass[10pt]{article}
\usepackage[a4paper,margin=18mm]{geometry}
\usepackage{amsmath,amssymb,longtable,array}
\usepackage[T1]{fontenc}
\usepackage{lmodern}
\setlength{\parindent}{0pt}
\setlength{\parskip}{4pt}
\begin{document}
\title{CKG Reasoner Manual Calculation Audit}
\author{Automatically generated from stored deterministic reasoning traces}
\date{}
\maketitle
\textbf{Scope.} This document reconstructs up to %d prediction mismatches and up to %d correctly matched cases in workbook order. It is an audit rendering only; it does not alter inference.\\
\textbf{Clustering note.} Adaptive K-means, GMM and Mahalanobis fitting use the two-dimensional vector $[P_{evidence}(D_j),M_j]$. The product is shown only as a post-fit ordering/audit quantity.
%s
\end{document}
''' % (int(ml),int(match_limit),'\n'.join(body))
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); path.write_text(tex,encoding='utf-8')
    return path


def _pdf_record_story(model,out_df,disease,method,rk,case_type,styles,Paragraph):
    tr=model.traces_[rk][disease]
    rid=model.source_df_.loc[rk,'id'] if 'id' in model.source_df_.columns else rk
    method_name=getattr(method,'name',str(method))
    story=[Paragraph(f'{case_type} record {rid}',styles['Heading1']),
           Paragraph(f"Actual: {out_df.loc[rk,'Actual_Result']} | Predicted: {out_df.loc[rk,'Predicted_Result']} | Method: {method_name} | Disease: {disease}",styles['BodyText'])]
    assignment=_assignment_for(method,rk)
    if assignment:
        story += [Paragraph('Clustering / assignment quantities',styles['Heading2']),
                  Paragraph('; '.join(f'{k}={_fmt(v)}' for k,v in assignment.items()),styles['BodyText'])]
    story += [Paragraph('Feature-level calculations',styles['Heading2']),
              Paragraph('For each observed feature: q is clipped to [0,1]; p_ij=||q||2; cosine and rho form IG; positive evidence uses f(IG), while the present contradiction proxy uses the same transform f(1-IG).',styles['BodyText'])]
    for r in tr.feature_rows:
        if not r.get('observed',False): continue
        qs=_component_q(r)
        qtxt=', '.join(f"{n}={_fmt(q)} (patient={pv}, ref={rv})" for n,q,pv,rv in qs) or 'stored conditioned activation'
        ig=float(r.get('information_gate',0.0) or 0.0); fg=float(r.get('positive_similarity_gate',0.0) or 0.0)
        g=float(r.get('diagnostic_role',0.0) or 0.0); I=float(r.get('clinical_importance',0.0) or 0.0)
        S=float(r.get('support',0.0) or 0.0); C=float(r.get('contradiction',0.0) or 0.0)
        pcon=float(r.get('positive_contribution',0.0) or 0.0); ncon=float(r.get('negative_contribution',0.0) or 0.0)
        story += [Paragraph(f"{r.get('feature')} — {r.get('name')}",styles['Heading3']),
                  Paragraph(f"Components: {qtxt}",styles['BodyText']),
                  Paragraph(f"p_ij = sqrt(sum q_c^2) = {_fmt(r.get('patient_magnitude'))}; cos(theta_ij) = sum(q_c)/(p_ij*sqrt(m)) = {_fmt(r.get('feature_cosine'))}; rho_ij = p_ij/sqrt(m) = {_fmt(r.get('feature_rho'))}",styles['BodyText']),
                  Paragraph(f"IG_ij = sqrt((cos(theta_ij)^2 + rho_ij^2)/2) = {_fmt(ig)}; f(IG_ij; alpha,beta,gamma), using alpha=0.05, beta=10, gamma=0.85, = {_fmt(fg)}",styles['BodyText']),
                  Paragraph(f"g={_fmt(g)}; I={_fmt(I)}; S={_fmt(S)}; C={_fmt(C)}",styles['BodyText']),
                  Paragraph(f"pcon = f(IG)*max(g,0)*I*S = {_fmt(fg)}*{_fmt(max(g,0))}*{_fmt(I)}*{_fmt(S)} = {_fmt(pcon)}",styles['BodyText']),
                  Paragraph(f"ncon = f(1-IG)*C = f(1-{_fmt(ig)})*{_fmt(C)} = {_fmt(ncon)}",styles['BodyText'])]
    hm=[r for r in tr.feature_rows if r.get('observed',False) and r.get('diagnostic_role') in (0.85,0.70)]
    pvec=[float(r.get('patient_magnitude',0.0) or 0.0) for r in hm]
    evec=[float(r.get('canonical_magnitude',0.0) or 0.0) for r in hm]
    story += [Paragraph('Disease-level reconstruction',styles['Heading2']),
              Paragraph(f"E+ = sum(pcon) = {_fmt(tr.positive_evidence)}; E- = sum(ncon) = {_fmt(tr.negative_evidence)}; E_net = {_fmt(tr.net_evidence)}",styles['BodyText']),
              Paragraph("Canonical denominator: E_net(D_canonical) = sum_i [f(1)*max(g_i,0)*I_i*S_i - f(0)*C_i]; all canonical IG_i=1.",styles['BodyText']),
              Paragraph(f"E_net(D_canonical) = {_fmt(tr.canonical_net_evidence)}",styles['BodyText']),
              Paragraph(f"P_evidence = E_net(D_j) / E_net(D_canonical) = {_fmt(tr.net_evidence)} / {_fmt(tr.canonical_net_evidence)} = {_fmt(tr.evidence_probability)}. No sigmoid or clipping.",styles['BodyText']),
              Paragraph(f"Hallmark/Major p vector=[{', '.join(_fmt(v) for v in pvec)}]; e vector=[{', '.join(_fmt(v) for v in evec)}]",styles['BodyText']),
              Paragraph(f"Evidence coordinates [P_evidence,r_j,c_j]=[{_fmt(tr.evidence_probability)},{_fmt(tr.magnitude_ratio)},{_fmt(tr.cosine_similarity)}]",styles['BodyText']),
              Paragraph(f"Ranking score R(D_j)=(max(0,P_evidence)+r_j+c_j)/(P_evidence_can+r_can+c_can)={_fmt(tr.final_score)}",styles['BodyText']),
              Paragraph(f"Pathognomonic={tr.pathognomonic_triggered}; exclusionary={tr.exclusionary_triggered}; final disease score={_fmt(tr.final_score)}",styles['BodyText'])]
    return story


def build_manual_mismatch_pdf(model, out_df, disease, method, path, limit=10, match_limit=5, mismatch_limit=None):
    """Write detailed PDF audit for mismatched and correctly matched cases."""
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet
    except ImportError as exc:
        raise ImportError("PDF audit requires reportlab. Install it with: pip install reportlab, or use manual_log_format='latex'.") from exc
    ml=limit if mismatch_limit is None else mismatch_limit
    mismatch,matched=_select_cases(out_df,ml,match_limit)
    styles=getSampleStyleSheet()
    story=[Paragraph('CKG Reasoner Manual Calculation Audit',styles['Title']),
           Paragraph(f'Scope: up to {int(ml)} mismatches and {int(match_limit)} correctly matched cases. Audit only; inference is unchanged.',styles['BodyText']),
           Paragraph('A. Mismatched cases',styles['Heading1'])]
    if not mismatch: story.append(Paragraph('No mismatched records were available for audit.',styles['BodyText']))
    for rk in mismatch:
        story.extend(_pdf_record_story(model,out_df,disease,method,rk,'Mismatch',styles,Paragraph)); story.append(PageBreak())
    story.append(Paragraph('B. Correctly matched cases',styles['Heading1']))
    if not matched: story.append(Paragraph('No correctly matched records were available for audit.',styles['BodyText']))
    for ix,rk in enumerate(matched):
        story.extend(_pdf_record_story(model,out_df,disease,method,rk,'Correct match',styles,Paragraph))
        if ix<len(matched)-1: story.append(PageBreak())
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    SimpleDocTemplate(str(path),pagesize=A4).build(story)
    return path
