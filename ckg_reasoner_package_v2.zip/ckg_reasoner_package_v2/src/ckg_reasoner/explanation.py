from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any


def _atom(name: str, *args) -> str:
    def fmt(x):
        if isinstance(x,bool): return "true" if x else "false"
        if isinstance(x,(int,float)): return f"{x:.12g}"
        s=str(x).replace("'","\\'")
        return f"'{s}'"
    return f"{name}({', '.join(fmt(a) for a in args)})"


@dataclass
class ExplanationObject:
    patient_id: Any
    disease: str
    evidence_facts: list[dict[str,Any]]
    continuous_facts: dict[str,Any]
    deterministic_facts: dict[str,Any]
    uncertainty_facts: dict[str,Any]
    decision: dict[str,Any]
    provenance: list[dict[str,Any]]
    fol_facts: list[str]

    def to_dict(self): return asdict(self)

    def to_fol(self) -> str:
        return ".\n".join(self.fol_facts) + (".\n" if self.fol_facts else "")


def build_explanation(patient_id, trace, interval=None, config=None, confidence=None) -> ExplanationObject:
    ev=[]; prov=[]; fol=[]
    for r in trace.feature_rows:
        observations=[]
        for cname,cdata in (r.get("components",{}) or {}).items():
            if cdata.get("from_patient") and cdata.get("patient_value") not in (None,""):
                observations.append({"component":cname,"value":cdata.get("patient_value")})
        item={
            "feature":r["feature"],"name":r.get("name"),"observed":bool(r.get("observed")),"observations":observations,
            "similarity":float(r.get("patient_activation",0.0)),
            "clinical_importance":float(r.get("clinical_importance",0.0)),
            "specificity":float(r.get("diagnostic_role",0.0)),
            "support":float(r.get("support",0.0)),"contradiction":float(r.get("contradiction",0.0)),
            "positive_contribution":float(r.get("positive_contribution",0.0)),
            "negative_contribution":float(r.get("negative_contribution",0.0)),
        }
        ev.append(item)
        f=r["feature"]; d=trace.disease
        for obs in observations:
            fol.append(_atom("Observed",patient_id,f+"."+obs["component"],obs["value"]))
        fol += [_atom("EvidenceAvailable",patient_id,f,item["observed"]),_atom("Importance",f,d,item["clinical_importance"]),
                _atom("Specificity",f,d,item["specificity"]),_atom("Similarity",patient_id,f,d,item["similarity"]),
                _atom("Supports",patient_id,f,d,item["support"]),_atom("Contradicts",patient_id,f,d,item["contradiction"])]
        prov.append({"fact_feature":f,"source":"patient-activated EFN","stage":r.get("stage"),"source_file":r.get("source_file"),"components":r.get("components",{})})
    cont={"positive_evidence":trace.positive_evidence,"negative_evidence":trace.negative_evidence,"net_evidence":trace.net_evidence,
          "evidence_probability":trace.evidence_probability,"cosine_similarity":trace.cosine_similarity,"magnitude_ratio":trace.magnitude_ratio,
          "logistic_similarity":trace.logistic_similarity,"pre_rule_score":trace.pre_rule_score,"diagnostic_support":trace.final_score}
    fol += [_atom("PositiveEvidence",patient_id,trace.disease,trace.positive_evidence),_atom("NegativeEvidence",patient_id,trace.disease,trace.negative_evidence),
            _atom("NetEvidence",patient_id,trace.disease,trace.net_evidence),_atom("DiagnosticSupport",patient_id,trace.disease,trace.final_score)]
    det={"pathognomonic_triggered":trace.pathognomonic_triggered,"exclusionary_triggered":trace.exclusionary_triggered,"responsible_features":[]}
    pthr=0.8 if config is None else config.pathognomonic_threshold
    ethr=0.8 if config is None else config.exclusionary_threshold
    for r in trace.feature_rows:
        if r.get("diagnostic_role")==1.0 and r.get("patient_activation",0)>=pthr and r.get("observed",False):
            det["responsible_features"].append(r["feature"]); fol.append(_atom("PathognomonicTriggered",patient_id,trace.disease,r["feature"]))
        if r.get("diagnostic_role")==-0.5 and r.get("patient_activation",0)>=ethr and r.get("observed",False):
            det["responsible_features"].append(r["feature"]); fol.append(_atom("ExclusionaryTriggered",patient_id,trace.disease,r["feature"]))
    uf={}
    if interval is not None:
        uf=interval.to_dict()
        fol += [_atom("SupportInterval",patient_id,trace.disease,interval.lower,interval.upper),_atom("IntervalWidth",patient_id,trace.disease,interval.width),
                _atom("SelectiveDecision",patient_id,trace.disease,interval.decision_label)]
        for f in interval.uncertain_features: fol.append(_atom("UnresolvedEvidence",patient_id,f))
        if interval.decision is None: fol.append(_atom("Indeterminate",patient_id,trace.disease))
    if confidence is not None:
        cf=confidence.to_dict() if hasattr(confidence,"to_dict") else dict(confidence)
        cont["evidence_coverage"]=cf.get("evidence_coverage")
        cont["confidence_score"]=cf.get("confidence_score")
        det["confidence_level"]=cf.get("confidence_level")
        det["confidence_reason"]=cf.get("reason")
        det["missing_pathognomonic"]=cf.get("missing_pathognomonic",[])
        det["missing_hallmark"]=cf.get("missing_hallmark",[])
        det["missing_major"]=cf.get("missing_major",[])
        det["missing_exclusionary"]=cf.get("missing_exclusionary",[])
        fol += [_atom("EvidenceCoverage",patient_id,trace.disease,cf.get("evidence_coverage",0.0)),
                _atom("DiagnosticConfidence",patient_id,trace.disease,cf.get("confidence_score",0.0),cf.get("confidence_level",""))]
        for role,key in (("Pathognomonic","missing_pathognomonic"),("Hallmark","missing_hallmark"),("Major","missing_major"),("Exclusionary","missing_exclusionary")):
            for f in cf.get(key,[]): fol.append(_atom("MissingCriticalEvidence",patient_id,trace.disease,role,f))
    decision={"candidate":trace.disease,"score":trace.final_score,"selective_decision":None if interval is None else interval.decision_label}
    return ExplanationObject(patient_id,trace.disease,ev,cont,det,uf,decision,prov,fol)
