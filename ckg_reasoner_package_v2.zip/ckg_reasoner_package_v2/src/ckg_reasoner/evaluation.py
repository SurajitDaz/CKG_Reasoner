from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, balanced_accuracy_score,
    confusion_matrix, matthews_corrcoef, cohen_kappa_score, roc_auc_score,
    average_precision_score, log_loss
)

_TEXT_BINARY = {
    "positive": 1, "negative": 0, "pos": 1, "neg": 0,
    "yes": 1, "no": 0, "true": 1, "false": 0,
}


def encode_binary_truth(y, positive_label=1) -> pd.Series:
    """Encode a binary ground-truth vector safely.

    Supports numeric 0/1-like labels, explicit ``positive_label`` values, and common
    textual positive/negative labels.  Raises instead of silently collapsing an
    unrecognised target to one class.
    """
    s = pd.Series(y).copy()
    if s.isna().any():
        raise ValueError(f"Ground truth contains {int(s.isna().sum())} missing value(s).")
    observed = list(pd.unique(s))
    text = s.astype(str).str.strip().str.lower()
    normalized_observed = list(pd.unique(text))
    if len(normalized_observed) != 2:
        raise ValueError(f"Binary evaluation requires exactly two ground-truth classes; observed {observed!r}.")
    if text.isin(_TEXT_BINARY).all():
        return text.map(_TEXT_BINARY).astype(int)

    numeric = pd.to_numeric(s, errors="coerce")
    if numeric.notna().all():
        pos_num = pd.to_numeric(pd.Series([positive_label]), errors="coerce").iloc[0]
        if pd.notna(pos_num) and (numeric == pos_num).any() and (numeric != pos_num).any():
            return (numeric == pos_num).astype(int)

    pos_text = str(positive_label).strip().lower()
    matches = text.eq(pos_text)
    if matches.any() and (~matches).any():
        return matches.astype(int)

    raise ValueError(
        "Unable to encode binary ground truth without ambiguity. "
        f"Observed labels: {observed!r}; positive_label={positive_label!r}. "
        "Use labels such as 0/1 or negative/positive, or set positive_label to an observed positive class."
    )


def evaluate_predictions(y_true, y_pred, score_matrix: pd.DataFrame | None = None,
                         positive_label: str | int | None = None) -> dict:
    y_true = pd.Series(y_true).copy()
    y_pred = pd.Series(y_pred).copy()
    if len(y_true) != len(y_pred):
        raise ValueError(f"y_true and y_pred must have the same length; got {len(y_true)} and {len(y_pred)}.")
    if y_true.isna().any() or y_pred.isna().any():
        raise ValueError("y_true and y_pred must not contain missing values.")
    y_true = y_true.astype(str)
    y_pred = y_pred.astype(str)

    out = {
        "n": len(y_true),
        "accuracy": accuracy_score(y_true, y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "precision_macro": precision_score(y_true, y_pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "f1_weighted": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "mcc": matthews_corrcoef(y_true, y_pred),
        "cohen_kappa": cohen_kappa_score(y_true, y_pred),
        "ground_truth_counts": y_true.value_counts(dropna=False).to_dict(),
        "prediction_counts": y_pred.value_counts(dropna=False).to_dict(),
    }
    labels = sorted(set(y_true) | set(y_pred))
    out["labels"] = labels
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    out["confusion_matrix"] = cm

    if len(labels) == 2:
        pos = str(positive_label) if positive_label is not None else labels[1]
        if pos not in labels:
            raise ValueError(f"positive_label {positive_label!r} is not present in evaluation labels {labels!r}.")
        neg = labels[0] if labels[1] == pos else labels[1]
        ordered = [neg, pos]
        bcm = confusion_matrix(y_true, y_pred, labels=ordered)
        tn, fp, fn, tp = bcm.ravel()
        out["binary_label_order"] = ordered
        out["tn"], out["fp"], out["fn"], out["tp"] = int(tn), int(fp), int(fn), int(tp)
        out.update({
            "sensitivity": tp/(tp+fn) if tp+fn else np.nan,
            "specificity": tn/(tn+fp) if tn+fp else np.nan,
            "npv": tn/(tn+fn) if tn+fn else np.nan,
            "ppv": tp/(tp+fp) if tp+fp else np.nan,
            "f1_positive": f1_score(y_true, y_pred, pos_label=pos, average="binary", zero_division=0),
        })
        # Plain binary F1: F1 of the explicitly designated positive class.
        # Keep f1_positive for backward compatibility and expose the conventional
        # short name requested for reporting.
        out["f1"] = out["f1_positive"]

    if score_matrix is not None and not score_matrix.empty:
        sm = score_matrix.reindex(y_true.index).copy()
        sm.columns = sm.columns.astype(str)
        sm = sm.reindex(columns=labels, fill_value=0.0)
        row_sum = sm.sum(axis=1).replace(0, np.nan)
        prob = sm.div(row_sum, axis=0).fillna(1/max(len(labels), 1))
        try:
            if len(labels) == 2:
                positive = str(positive_label) if positive_label is not None else labels[1]
                if positive not in labels:
                    positive = labels[1]
                yt = (y_true == positive).astype(int)
                if yt.nunique() == 2:
                    out["roc_auc"] = roc_auc_score(yt, prob[positive])
                    out["average_precision"] = average_precision_score(yt, prob[positive])
                else:
                    out["roc_auc"] = np.nan
                    out["average_precision"] = np.nan
                    out["auc_unavailable_reason"] = "Ground truth contains only one class."
            elif len(labels) > 2:
                out["roc_auc_ovr_macro"] = roc_auc_score(y_true, prob, labels=labels, multi_class="ovr", average="macro")
        except ValueError as e:
            out["auc_unavailable_reason"] = str(e)
        try:
            out["log_loss"] = log_loss(y_true, prob, labels=labels)
        except ValueError as e:
            out["log_loss_unavailable_reason"] = str(e)
    return out
