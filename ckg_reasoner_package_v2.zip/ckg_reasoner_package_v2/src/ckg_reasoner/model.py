from __future__ import annotations
from pathlib import Path
from typing import Iterable
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import f1_score
from .config import ReasoningConfig
from .functions import register_function as _register_function, available_functions as _available_functions
from .knowledge import KnowledgeBase
from .mapping import HeadingMapper
from .reasoning import score_candidate
from .evaluation import evaluate_predictions, encode_binary_truth
from .graphview import GraphSelectionView
from .uncertainty import AdmissibleDomain, bounded_support
from .explanation import build_explanation
from .confidence import assess_confidence
from .reporting import deterministic_report, verify_explanation_object
from .clinical_transformer import ClinicalReportTransformer
from .retrieval import CandidateGraphRetriever
from .separation import (
    auto_kmeans_1d, auto_kmeans_scores, gaussian_separation, mahalanobis_separation,
    BasePartitionMethod, HardAssignment, KMeansPartition, GaussianPartition, MahalanobisPartition
)
from .kmeans import diagnose_kmeans
from .gaussian import diagnose_gaussian
from .mahalanobis import diagnose_mahalanobis

class CKGModel:
    def __init__(self, knowledge_path=None, aliases=None, config: ReasoningConfig|None=None, legacy_compatibility=False):
        if config is not None:
            self.config=config
        elif legacy_compatibility:
            self.config=ReasoningConfig(missing_aware=False, activation_function="legacy_l2", soft_and_function="legacy_linear")
        else:
            self.config=ReasoningConfig()
        self.kb=KnowledgeBase(knowledge_path)
        self.mapper=HeadingMapper(self.kb,aliases=aliases)
        self.df_=None; self.source_df_=None; self.source_path_=None; self.id_created_=False
        self.heading_map_={}; self.unmatched_columns_=[]; self.ignored_columns_=[]; self.detected_schema_=None; self.target_column_=None; self.hmap_report_=None; self.results_=None; self.traces_={}
        self.kmeans_results_=None; self.kmeans_summary_=None; self.kmeans_diagnostics_=None; self.optimal_k_=None; self.kmeans_metadata_=None
        self.gaussian_results_=None; self.gaussian_diagnostics_=None; self.gaussian_metadata_=None
        self.mahalanobis_results_=None; self.mahalanobis_diagnostics_=None; self.mahalanobis_metadata_=None
        self.admissible_domains_={}
        self.support_intervals_={}
        self.graph=GraphSelectionView(self)
        self.retriever=CandidateGraphRetriever(self.kb)
        self.retrieval_traces_={}
        self.fol_explanations_={}  # populated only when the explanation/FOL layer is explicitly executed
        self.clinical_transformer_=ClinicalReportTransformer()

    def __repr__(self):
        state="fitted" if self.results_ is not None else "mapped" if self.df_ is not None else "new"
        return f"CKGModel(state={state!r}, diseases={self.kb.diseases}, rows={0 if self.df_ is None else len(self.df_)})"

    def register_function(self, name, category, function, overwrite=False):
        """Register a custom mathematical function for later assignment."""
        _register_function(category,name,function,overwrite=overwrite)
        return self

    def available_functions(self, category=None):
        return _available_functions(category)

    def set_function(self, category, name):
        """Assign a registered function by returning an updated immutable config."""
        from dataclasses import replace
        field={"activation":"activation_function","relevancy":"relevancy_function","soft_and":"soft_and_function"}.get(str(category).lower())
        if field is None:
            raise ValueError("category must be 'activation', 'relevancy', or 'soft_and'")
        if name not in _available_functions(category):
            raise ValueError(f"Unknown {category} function {name!r}; available={_available_functions(category)}")
        self.config=replace(self.config,**{field:str(name)})
        return self

    def function_config(self):
        return {"activation":self.config.activation_function,"relevancy":self.config.relevancy_function,
                "soft_and":self.config.soft_and_function,"relevancy_threshold":self.config.relevancy_threshold}

    def activation_audit(self):
        """Summarize patient-activation range after graphfit()."""
        vals=[]
        for per_record in self.traces_.values():
            for trace in per_record.values():
                vals.extend(float(r.get("patient_activation",0.0)) for r in trace.feature_rows if r.get("observed",False))
        a=np.asarray(vals,float)
        return {"activation_function":self.config.activation_function,"n":int(a.size),
                "min":None if not a.size else float(a.min()),"max":None if not a.size else float(a.max()),
                "count_gt_1":int(np.sum(a>1.0)) if a.size else 0,
                "fraction_gt_1":float(np.mean(a>1.0)) if a.size else 0.0}

    def hmap(self, df, interactive=True, fuzzy_threshold=0.88, disease_hint=None, target=None):
        """Map raw dataset headings to CKG ontology headings.

        v0.4 adds automatic recognition of the four frozen paper cohorts, robust unit/punctuation
        normalization, dataset-specific disambiguation (e.g. dengue MTP vs malaria THR), and
        deterministic value normalization needed by the M1/I1 schemas. The original API remains
        valid: ``model.hmap(df)`` still works.
        """
        if isinstance(df,(str,Path)):
            p=Path(df); self.source_path_=p
            df=pd.read_csv(p) if p.suffix.lower()=='.csv' else pd.read_excel(p)
        else:
            self.source_path_=None
        if not isinstance(df,pd.DataFrame): raise TypeError("hmap expects a pandas DataFrame or CSV/XLSX path.")

        # Every patient record receives a stable primary key. Existing valid `id` values are
        # preserved. A case-only ID heading is canonicalized. Invalid/duplicate IDs are retained
        # as `id_original` and replaced by deterministic 1..N identifiers.
        df=df.copy()
        self.id_created_=False
        if "id" not in df.columns:
            case_ids=[c for c in df.columns if str(c).lower()=="id"]
            if len(case_ids)==1 and df[case_ids[0]].notna().all() and df[case_ids[0]].is_unique:
                df=df.rename(columns={case_ids[0]:"id"})
            else:
                df.insert(0,"id",np.arange(1,len(df)+1,dtype=int)); self.id_created_=True
        elif df["id"].isna().any() or not df["id"].is_unique:
            df=df.rename(columns={"id":"id_original"})
            df.insert(0,"id",np.arange(1,len(df)+1,dtype=int)); self.id_created_=True
        self.source_df_=df.copy()

        mapped,mapping,unmatched,ignored=self.mapper.map(
            df, interactive=interactive, fuzzy_threshold=fuzzy_threshold, disease_hint=disease_hint, target=target
        )
        self.df_=mapped.replace({np.nan:None}); self.heading_map_=mapping; self.unmatched_columns_=unmatched; self.ignored_columns_=ignored
        self.detected_schema_=self.mapper.last_schema; self.target_column_=self.mapper.last_target; self.hmap_report_=self.mapper.last_report
        if self.detected_schema_:
            print(f"Detected dataset schema: {self.detected_schema_} (confidence={self.mapper.last_schema_confidence:.2f})")
        print(f"Successful matches found: {len(mapping)} dataset headings mapped to ontology headings.")
        if mapping:
            print(pd.DataFrame({"dataset_heading":list(mapping),"ontology_heading":list(mapping.values())}).to_string(index=False))
        if ignored: print("Ignored metadata/target headings:", ignored)
        if unmatched: print("Unmatched/skipped headings:", unmatched)
        return self

    def hmap_report(self):
        """Return the most recent heading-mapping audit table."""
        if self.hmap_report_ is None:
            raise RuntimeError("Run hmap() first.")
        return self.hmap_report_.copy()

    def graphfit(self, top_k=None, strategy="auto", candidate_k=None, min_retrieval_score=0.0, min_matches=1, fallback=True, auto_kmeans=True):
        """Fit/rank disease graphs for every patient record.

        strategy="exhaustive" reproduces the original behavior. strategy="retrieval"
        first uses the training-free ontology inverted index, then applies the unchanged
        Framework-2 reasoner only to retrieved graphs. strategy="auto" uses exhaustive
        scoring for small KBs (<=20 diseases) and retrieval for larger KBs.

        `top_k` limits retained diagnostic traces after scoring; `candidate_k` limits
        graphs entering diagnostic scoring. Retrieval never uses outcome labels.
        """
        if self.df_ is None: raise RuntimeError("Call model.hmap(df) before graphfit().")
        strategy=str(strategy).lower()
        if strategy not in {"auto","exhaustive","retrieval"}: raise ValueError("strategy must be 'auto', 'exhaustive', or 'retrieval'.")
        effective="exhaustive" if strategy=="auto" and len(self.kb.reference_vectors)<=20 else ("retrieval" if strategy=="auto" else strategy)
        rows=[]; self.traces_.clear(); self.support_intervals_.clear(); self.retrieval_traces_.clear(); self.fol_explanations_.clear()
        all_keys=list(self.kb.reference_vectors)
        for ridx,row in self.df_.iterrows():
            patient={k:(None if pd.isna(v) else v) for k,v in row.to_dict().items()}
            hits=[]
            if effective=="retrieval":
                hits=self.retriever.retrieve(patient,top_k=candidate_k,min_score=min_retrieval_score,min_matches=min_matches)
                disease_keys=[h.key for h in hits]
                if not disease_keys and fallback: disease_keys=all_keys
            else:
                disease_keys=all_keys
            self.retrieval_traces_[ridx]={"strategy":effective,"candidates":[h.to_dict() for h in hits],"candidate_count":len(disease_keys),"total_graphs":len(all_keys),"fallback_used":bool(effective=="retrieval" and not hits and fallback)}
            traces=[score_candidate(patient,self.kb.disease_names[key],self.kb.reference_vectors[key],self.config) for key in disease_keys]
            traces.sort(key=lambda t:t.final_score,reverse=True)
            if top_k: traces=traces[:int(top_k)]
            self.traces_[ridx]={t.disease:t for t in traces}
            best=traces[0] if traces else None
            rec={"row_id":ridx,"predicted_disease":best.disease if best else None,"best_score":best.final_score if best else np.nan,"retrieval_strategy":effective,"candidate_graphs_scored":len(disease_keys)}
            for t in traces: rec[f"score__{t.disease}"]=t.final_score
            rows.append(rec)
        self.results_=pd.DataFrame(rows).set_index("row_id",drop=False)
        print(f"Graph fitting completed for {len(self.results_)} record(s); strategy={effective!r}; knowledge base={len(all_keys)} disease graph(s).")
        if auto_kmeans:
            self._fit_auto_kmeans()
        return self

    def _fit_auto_kmeans(self, min_k=3, max_k=10, random_state=42):
        """Automatically fit the K-means method on disease-support score vectors only.

        This is retained as a convenience auto-run after graphfit(). K is selected by
        maximum silhouette score; no outcome labels or raw patient variables are used.
        """
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        try:
            dname=self._infer_positive_disease(None)
        except Exception:
            # Fallback to the cohort's highest mean disease-support score only to choose
            # the ordering direction; the clustering itself still uses all score columns.
            dname=self.selected_diseases()[0]
        try:
            sep=auto_kmeans_scores(self._clustering_matrix(dname),dname,min_k=min_k,max_k=max_k,random_state=random_state,n_init=20)
        except ValueError:
            self.kmeans_results_=None; self.kmeans_summary_=None; self.kmeans_diagnostics_=None; self.optimal_k_=None; self.kmeans_metadata_=None
            return None
        kr=sep.assignments.copy(); self.kmeans_results_=kr; self.kmeans_diagnostics_=sep.diagnostics.copy(); self.kmeans_metadata_=dict(sep.metadata or {}); self.optimal_k_=int(self.kmeans_metadata_["selected_k"])
        self.results_.loc[kr.index,"cluster"]=kr["KMeans_Cluster"].astype(int)
        self.results_.loc[kr.index,"cluster_label"]=kr["Predicted_Result"]
        self.kmeans_summary_=(kr.groupby(["KMeans_Cluster","Predicted_Result"],as_index=False).agg(count=("Target_Disease_Score","size"),min=("Target_Disease_Score","min"),max=("Target_Disease_Score","max"),mean=("Target_Disease_Score","mean"),std=("Target_Disease_Score","std"),median=("Target_Disease_Score","median")))
        print(f"Auto K-means completed on S0=[P_evidence, r, c, Confidence_Score] (optimal K={self.optimal_k_}; target ordering={dname}).")
        return kr

    def kmeans(self, show=True, y_true=None, min_k=3, max_k=10, random_state=42, positive_disease=None, variables=None):
        """Run automatic K-means on a selected subset of S0=[P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)].

        K is chosen automatically by silhouette score. y_true is accepted only for
        backward-compatible post-hoc composition tables and is never used for fitting.
        New code should prefer model.partition(KMeansPartition(), ...).
        """
        dname=self._infer_positive_disease(positive_disease)
        obj=self.partition(KMeansPartition(min_clusters=min_k,max_clusters=max_k,random_state=random_state,variables=variables),dname,show=show)
        self.kmeans_results_=obj.assignments_.copy(); self.kmeans_diagnostics_=obj.diagnostics_.copy(); self.kmeans_metadata_=dict(obj.metadata_); self.optimal_k_=obj.n_partitions_
        self.kmeans_summary_=(self.kmeans_results_.groupby(["KMeans_Cluster","Predicted_Result"],as_index=False).agg(count=("Target_Disease_Score","size"),mean=("Target_Disease_Score","mean"),median=("Target_Disease_Score","median"),min=("Target_Disease_Score","min"),max=("Target_Disease_Score","max")))
        composition=None
        if y_true is not None:
            truth=self.df_[y_true] if isinstance(y_true,str) else pd.Series(y_true,index=self.results_.index)
            composition=pd.crosstab(self.kmeans_results_["KMeans_Cluster"],truth.reindex(self.kmeans_results_.index),dropna=False)
        return {"method":obj,"assignments":obj.assignments_.copy(),"summary":self.kmeans_summary_.copy(),"diagnostics":obj.diagnostics_.copy(),"composition":composition,"metadata":dict(obj.metadata_)}

    cluster = kmeans

    def row_from_id(self, record_id):
        """Resolve a stable patient `id` to the dataframe row key used by reasoning methods."""
        if self.df_ is None or "id" not in self.df_: raise RuntimeError("Run hmap() first.")
        m=self.df_.index[self.df_["id"]==record_id].tolist()
        if not m:
            # common CSV/Excel type mismatch fallback
            m=self.df_.index[self.df_["id"].astype(str)==str(record_id)].tolist()
        if not m: raise KeyError(f"Record id {record_id!r} not found.")
        if len(m)>1: raise ValueError(f"Record id {record_id!r} is not unique.")
        return m[0]

    def candidate_graphs(self, row=0):
        """Return the retrieval audit trace for one record."""
        rk=self._row_key(row)
        return self.retrieval_traces_.get(rk,{})

    def selected_diseases(self,top=None):
        if self.results_ is None: return []
        score_cols=[c for c in self.results_ if c.startswith('score__')]
        means={c[7:]:float(self.results_[c].mean()) for c in score_cols}
        ordered=[k for k,_ in sorted(means.items(),key=lambda kv:kv[1],reverse=True)]
        return ordered[:top] if top else ordered

    def _diseases(self,diseases=None):
        if diseases is None: return self.selected_diseases()
        if isinstance(diseases,str): diseases=[diseases]
        resolved=[]
        for d in diseases:
            key=self.kb.resolve(d); resolved.append(self.kb.disease_names[key])
        return resolved

    def evidence(self,diseases=None,subheading=None,row=0):
        ds=self._diseases(diseases); out={}
        allowed={"clinical importance":"clinical_importance","specificity":"diagnostic_role","similarity":"patient_activation","support":"support","contradiction":"contradiction"}
        wanted=list(allowed) if subheading is None else ([subheading] if isinstance(subheading,str) else list(subheading))
        trace_row=self.traces_[self.results_.index[row] if isinstance(row,int) and row not in self.traces_ else row]
        for d in ds:
            tr=trace_row[d]
            frame=pd.DataFrame(tr.feature_rows)
            cols=["feature","name"]+[allowed[w.lower()] for w in wanted if w.lower() in allowed]
            out[d]=frame[[c for c in cols if c in frame.columns]]
        return out

    def evidance(self,*args,**kwargs):
        """Backward-compatible spelling requested in the original API."""
        return self.evidence(*args,**kwargs)

    def Continuous_reasoning(self,diseases=None,row=0):
        ds=self._diseases(diseases); trr=self.traces_[self.results_.index[row] if isinstance(row,int) and row not in self.traces_ else row]
        return {d:{"evidence_accumulation":{"positive":trr[d].positive_evidence,"negative":trr[d].negative_evidence,"net":trr[d].net_evidence,"evidence_probability":trr[d].evidence_probability},"diagnostic_support":{"cosine_similarity":trr[d].cosine_similarity,"magnitude_ratio":trr[d].magnitude_ratio,"logistic_similarity":trr[d].logistic_similarity,"score":trr[d].final_score}} for d in ds}

    def Deterministic_reasoning(self,diseases=None,row=0):
        ds=self._diseases(diseases); trr=self.traces_[self.results_.index[row] if isinstance(row,int) and row not in self.traces_ else row]
        return {d:{"pathognomonic_rules":trr[d].pathognomonic_triggered,"exclusionary_rules":trr[d].exclusionary_triggered,"responsible_features":[r["feature"] for r in trr[d].feature_rows if r.get("observed",False) and ((r["diagnostic_role"]==1.0 and r["patient_activation"]>=self.config.pathognomonic_threshold) or (r["diagnostic_role"]==-0.5 and r["patient_activation"]>=self.config.exclusionary_threshold))]} for d in ds}

    def set_admissible_domains(self, domains, disease=None):
        """Declare activation-space admissible domains for bounded-support reasoning.

        Parameters
        ----------
        domains : mapping
            Feature -> scalar (exact), (lower, upper), iterable of discrete states, or
            AdmissibleDomain. Values are candidate-conditioned activation magnitudes.
        disease : str or None
            If provided, declarations apply only to that disease. If omitted, the same
            feature declarations are available to every disease containing the feature.
        """
        key="*" if disease is None else self.kb.disease_names[self.kb.resolve(disease)]
        self.admissible_domains_.setdefault(key,{})
        self.admissible_domains_[key].update(dict(domains))
        return self

    def _row_key(self,row=0):
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        if row in self.traces_: return row
        if isinstance(row,int) and 0 <= row < len(self.results_): return self.results_.index[row]
        raise KeyError(f"Unknown row {row!r}.")

    def _declared_domains_for(self,disease):
        d={}
        d.update(self.admissible_domains_.get("*",{}))
        d.update(self.admissible_domains_.get(disease,{}))
        return d

    def bounded_support(self,diseases=None,row=0,exact_discrete_limit=14,shgo_samples=96,max_continuous_dimensions=8):
        """Propagate admissible evidence to diagnostic-support intervals.

        Observed EFNs are exact. Missing EFNs use declared domains when available;
        otherwise a conservative component-derived activation envelope is used and
        explicitly marked as such in the returned provenance.
        """
        rk=self._row_key(row); ds=self._diseases(diseases); out={}
        self.support_intervals_.setdefault(rk,{})
        for d in ds:
            tr=self.traces_[rk][d]
            si=bounded_support(tr,self.config,self._declared_domains_for(d),exact_discrete_limit,shgo_samples,max_continuous_dimensions)
            self.support_intervals_[rk][d]=si
            out[d]=si.to_dict()
        return out

    def Selective_decision(self,diseases=None,row=0,**kwargs):
        """Return positive / negative / indeterminate decisions from bounded support."""
        bs=self.bounded_support(diseases,row,**kwargs)
        return {d:{"decision":v["decision"],"label":v["decision_label"],"support_interval":[v["lower"],v["upper"]],"width":v["width"]} for d,v in bs.items()}

    def Uncertainty(self,diseases=None,gray_quantiles=(0.33,0.67),row=None,formal=True):
        """Report formal bounded support plus label-free exploratory score context."""
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        ds=self._diseases(diseases); out={}
        formal_row=0 if row is None else row
        formal_result=self.bounded_support(ds,formal_row) if formal else {}
        for d in ds:
            s=pd.to_numeric(self.results_[f"score__{d}"],errors="coerce")
            desc=s.describe().to_dict()
            clusters=None; meta=None
            try:
                # Exploratory cohort clustering must use the same 4-D post-KG S0 vector
                # as the public K-means/GMM/Mahalanobis API: [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)].
                # The final scalar disease score is summarized below but is NOT used
                # as a clustering coordinate.
                sep=auto_kmeans_scores(
                    self._clustering_matrix(d), d,
                    min_k=2, max_k=10, random_state=42, n_init=20
                )
                clusters=sep.assignments.copy()
                meta=sep.metadata
            except (ValueError, KeyError):
                pass
            ql,qh=s.quantile(list(gray_quantiles)); gray=(s>=ql)&(s<=qh)
            out[d]={
                "bounded_support":formal_result.get(d),
                "exploratory":{
                    "score_distribution":desc,
                    "kmeans":clusters,
                    "kmeans_metadata":meta,
                    "gray_uncertain_region":{"lower":float(ql),"upper":float(qh),"rows":s.index[gray].tolist()},
                    "warning":"Exploratory cohort context only; does not alter core KG inference."
                }
            }
        return out

    def explanation_object(self,diseases=None,row=0,include_uncertainty=True):
        """Build the machine-verifiable patient/disease explanation object Z_x,j."""
        rk=self._row_key(row); ds=self._diseases(diseases); out={}
        if include_uncertainty:
            self.bounded_support(ds,rk)
        for d in ds:
            interval=self.support_intervals_.get(rk,{}).get(d) if include_uncertainty else None
            out[d]=build_explanation(rk,self.traces_[rk][d],interval,self.config,assess_confidence(self.traces_[rk][d]))
        return out

    def explain(self,diseases=None,row=0,include_uncertainty=True,format="dict"):
        """Execute/cache the FOL explanation layer and return its grounded result."""
        objs=self.explanation_object(diseases,row,include_uncertainty)
        rk=self._row_key(row)
        self.fol_explanations_.setdefault(rk,{})
        self.fol_explanations_[rk].update(objs)
        f=str(format).lower()
        if f in {"object","objects"}: return objs
        if f in {"fol","facts"}: return {d:o.to_fol() for d,o in objs.items()}
        if f != "dict": raise ValueError("format must be 'dict', 'object', or 'fol'.")
        return {d:o.to_dict() for d,o in objs.items()}

    def _score_matrix(self):
        """Return disease-support scores only (no patient variables or outcome columns)."""
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        score_cols=[c for c in self.results_ if c.startswith("score__")]
        sm=self.results_[score_cols].copy(); sm.columns=[c[7:] for c in score_cols]
        return sm

    def _confidence_eligible_features(self, disease):
        """Features evaluable somewhere in the cohort for the candidate disease.

        This reproduces the confidence-audit denominator used by output(), so the
        Confidence_Score coordinate in S0 is numerically identical to the exported
        confidence score and remains independent of outcome labels.
        """
        return {
            r.get("feature")
            for per in self.traces_.values()
            for tr in [per.get(disease)] if tr is not None
            for r in tr.feature_rows if r.get("observed", False)
        }

    def _clustering_matrix(self, target_disease):
        """Return the 4-D post-KG vector used for unsupervised partitioning.

        S0(D_j) = [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)]^T.
        Confidence_Score is the existing evidence-completeness audit score; it is
        not outcome-fitted. The scalar disease-ranking score R(D_j) is deliberately
        NOT used as a clustering coordinate.
        """
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        dname=self.kb.disease_names[self.kb.resolve(target_disease)]
        eligible=self._confidence_eligible_features(dname)
        rows=[]
        for rk in self.results_.index:
            tr=self.traces_.get(rk,{}).get(dname)
            conf=None if tr is None else assess_confidence(tr,eligible_features=eligible)
            rows.append({"P_evidence": np.nan if tr is None else float(tr.evidence_probability),
                         "r": np.nan if tr is None else float(tr.magnitude_ratio),
                         "c": np.nan if tr is None else float(tr.cosine_similarity),
                         "Confidence_Score": np.nan if conf is None else float(conf.confidence_score)})
        return pd.DataFrame(rows,index=self.results_.index)

    def clustering_vectors(self, positive_disease=None):
        """Public audit view of the exact 4-D S0 vectors used by K-means, GMM and Mahalanobis."""
        dname=self._infer_positive_disease(positive_disease)
        return self._clustering_matrix(dname).copy()

    def disease_scores(self):
        """Return the exact disease-support score matrix used by adaptive partitioners.

        This contains only ``score__<disease>`` outputs from KG reasoning, renamed to
        disease names. It never contains raw patient features or ground-truth labels.
        """
        return self._score_matrix().copy()

    def partition(self, method, positive_disease=None, show=True):
        """Fit an estimator-style post-KG decision/partitioning method on disease scores only.

        Parameters
        ----------
        method : HardAssignment, KMeansPartition, GaussianPartition, MahalanobisPartition
            An unfitted or fitted method object. No outcome labels are accepted by method.fit().
        positive_disease : str
            Disease whose ordered score direction defines negative/intermediate/positive groups.
        show : bool
            Generate the method's visual outputs after fitting.
        """
        if not isinstance(method, BasePartitionMethod):
            raise TypeError("method must be a HardAssignment, KMeansPartition, GaussianPartition, or MahalanobisPartition object.")
        dname=self._infer_positive_disease(positive_disease)
        fit_matrix = self._score_matrix() if method.name == "hard" else self._clustering_matrix(dname)
        method.fit(fit_matrix, dname)
        self.partition_method_=method
        if method.name=="kmeans":
            self.kmeans_results_=method.assignments_.copy(); self.kmeans_diagnostics_=method.diagnostics_.copy(); self.kmeans_metadata_=dict(method.metadata_); self.optimal_k_=method.n_partitions_
        elif method.name=="gaussian":
            self.gaussian_results_=method.assignments_.copy(); self.gaussian_diagnostics_=method.diagnostics_.copy(); self.gaussian_metadata_=dict(method.metadata_)
        elif method.name=="mahalanobis":
            self.mahalanobis_results_=method.assignments_.copy(); self.mahalanobis_diagnostics_=method.diagnostics_.copy(); self.mahalanobis_metadata_=dict(method.metadata_)
        if show: method.visualize()
        return method

    def evaluate(self,y_true,metrics="all",positive_disease=None,positive_label=1,method=None,**kwargs):
        """Evaluate predictions with the existing scikit-learn strategy.

        With method=None, behavior is unchanged: evaluate the KG's best-ranked disease.
        With a fitted partition-method object, its positive/negative/indeterminate tags are
        evaluated as three labels; indeterminate records therefore count as non-matches.
        Use evalute_tag()/evaluate_tag() to exclude indeterminate records and report coverage.
        """
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        if isinstance(y_true,str):
            if self.df_ is None or y_true not in self.df_: raise KeyError(f"Column {y_true!r} not found.")
            truth=self.df_[y_true]
        else: truth=pd.Series(y_true,index=self.results_.index)
        sm=self._score_matrix()
        if method is None:
            pred=self.results_["predicted_disease"]
            if positive_disease is not None:
                dname=self._infer_positive_disease(positive_disease)
                truth_bin=encode_binary_truth(pd.Series(truth), positive_label=positive_label)
                pred_bin=(pred==dname).astype(int)
                scores=pd.DataFrame({"0":1.0-sm[dname],"1":sm[dname]},index=sm.index)
                return evaluate_predictions(truth_bin.astype(str),pred_bin.astype(str),scores,positive_label="1")
            return evaluate_predictions(pd.Series(truth).astype(str),pred.astype(str),sm)
        method,dname=self._method_object(method,positive_disease,show=False,**kwargs)
        if method == "bounded":
            t=self._selective_tags(dname,method="bounded"); tags=t["Predicted_Result"].reindex(self.results_.index).fillna("indeterminate")
        else:
            tags=method.predictions_.reindex(self.results_.index).fillna("indeterminate")
        tr=pd.Series(truth,index=self.results_.index)
        truth_bin=encode_binary_truth(tr, positive_label=positive_label)
        truth_tag=truth_bin.map({0:"negative",1:"positive"})
        # Three-label evaluation; every indeterminate prediction is counted as a mismatch.
        out=evaluate_predictions(truth_tag.astype(str),tags.astype(str),None,positive_label="positive")
        # Plain positive-class F1 on all records.  Indeterminate predictions are
        # treated as not-positive, so a true-positive record that is abstained on
        # contributes a false negative. This preserves the all-record evaluation
        # semantics while making the conventional binary F1 directly reportable.
        truth_positive=truth_tag.eq("positive").astype(int)
        pred_positive=tags.eq("positive").astype(int)
        plain_f1=f1_score(truth_positive,pred_positive,pos_label=1,average="binary",zero_division=0)
        out["f1_positive"]=plain_f1
        out["f1"]=plain_f1
        out.update({"n_total":len(tags),"n_indeterminate":int((tags=="indeterminate").sum()),
                    "coverage":float((tags!="indeterminate").mean()),"abstention_rate":float((tags=="indeterminate").mean()),
                    "positive_disease":dname,"tag_method":("bounded" if method == "bounded" else method.name),
                    "evaluation_mode":"all records; indeterminate retained as a third predicted label"})
        return out

    def _infer_positive_disease(self, positive_disease=None):
        if positive_disease is not None:
            return self.kb.disease_names[self.kb.resolve(positive_disease)]
        if self.detected_schema_:
            try:
                from .mapping import KNOWN_SCHEMAS
                hint=KNOWN_SCHEMAS[self.detected_schema_].get("disease")
                if hint: return self.kb.disease_names[self.kb.resolve(hint)]
            except Exception:
                pass
        if self.results_ is not None and len(self.selected_diseases())==1:
            return self.selected_diseases()[0]
        raise ValueError("positive_disease is required when it cannot be inferred from the detected dataset schema.")

    def help(self, topic="clustering"):
        """Print concise user help for the public CKG Reasoner workflow."""
        topic=str(topic or "clustering").lower().strip()
        if topic not in {"clustering","cluster","partition","all"}:
            print("Available help topic: clustering")
            return
        print("CKG Reasoner clustering help")
        print("Eligible variables: P_evidence, r, c, Confidence_Score")
        print("Default: variables=None -> ALL FOUR eligible variables are used.")
        print('Subset example: variables=["P_evidence", "r", "c"]')
        print('K-means:     model.kmeans_partition("Dengue", variables=None)')
        print('GMM:         model.gaussian("Dengue", variables=None)')
        print('Mahalanobis: model.mahalanobis("Dengue", variables=None)')
        print('Diagnostics: model.diagnostics("kmeans", "Dengue", variables=None)')
        print("Raw patient variables, outcome labels, and R(D_j) are not clustering coordinates.")

    def diagnostics(self, method, positive_disease=None, show=True, **kwargs):
        """Run label-free cluster-count diagnostics on S0=[P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] only.

        Returns a DataFrame. The recommended count is available as
        ``df.attrs["recommended_n"]``; it is advisory and the user may manually choose n.
        """
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        dname=self._infer_positive_disease(positive_disease)
        name=str(method).lower().strip()
        if name in {"kmeans","k-means"}:
            d=diagnose_kmeans(self._clustering_matrix(dname),dname,show=show,**kwargs); self.kmeans_diagnostics_=d
        elif name in {"gaussian","gmm","gaussian-mixture"}:
            d=diagnose_gaussian(self._clustering_matrix(dname),dname,show=show,**kwargs); self.gaussian_diagnostics_=d
        elif name in {"mahalanobis","mahal"}:
            d=diagnose_mahalanobis(self._clustering_matrix(dname),dname,show=show,**kwargs); self.mahalanobis_diagnostics_=d
        else: raise ValueError("method must be 'kmeans', 'gaussian', or 'mahalanobis'.")
        print(f"{name} diagnostics complete. Advisory recommended n={d.attrs.get('recommended_n')}; choose n manually for the final fit.")
        return d

    def visualize(self, method, y_true=None, positive_disease=None, **kwargs):
        """Fit/resolve a partition method and render the full visualization family.

        ``y_true`` is optional and is used only for the post-fit actual-outcome composition plot.
        """
        obj,dname=self._method_object(method,positive_disease,show=False,**kwargs)
        if obj == "bounded": raise ValueError("Full clustering visualization is not defined for bounded-support mode.")
        truth=self.df_[y_true] if isinstance(y_true,str) else y_true
        obj.visualize(y_true=truth)
        return obj

    def gaussian(self, positive_disease=None, show=True, n=None, min_components=3, max_components=10, random_state=42, variables=None):
        """Convenience wrapper returning a fitted GaussianPartition object."""
        return self.partition(GaussianPartition(n_components=n,min_components=min_components,max_components=max_components,random_state=random_state,variables=variables),positive_disease,show=show)

    gaussian_separation = gaussian

    def mahalanobis(self, positive_disease=None, show=True, n=None, min_clusters=3, max_clusters=10, random_state=42, variables=None):
        """Convenience wrapper returning a fitted MahalanobisPartition object."""
        return self.partition(MahalanobisPartition(n_clusters=n,min_clusters=min_clusters,max_clusters=max_clusters,random_state=random_state,variables=variables),positive_disease,show=show)

    mahalanobis_separation = mahalanobis

    def kmeans_partition(self, positive_disease=None, show=True, n=None, min_clusters=3, max_clusters=10, random_state=42, variables=None):
        """Convenience wrapper returning a fitted automatic KMeansPartition object."""
        return self.partition(KMeansPartition(n_clusters=n,min_clusters=min_clusters,max_clusters=max_clusters,random_state=random_state,variables=variables),positive_disease,show=show)

    def hard_assignment(self, positive_disease=None, show=True, negative_threshold=None, positive_threshold=None):
        """Convenience wrapper returning a fitted HardAssignment object."""
        nt=self.config.negative_threshold if negative_threshold is None else negative_threshold
        pt=self.config.positive_threshold if positive_threshold is None else positive_threshold
        return self.partition(HardAssignment(nt,pt),positive_disease,show=show)

    def _evidence_reason_suffix(self, rk, dname):
        tr=self.traces_[rk][dname]
        best=self.results_.loc[rk,"predicted_disease"]
        parts=[]
        if tr.pathognomonic_triggered: parts.append("Pathognomonic rule triggered.")
        if tr.exclusionary_triggered: parts.append("Exclusionary rule triggered.")
        observed=[r for r in tr.feature_rows if r.get("observed",False)]
        pos_ev=sorted(observed,key=lambda r:float(r.get("positive_contribution",0.0) or 0.0),reverse=True)
        pos_names=[str(r.get("name") or r.get("feature")) for r in pos_ev if float(r.get("positive_contribution",0.0) or 0.0)>0][:3]
        neg_ev=sorted(observed,key=lambda r:float(r.get("negative_contribution",0.0) or 0.0),reverse=True)
        neg_names=[str(r.get("name") or r.get("feature")) for r in neg_ev if float(r.get("negative_contribution",0.0) or 0.0)>0][:2]
        if pos_names: parts.append("Main supporting evidence: "+", ".join(pos_names)+".")
        if neg_names: parts.append("Main contradictory evidence: "+", ".join(neg_names)+".")
        parts.append(f"Best-ranked disease: {best}.")
        return " ".join(parts)

    def _method_object(self, method, positive_disease=None, show=False, **kwargs):
        dname=self._infer_positive_disease(positive_disease if positive_disease is not None else getattr(method,"target_disease_",None))
        if isinstance(method, BasePartitionMethod):
            if (not method.fitted_) or method.target_disease_ != dname:
                method=self.partition(method,dname,show=show)
            elif show:
                method.visualize()
            return method,dname
        name=str(method).lower().strip()
        aliases={"gmm":"gaussian","gaussian-mixture":"gaussian","gaussian_mixture":"gaussian",
                 "mahal":"mahalanobis","hard-assignment":"hard","score":"hard"}
        name=aliases.get(name,name)
        if name=="hard": obj=HardAssignment(self.config.negative_threshold,self.config.positive_threshold)
        elif name=="kmeans": obj=KMeansPartition(n_clusters=kwargs.get("n",kwargs.get("n_clusters")),min_clusters=kwargs.get("min_clusters",3),max_clusters=kwargs.get("max_clusters",10),random_state=kwargs.get("random_state",42),variables=kwargs.get("variables"))
        elif name=="gaussian": obj=GaussianPartition(n_components=kwargs.get("n",kwargs.get("n_components")),min_components=kwargs.get("min_components",3),max_components=kwargs.get("max_components",10),random_state=kwargs.get("random_state",42),variables=kwargs.get("variables"))
        elif name=="mahalanobis": obj=MahalanobisPartition(n_clusters=kwargs.get("n",kwargs.get("n_clusters")),min_clusters=kwargs.get("min_clusters",3),max_clusters=kwargs.get("max_clusters",10),random_state=kwargs.get("random_state",42),variables=kwargs.get("variables"))
        elif name=="bounded": return "bounded",dname
        else: raise ValueError("method must be hard, kmeans, gaussian, mahalanobis, bounded, or a fitted partition-method object.")
        return self.partition(obj,dname,show=show),dname

    def _selective_tags(self, positive_disease=None, method="hard", mode=None, show=False, **kwargs):
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        if mode is not None:
            ml=str(mode).lower(); method="hard" if ml=="score" else ml
        obj,dname=self._method_object(method,positive_disease,show=show,**kwargs)
        rows=[]
        if obj=="bounded":
            for rk in self.results_.index:
                score=float(self.traces_[rk][dname].final_score); si=self.bounded_support(dname,row=rk)[dname]
                tag=si["decision_label"]; lo=float(si["lower"]); hi=float(si["upper"])
                why=f"Method=bounded-support; {dname} support interval=[{lo:.4f}, {hi:.4f}]."
                suffix=self._evidence_reason_suffix(rk,dname)
                if suffix: why += " " + suffix
                rows.append({"row_id":rk,"Predicted_Result":tag,"Reason":why,"support_lower":lo,"support_upper":hi,"disease":dname,"tag_method":"bounded"})
            return pd.DataFrame(rows).set_index("row_id",drop=False)
        base=obj.assignments_
        for rk in self.results_.index:
            score=float(self.traces_[rk][dname].final_score)
            if rk not in base.index:
                tag="indeterminate"; why=f"Method={obj.name}; complete disease-score vector unavailable, therefore indeterminate."
            else:
                r=base.loc[rk]; tag=str(r["Predicted_Result"])
                if obj.name=="hard":
                    if tag=="positive": why=f"Method=hard-assignment; {dname} score={score:.4f} >= fixed threshold {obj.positive_threshold:.2f}."
                    elif tag=="negative": why=f"Method=hard-assignment; {dname} score={score:.4f} <= fixed threshold {obj.negative_threshold:.2f}."
                    else: why=f"Method=hard-assignment; {dname} score={score:.4f} lies between {obj.negative_threshold:.2f} and {obj.positive_threshold:.2f}."
                elif obj.name=="kmeans":
                    k=int(obj.metadata_["selected_k"]); c=int(r["KMeans_Cluster"]); why=(f"Method=K-means; K={k} chosen {('manually' if obj.metadata_.get('selection_mode')=='manual' else 'automatically by maximum silhouette score')} using selected post-KG variables {obj.metadata_.get('score_dimensions')}; assigned to ordered partition {c+1}/{k}; lowest=negative, highest=positive, middle partition(s)=indeterminate.")
                elif obj.name=="gaussian":
                    k=int(obj.metadata_["selected_k"]); c=int(r["Gaussian_Component"]); why=(f"Method=Gaussian-mixture; K={k} chosen {('manually after BIC/AIC diagnostics' if obj.metadata_.get('selection_mode')=='manual' else 'automatically by minimum BIC')} using selected post-KG variables {obj.metadata_.get('score_dimensions')}; assigned to ordered component {c+1}/{k}; target-score component mean={float(r['Gaussian_Component_Target_Mean']):.4f}; posterior membership={float(r['Gaussian_Posterior']):.4f}; lowest=negative, highest=positive, middle component(s)=indeterminate.")
                else:
                    k=int(obj.metadata_["selected_k"]); c=int(r["Mahalanobis_Cluster"]); why=(f"Method=Mahalanobis-type; K={k} reference groups {('chosen manually after diagnostics' if obj.metadata_.get('selection_mode')=='manual' else 'selected automatically by silhouette')} using selected post-KG variables {obj.metadata_.get('score_dimensions')}; final assignment by minimum Mahalanobis distance={float(r['Mahalanobis_Distance']):.4f}; relative proximity={float(r['Mahalanobis_Relative_Proximity']):.4f}; lowest=negative, highest=positive, middle group(s)=indeterminate.")
            suffix=self._evidence_reason_suffix(rk,dname)
            if suffix: why += " " + suffix
            rows.append({"row_id":rk,"Predicted_Result":tag,"Reason":why,"support_lower":score,"support_upper":score,"disease":dname,"tag_method":obj.name})
        return pd.DataFrame(rows).set_index("row_id",drop=False)

    def tag(self,positive_disease=None,method="hard",mode=None,**kwargs):
        """Return the three-way cohort tag table without writing a file."""
        return self._selective_tags(positive_disease,method=method,mode=mode,**kwargs).copy()

    def evalute_tag(self,y_true=None,positive_disease=None,positive_label=1,metrics="all",
                    method="hard",mode=None,**kwargs):
        """Evaluate only issued positive/negative tags; exclude indeterminate records.

        Uses the same standard evaluation metrics as :meth:`evaluate` and additionally
        reports coverage/abstention. The outcome column is used only *after* tag creation;
        it is never passed to Gaussian, Mahalanobis, K-means, or KG inference.
        """
        if self.results_ is None: raise RuntimeError("Run graphfit() first.")
        if y_true is None: y_true=self.target_column_
        if y_true is None: raise ValueError("y_true is required when no target column was detected by hmap().")
        if isinstance(y_true,str):
            if self.df_ is None or y_true not in self.df_: raise KeyError(f"Column {y_true!r} not found.")
            truth=pd.Series(self.df_[y_true],index=self.df_.index)
        else: truth=pd.Series(y_true,index=self.results_.index)
        dname=self._infer_positive_disease(positive_disease)
        tags=self._selective_tags(dname,method=method,mode=mode,**kwargs)
        keep=tags["Predicted_Result"].isin(["positive","negative"])
        n_total=len(tags); n_kept=int(keep.sum()); n_ind=int((~keep).sum())
        method_used=str(tags["tag_method"].iloc[0]) if len(tags) else getattr(method,"name",str(method))
        if n_kept==0:
            return {"n":0,"n_total":n_total,"n_indeterminate":n_ind,"coverage":0.0,"abstention_rate":1.0,
                    "positive_disease":dname,"tag_method":method_used,
                    "message":"No positive/negative decisions were issued; metrics are undefined."}
        tr=truth.reindex(tags.index)[keep]
        if tr.astype(str).str.strip().str.lower().nunique() < 2:
            return {"n":n_kept,"n_total":n_total,"n_indeterminate":n_ind,"coverage":n_kept/n_total,
                    "abstention_rate":n_ind/n_total,"positive_disease":dname,"tag_method":method_used,
                    "message":"Issued decisions contain only one ground-truth class; binary metrics are undefined."}
        truth_bin=encode_binary_truth(tr, positive_label=positive_label)
        pred_bin=tags.loc[keep,"Predicted_Result"].map({"negative":0,"positive":1}).astype(int)
        score=self.results_.loc[tags.index[keep],f"score__{dname}"].astype(float)
        sm=pd.DataFrame({"0":1.0-score,"1":score},index=score.index)
        out=evaluate_predictions(truth_bin.astype(str),pred_bin.astype(str),sm,positive_label="1")
        out.update({"n_total":n_total,"n_indeterminate":n_ind,"coverage":n_kept/n_total,
                    "abstention_rate":n_ind/n_total,"positive_disease":dname,"tag_method":method_used})
        return out

    evaluate_tag = evalute_tag

    def output(self,path=None,positive_disease=None,method="hard",mode=None,manual_log=False,manual_log_format="latex",manual_log_limit=10,manual_log_mismatch_limit=None,manual_log_match_limit=5,manual_log_path=None,**kwargs):
        """Write an auditable patient-level result workbook.

        The main sheet contains the original record, actual/predicted result, mismatch
        flag, and every candidate disease's evidence, similarity, and final disease
        score. A second ``Feature_Evidence`` sheet contains the feature-level IG,
        transformed positive-similarity gate, pcon, ncon, and knowledge attributes.
        In Excel output, rows whose predicted result does not match the available
        actual outcome are highlighted yellow for error analysis.
        """
        if self.results_ is None: raise RuntimeError("Run hmap() and graphfit() before output().")
        if self.source_df_ is None: raise RuntimeError("Original input data are unavailable; rerun hmap().")
        tags=self._selective_tags(positive_disease,method=method,mode=mode,**kwargs)
        out=self.source_df_.copy()
        out["Predicted_Result"]=tags.reindex(out.index)["Predicted_Result"].values
        dname=self._infer_positive_disease(positive_disease)

        # Graph-level prediction is retained separately from the selected binary decision.
        if "predicted_disease" in self.results_.columns:
            out["Predicted_Disease"]=self.results_.reindex(out.index)["predicted_disease"].values

        # Flatten all disease-level trace quantities into the patient row.
        metric_map={
            "positive_evidence":"E_Positive", "negative_evidence":"E_Negative",
            "net_evidence":"E_Net", "canonical_net_evidence":"E_Net_Canonical", "evidence_probability":"Evidence_Probability",
            "cosine_similarity":"Similarity_Cosine_HM", "magnitude_ratio":"Similarity_Ratio_HM",
            "logistic_similarity":"Similarity_Gate_HM", "pre_rule_score":"Pre_Rule_Score",
            "final_score":"Disease_Score",
        }
        diseases=sorted({d for per in self.traces_.values() for d in per})
        for disease in diseases:
            for attr,label in metric_map.items():
                out[f"{disease}__{label}"]=[
                    getattr(self.traces_.get(rk,{}).get(disease),attr,np.nan)
                    if self.traces_.get(rk,{}).get(disease) is not None else np.nan
                    for rk in out.index
                ]

        # Diagnostic confidence is an evidence-completeness layer.
        # It does not enter P_evidence, r, c, or disease ranking R. In v2.1 it is also
        # exposed as the fourth S0 coordinate for post-KG unsupervised partitioning.
        confidence_cache={}
        cohort_evaluable={}
        for disease in diseases:
            cohort_evaluable[disease]={
                r.get("feature") for per in self.traces_.values() for tr in [per.get(disease)] if tr is not None
                for r in tr.feature_rows if r.get("observed",False)
            }
        for disease in diseases:
            assessments=[]
            for rk in out.index:
                tr=self.traces_.get(rk,{}).get(disease)
                assessments.append(assess_confidence(tr,eligible_features=cohort_evaluable.get(disease)) if tr is not None else None)
            confidence_cache[disease]={rk:a for rk,a in zip(out.index,assessments)}
            out[f"{disease}__Evidence_Coverage"]=[np.nan if a is None else a.evidence_coverage for a in assessments]
            out[f"{disease}__Confidence_Score"]=[np.nan if a is None else a.confidence_score for a in assessments]
            out[f"{disease}__Confidence_Level"]=[None if a is None else a.confidence_level for a in assessments]
            out[f"{disease}__Confidence_Reason"]=[None if a is None else a.reason for a in assessments]
            out[f"{disease}__Missing_Pathognomonic"]=[None if a is None else '; '.join(a.missing_pathognomonic) for a in assessments]
            out[f"{disease}__Missing_Hallmark"]=[None if a is None else '; '.join(a.missing_hallmark) for a in assessments]
            out[f"{disease}__Missing_Major"]=[None if a is None else '; '.join(a.missing_major) for a in assessments]
            out[f"{disease}__Missing_Exclusionary"]=[None if a is None else '; '.join(a.missing_exclusionary) for a in assessments]

        # Convenience aliases for the selected positive disease.
        selected=[confidence_cache.get(dname,{}).get(rk) for rk in out.index]
        out["Evidence_Coverage"]=[np.nan if a is None else a.evidence_coverage for a in selected]
        out["Confidence_Score"]=[np.nan if a is None else a.confidence_score for a in selected]
        out["Confidence_Level"]=[None if a is None else a.confidence_level for a in selected]
        out["Confidence_Reason"]=[None if a is None else a.reason for a in selected]

        # Normalize the actual cohort outcome, when available, to the same binary labels.
        def _actual_label(v):
            if v is None or (isinstance(v,float) and np.isnan(v)): return None
            z=str(v).strip().lower().replace("_"," ").replace("-"," ")
            pos={"1","1.0","true","yes","y","positive","pos",str(dname).strip().lower()}
            neg={"0","0.0","false","no","n","negative","neg",f"non {str(dname).strip().lower()}",f"not {str(dname).strip().lower()}"}
            if z in pos: return "positive"
            if z in neg or z.startswith("non ") or z.startswith("not "): return "negative"
            return None

        actual_col=self.target_column_ if self.target_column_ in out.columns else None
        if actual_col is not None:
            out["Actual_Result"]=[_actual_label(v) for v in out[actual_col]]
            out["Mismatch"]=[
                bool(a is not None and str(p).lower()!=a)
                for a,p in zip(out["Actual_Result"],out["Predicted_Result"])
            ]
        else:
            out["Actual_Result"]=None
            out["Mismatch"]=False

        # Keep the primary prediction next to the human-readable reason for backward compatibility.
        predicted_col=out.pop("Predicted_Result")
        out["Predicted_Result"]=predicted_col
        reasons=[]
        for rk in out.index:
            obj=self.fol_explanations_.get(rk,{}).get(dname)
            reasons.append(deterministic_report(obj) if obj is not None else "")
        out["Reason"]=reasons

        # Long-form feature evidence makes each mismatch inspectable without rerunning Python.
        detail=[]
        for rk,per_disease in self.traces_.items():
            record_id=self.source_df_.loc[rk,"id"] if "id" in self.source_df_.columns else rk
            for disease,tr in per_disease.items():
                for r in tr.feature_rows:
                    detail.append({
                        "id":record_id,"row_id":rk,"Disease":disease,"Feature":r.get("feature"),
                        "Observed":r.get("observed"),"Information_Gate":r.get("information_gate"),
                        "Positive_Similarity_Gate":r.get("positive_similarity_gate"),
                        "Patient_Magnitude":r.get("patient_magnitude"),"Feature_Cosine":r.get("feature_cosine"),
                        "Feature_Rho":r.get("feature_rho"),"Canonical_Magnitude":r.get("canonical_magnitude"),
                        "Diagnostic_Role":r.get("diagnostic_role"),"Clinical_Importance":r.get("clinical_importance"),
                        "Support":r.get("support"),"Contradiction":r.get("contradiction"),
                        "Positive_Contribution":r.get("positive_contribution"),
                        "Negative_Contribution":r.get("negative_contribution"),
                        "HM_Similarity_Feature":r.get("diagnostic_role") in (0.85,0.70),
                    })
        detail_df=pd.DataFrame(detail)

        confidence_detail=[]; explanation_rows=[]
        for rk,per_disease in self.traces_.items():
            record_id=self.source_df_.loc[rk,"id"] if "id" in self.source_df_.columns else rk
            for disease,tr in per_disease.items():
                a=confidence_cache.get(disease,{}).get(rk) or assess_confidence(tr)
                for fr in a.feature_rows:
                    confidence_detail.append({"id":record_id,"row_id":rk,"Disease":disease,**fr})
                obj=self.fol_explanations_.get(rk,{}).get(disease)
                export_obj=obj if obj is not None else build_explanation(rk,tr,None,self.config,a)
                fol_text=export_obj.to_fol()
                explanation_rows.append({
                    "id":record_id,"row_id":rk,"Disease":disease,"Disease_Score":tr.final_score,
                    "Evidence_Probability":tr.evidence_probability,"Similarity_Ratio_HM":tr.magnitude_ratio,
                    "Similarity_Cosine_HM":tr.cosine_similarity,"Evidence_Coverage":a.evidence_coverage,
                    "Confidence_Score":a.confidence_score,"Confidence_Level":a.confidence_level,
                    "Confidence_Reason":a.reason,"Missing_Pathognomonic":'; '.join(a.missing_pathognomonic),
                    "Missing_Hallmark":'; '.join(a.missing_hallmark),"Missing_Major":'; '.join(a.missing_major),
                    "Missing_Exclusionary":'; '.join(a.missing_exclusionary),"FOL_Facts":fol_text,
                    "Deterministic_Report":deterministic_report(export_obj),
                })
        confidence_df=pd.DataFrame(confidence_detail)
        explanation_df=pd.DataFrame(explanation_rows)

        if path is None:
            if self.source_path_ is not None:
                path=self.source_path_.with_name(self.source_path_.stem+"_CKG_output.xlsx")
            else:
                path=Path.cwd()/"CKG_output.xlsx"
        path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
        if path.suffix.lower()==".csv":
            out.to_csv(path,index=False)
        else:
            if path.suffix.lower() not in {".xlsx",".xls"}: path=path.with_suffix(".xlsx")
            # openpyxl is used for broad Colab compatibility and row-level audit highlighting.
            with pd.ExcelWriter(path,engine="openpyxl") as writer:
                out.to_excel(writer,index=False,sheet_name="Patient_Results")
                detail_df.to_excel(writer,index=False,sheet_name="Feature_Evidence")
                confidence_df.to_excel(writer,index=False,sheet_name="Confidence_Audit")
                explanation_df.to_excel(writer,index=False,sheet_name="Explanation_Trace")
                from openpyxl.styles import PatternFill, Font
                from openpyxl.formatting.rule import FormulaRule
                from openpyxl.utils import get_column_letter
                ws=writer.sheets["Patient_Results"]
                header_fill=PatternFill("solid",fgColor="D9EAF7")
                yellow_fill=PatternFill("solid",fgColor="FFF2CC")
                for cell in ws[1]:
                    cell.font=Font(bold=True); cell.fill=header_fill
                ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
                for col_idx in range(1,len(out.columns)+1):
                    ws.column_dimensions[get_column_letter(col_idx)].width=45 if out.columns[col_idx-1]=="Reason" else 16
                if len(out) and "Mismatch" in out.columns:
                    mc=out.columns.get_loc("Mismatch")+1; mletter=get_column_letter(mc); last=get_column_letter(len(out.columns))
                    ws.conditional_formatting.add(f"A2:{last}{len(out)+1}",FormulaRule(formula=[f"${mletter}2=TRUE"],fill=yellow_fill))
                if not detail_df.empty:
                    wd=writer.sheets["Feature_Evidence"]
                    for cell in wd[1]:
                        cell.font=Font(bold=True); cell.fill=header_fill
                    wd.freeze_panes="A2"; wd.auto_filter.ref=wd.dimensions
                    for col_idx in range(1,len(detail_df.columns)+1): wd.column_dimensions[get_column_letter(col_idx)].width=18
                for sheet_name,frame in (("Confidence_Audit",confidence_df),("Explanation_Trace",explanation_df)):
                    if not frame.empty:
                        wx=writer.sheets[sheet_name]
                        for cell in wx[1]:
                            cell.font=Font(bold=True); cell.fill=header_fill
                        wx.freeze_panes="A2"; wx.auto_filter.ref=wx.dimensions
                        for col_idx,col in enumerate(frame.columns,1):
                            wx.column_dimensions[get_column_letter(col_idx)].width=60 if col in {"Confidence_Reason","FOL_Facts","Deterministic_Report"} else 20
        self.output_path_=path; self.output_df_=out

        # Optional independent human-readable reconstruction for selected mismatches and correct matches.
        # OFF by default so existing workflows and runtime are unchanged.
        self.manual_log_path_=None
        if manual_log:
            from .manual_audit import build_manual_mismatch_latex, build_manual_mismatch_pdf
            fmt=str(manual_log_format).strip().lower()
            if fmt not in {"latex","tex","pdf"}:
                raise ValueError("manual_log_format must be 'latex'/'tex' or 'pdf'.")
            suffix=".pdf" if fmt=="pdf" else ".tex"
            audit_path=Path(manual_log_path) if manual_log_path is not None else path.with_name(path.stem+"_manual_mismatch_audit"+suffix)
            if fmt=="pdf":
                self.manual_log_path_=build_manual_mismatch_pdf(self,out,dname,method,audit_path,limit=manual_log_limit,match_limit=manual_log_match_limit,mismatch_limit=manual_log_mismatch_limit)
            else:
                self.manual_log_path_=build_manual_mismatch_latex(self,out,dname,method,audit_path,limit=manual_log_limit,match_limit=manual_log_match_limit,mismatch_limit=manual_log_mismatch_limit)
            print(f"Manual calculation audit written: {self.manual_log_path_}")
        print(f"Output written: {path} (method={tags['tag_method'].iloc[0] if len(tags) else method}); mismatch rows are yellow when actual outcome is available.")
        return path

    def _row_from_id(self, id):
        if self.source_df_ is None or "id" not in self.source_df_.columns:
            raise RuntimeError("Run hmap() first so record IDs are available.")
        m=self.source_df_.index[self.source_df_["id"] == id].tolist()
        if not m: raise KeyError(f"Unknown id {id!r}.")
        return m[0]

    def report(self,diseases=None,row=0,include_uncertainty=True,top_evidence=8):
        """Generate the backward-compatible deterministic inference-grounded report.

        Calling report executes/caches the FOL layer, so a subsequent output() may use
        this grounded explanation in the Reason column.
        """
        objs=self.explain(diseases,row,include_uncertainty,format="object")
        return {d:deterministic_report(o,top_evidence=top_evidence) for d,o in objs.items()}

    def clinical_report(self,id,disease=None,method=None,positive_disease=None,include_uncertainty=True,
                        top_evidence=8,uncertainty_test=None,transformer=None):
        """Generate a human-readable clinical report for one record ID on top of FOL.

        The FOL/explanation layer is executed first and cached. ``transformer`` may be a
        ClinicalReportTransformer instance; otherwise the model's constrained default is used.
        If the partition decision is indeterminate, the report asks for confirmatory testing.
        """
        row=self._row_from_id(id)
        dname=self._infer_positive_disease(disease or positive_disease)
        objs=self.explain(dname,row,include_uncertainty,format="object")
        pred=None
        if method is not None:
            tags=self._selective_tags(dname,method=method)
            if row in tags.index: pred=str(tags.loc[row,"Predicted_Result"])
        tr=transformer or self.clinical_transformer_
        text=tr.transform(objs[dname],predicted_result=pred,top_evidence=top_evidence,uncertainty_test=uncertainty_test)
        # ExplanationObject uses the internal row key for formal provenance; the public report
        # identifies the patient using the stable dataset ID requested by the caller.
        first=text.splitlines()
        if first: first[0]=f"Clinical decision-support report for ID {id}"
        return "\n".join(first)

    def verify_explanation(self,diseases=None,row=0,include_uncertainty=True):
        """Verify numerical, rule-provenance, interval, and decision consistency."""
        objs=self.explanation_object(diseases,row,include_uncertainty)
        return {d:verify_explanation_object(o) for d,o in objs.items()}

    def explainable_layer(self,diseases=None,row=0,include_uncertainty=True,format="dict",**kwargs):
        f=str(format).lower()
        if f in {"report","text"}:
            return self.report(diseases,row,include_uncertainty,**kwargs)
        return self.explain(diseases,row,include_uncertainty,format=f)

    # Professional lowercase aliases; manuscript/original API names remain supported.
    continuous_reasoning=Continuous_reasoning
    deterministic_reasoning=Deterministic_reasoning
    uncertainty=Uncertainty
    selective_decision=Selective_decision
