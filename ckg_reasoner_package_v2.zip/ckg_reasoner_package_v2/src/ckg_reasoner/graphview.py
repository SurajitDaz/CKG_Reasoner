class GraphSelectionView:
    def __init__(self, model): self.model=model
    def show(self, top=None):
        if self.model.results_ is None: raise RuntimeError("Run model.graphfit() first.")
        names=self.model.selected_diseases(top=top)
        print("Selected disease graphs:")
        for i,n in enumerate(names,1): print(f"  {i}. {n}")
        return names
