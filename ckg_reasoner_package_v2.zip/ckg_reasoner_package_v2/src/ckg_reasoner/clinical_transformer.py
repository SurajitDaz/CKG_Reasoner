from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
from .explanation import ExplanationObject

@dataclass
class ClinicalReportTransformer:
    """Safety-constrained verbalization layer on top of FOL-grounded explanations.

    The default backend is deterministic and requires no model download. An optional
    callable ``backend(prompt)->str`` may be supplied to use a local/remote transformer.
    The diagnostic facts, score, and decision remain fixed by CKG/FOL; the transformer
    is permitted to verbalize them, not to change them.
    """
    backend: Callable[[str], str] | None = None
    uncertainty_test: str = "confirmatory pathological/diagnostic test"

    def _prompt(self, obj: ExplanationObject, predicted_result: str | None, top_evidence: int) -> str:
        ranked=sorted(obj.evidence_facts,key=lambda x:abs(x.get("positive_contribution",0.0))+abs(x.get("negative_contribution",0.0)),reverse=True)[:max(1,int(top_evidence))]
        evidence="\n".join(f"- {e['name']}: support={e['support']:.4g}, contradiction={e['contradiction']:.4g}, similarity={e['similarity']:.4g}" for e in ranked)
        return ("Convert ONLY the following verified CKG/FOL facts into a concise clinical report. "
                "Do not add symptoms, tests, diagnoses, probabilities, or causal claims not present in the facts.\n"
                f"Patient ID: {obj.patient_id}\nCandidate disease: {obj.disease}\n"
                f"Model result: {predicted_result or obj.decision.get('selective_decision') or 'not assigned'}\n"
                f"Disease score: {obj.decision['score']:.6g}\nEvidence:\n{evidence}\nFOL:\n{obj.to_fol()}")

    def transform(self, obj: ExplanationObject, predicted_result: str | None=None, top_evidence: int=8,
                  uncertainty_test: str | None=None) -> str:
        test=uncertainty_test or self.uncertainty_test
        decision=(predicted_result or obj.decision.get("selective_decision") or "not assigned")
        uncertain=str(decision).lower() in {"indeterminate","uncertain","intermediate"}
        if self.backend is not None:
            text=str(self.backend(self._prompt(obj,predicted_result,top_evidence))).strip()
        else:
            ranked=sorted(obj.evidence_facts,key=lambda x:abs(x.get("positive_contribution",0.0))+abs(x.get("negative_contribution",0.0)),reverse=True)[:max(1,int(top_evidence))]
            observed=[e for e in ranked if e.get("observed")]
            support=[e for e in observed if e.get("support",0)>e.get("contradiction",0)]
            contra=[e for e in observed if e.get("contradiction",0)>e.get("support",0)]
            lines=[f"Clinical decision-support report for ID {obj.patient_id}",
                   f"Model assessment: {decision} for {obj.disease} (CKG disease score {obj.decision['score']:.4f})."]
            if support:
                lines.append("Supporting evidence: "+"; ".join(f"{e['name']} (support {e['support']:.3f})" for e in support[:4])+".")
            if contra:
                lines.append("Contradictory evidence: "+"; ".join(f"{e['name']} (contradiction {e['contradiction']:.3f})" for e in contra[:4])+".")
            d=obj.deterministic_facts
            if d.get("pathognomonic_triggered"): lines.append("A pathognomonic FOL rule was triggered by: "+", ".join(map(str,d.get("responsible_features",[])))+".")
            if d.get("exclusionary_triggered"): lines.append("An exclusionary FOL rule was triggered by: "+", ".join(map(str,d.get("responsible_features",[])))+".")
            if obj.uncertainty_facts:
                u=obj.uncertainty_facts
                lines.append(f"Uncertainty analysis: support interval {u['lower']:.4f}-{u['upper']:.4f}; decision {u['decision_label']}.")
            text="\n".join(lines)
        if uncertain:
            text += f"\nThe model result is uncertain/indeterminate. Please obtain a {test} before making a definitive clinical diagnosis."
        text += "\nThis is a model-generated decision-support explanation and is not a substitute for clinician judgment."
        return text
