"""K-means partitioning and diagnostics for selectable post-KG clustering variables."""
from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from .separation import KMeansPartition, _score_frame


def _elbow_strengths(k_values, inertias):
    """Normalized geometric elbow strength for each point (first-last chord distance)."""
    x=np.asarray(k_values,dtype=float); y=np.asarray(inertias,dtype=float)
    if len(x)<3: return np.zeros_like(x, dtype=float)
    # Normalize axes so units do not dominate the geometric knee.
    xn=(x-x.min())/(x.max()-x.min()) if x.max()>x.min() else np.zeros_like(x)
    yn=(y-y.min())/(y.max()-y.min()) if y.max()>y.min() else np.zeros_like(y)
    p1=np.array([xn[0],yn[0]]); p2=np.array([xn[-1],yn[-1]])
    v=p2-p1; den=np.linalg.norm(v)
    if den==0: return np.zeros_like(x, dtype=float)
    pts=np.c_[xn,yn]
    dist=np.abs(v[0]*(p1[1]-pts[:,1])-(p1[0]-pts[:,0])*v[1])/den
    # endpoints cannot be elbows. Return strengths on [0,1].
    dist[0]=dist[-1]=0.0
    mx=float(np.max(dist))
    return dist/mx if mx>0 else np.zeros_like(dist)


def _elbow_k(k_values, inertias):
    """Deterministic knee: maximum normalized perpendicular chord distance."""
    strengths=_elbow_strengths(k_values,inertias)
    return int(np.asarray(k_values,dtype=int)[int(np.argmax(strengths))])


def diagnose_kmeans(score_matrix: pd.DataFrame, target_disease: str, min_clusters=2, max_clusters=10,
                     random_state=42, n_init=10, show=True, variables=None,
                     print_recommendations=False) -> pd.DataFrame:
    """Elbow/inertia + silhouette diagnostics in the selected post-KG variable space."""
    _,valid,cols=_score_frame(score_matrix,target_disease,variables=variables)
    z=StandardScaler().fit_transform(valid[cols].to_numpy(float))
    unique_rows=len(np.unique(np.round(z,12),axis=0)); hi=min(int(max_clusters),unique_rows,len(valid)-1); lo=max(2,int(min_clusters))
    if hi<lo: raise ValueError(f"K-means diagnostics require at least {lo} usable cluster counts.")
    rows=[]
    km1=KMeans(n_clusters=1,random_state=random_state,n_init=n_init).fit(z)
    rows.append({"n":1,"k":1,"inertia":float(km1.inertia_),"silhouette":np.nan})
    for k in range(lo,hi+1):
        km=KMeans(n_clusters=k,random_state=random_state,n_init=n_init).fit(z)
        sil=float(silhouette_score(z,km.labels_)) if len(set(km.labels_))>1 else np.nan
        rows.append({"n":k,"k":k,"inertia":float(km.inertia_),"silhouette":sil})
    d=pd.DataFrame(rows); finite=d[np.isfinite(d.silhouette)]
    sil_k=int(finite.sort_values(["silhouette","k"],ascending=[False,True]).iloc[0].k)
    elbow_strength=_elbow_strengths(d.k.to_numpy(),d.inertia.to_numpy())
    d["elbow_strength"]=elbow_strength
    # K=1 is an inertia baseline only, never an admissible clustering recommendation.
    # With fewer than two admissible candidate K values there is no geometric knee;
    # deterministically return the sole admissible K instead.
    elbow_candidates=d[d.k>=lo]
    if len(elbow_candidates)==1:
        elbow_k=int(elbow_candidates.iloc[0].k)
    else:
        elbow_k=int(elbow_candidates.sort_values(["elbow_strength","k"],ascending=[False,True]).iloc[0].k)
    # Consensus best-k: equal-weight normalized elbow and silhouette evidence.
    # k=1 is excluded because silhouette is undefined there.
    d["silhouette_strength"]=np.nan
    d["combined_score"]=np.nan
    cand=d[d.k>=2].copy()
    sv=cand.silhouette.to_numpy(float)
    finite_sv=np.isfinite(sv)
    ss=np.zeros(len(cand),dtype=float)
    if finite_sv.any():
        lo_s=float(np.nanmin(sv)); hi_s=float(np.nanmax(sv))
        if hi_s>lo_s:
            ss[finite_sv]=(sv[finite_sv]-lo_s)/(hi_s-lo_s)
        else:
            ss[finite_sv]=1.0
    es=cand.elbow_strength.to_numpy(float)
    combined=0.5*es+0.5*ss
    d.loc[cand.index,"silhouette_strength"]=ss
    d.loc[cand.index,"combined_score"]=combined
    ranked=pd.DataFrame({"k":cand.k.to_numpy(int),"combined":combined}).sort_values(["combined","k"],ascending=[False,True])
    best_k=int(ranked.iloc[0].k)
    basis=("standardized 4-D [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] vector (post-KG)" if cols==["P_evidence","r","c","Confidence_Score"] else f"standardized selected post-KG variables {cols}")
    d.attrs.update({"recommended_n":best_k,"best_k":best_k,"best_recommended_n":best_k,
                    "silhouette_recommended_n":sil_k,"elbow_recommended_n":elbow_k,
                    "combination_rule":"equal-weight mean of normalized geometric elbow strength and normalized silhouette strength; ties choose smaller k",
                    "basis":basis,"variables":list(cols)})
    if print_recommendations:
        print(f"Elbow-recommended cluster number: {elbow_k}")
        print(f"Silhouette-recommended cluster number: {sil_k}")
        print(f"Combined best cluster number: {best_k}")
    if show:
        fig,axes=plt.subplots(1,2,figsize=(14,5)); axes[0].plot(d.k,d.inertia,"o-"); axes[0].axvline(elbow_k,ls="--",label=f"Elbow: K={elbow_k}"); axes[0].set(xlabel="Number of clusters (K)",ylabel="Inertia (WCSS)",title="Elbow / inertia"); axes[0].set_xticks(d.k.astype(int)); axes[0].legend(); axes[0].grid(alpha=.25)
        sd=d[d.k>=2]; axes[1].plot(sd.k,sd.silhouette,"o-"); axes[1].axvline(sil_k,ls="--",label=f"Highest silhouette: K={sil_k}"); axes[1].set(xlabel="Number of clusters (K)",ylabel="Silhouette score",title="Silhouette diagnostic"); axes[1].set_xticks(sd.k.astype(int)); axes[1].legend(); axes[1].grid(alpha=.25); plt.tight_layout(); plt.show()
    return d

__all__=["KMeansPartition","diagnose_kmeans"]
