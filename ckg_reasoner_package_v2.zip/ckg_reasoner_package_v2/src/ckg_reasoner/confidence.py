from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import math
from .functions import positive_similarity_gate

ROLE_NAMES={1.0:'Pathognomonic',0.85:'Hallmark',0.70:'Major',0.50:'Supportive',0.30:'Associated',0.15:'Nonspecific',-0.50:'Exclusionary'}
CRITICAL_ROLES={1.0,0.85,0.70,-0.50}

@dataclass
class ConfidenceAssessment:
    disease: str
    evidence_coverage: float
    confidence_score: float
    confidence_level: str
    observed_weight: float
    total_weight: float
    missing_weight: float
    observed_features: int
    missing_features: int
    partial_features: int
    observed_components: int
    expected_components: int
    missing_components: int
    missing_pathognomonic: list[str]
    missing_hallmark: list[str]
    missing_major: list[str]
    missing_exclusionary: list[str]
    reason: str
    feature_rows: list[dict[str,Any]]
    def to_dict(self): return asdict(self)


def _component_availability(row: dict[str,Any]) -> tuple[int,int,float]:
    comps=row.get('components',{}) or {}
    expected=[]; observed=[]
    for name,c in comps.items():
        if name=='main':
            continue
        # A reference-defined component belongs to the canonical EFN.  Some legacy
        # activations mark matched components from_patient without repeating from_reference,
        # so accept either marker as evidence that this is a real component.
        if c.get('from_reference') or c.get('ref_value') is not None or c.get('reference_score') is not None or c.get('from_patient'):
            expected.append(name)
            v=c.get('patient_value')
            present=bool(c.get('from_patient')) and v not in (None,'')
            try:
                present=present and not (isinstance(v,float) and math.isnan(v))
            except Exception:
                pass
            if present: observed.append(name)
    ne=len(expected); no=len(observed)
    # Feature-level observed status is authoritative for legacy single/default EFNs.
    if ne==0:
        return (1 if row.get('observed',False) else 0),1,(1.0 if row.get('observed',False) else 0.0)
    return no,ne,no/ne


def _canonical_weight(row: dict[str,Any]) -> float:
    g=float(row.get('diagnostic_role',0.0) or 0.0)
    I=max(0.0,float(row.get('clinical_importance',0.0) or 0.0))
    S=max(0.0,float(row.get('support',0.0) or 0.0))
    C=abs(float(row.get('contradiction',0.0) or 0.0))
    # Positive roles use the exact canonical positive-evidence capacity already used
    # by the reasoner. Exclusionary roles have no positive capacity, so preserve their
    # decisive diagnostic role through canonical contradiction capacity.
    if g >= 0:
        return positive_similarity_gate(1.0)*max(g,0.0)*I*S
    return positive_similarity_gate(1.0)*abs(g)*max(C,I*S)


def assess_confidence(trace, high_threshold: float=.80, moderate_threshold: float=.50, eligible_features=None) -> ConfidenceAssessment:
    details=[]; total=observed_w=0.0; obs_c=exp_c=0; partial=0
    missing_by={1.0:[],0.85:[],0.70:[],-0.50:[]}
    eligible=set(eligible_features) if eligible_features is not None else None
    for r in trace.feature_rows:
        if eligible is not None and r.get('feature') not in eligible:
            continue
        no,ne,a=_component_availability(r); w=_canonical_weight(r)
        total += w; observed_w += a*w; obs_c += no; exp_c += ne
        status='observed' if a>=1-1e-12 else 'missing' if a<=1e-12 else 'partial'
        if status=='partial': partial+=1
        g=float(r.get('diagnostic_role',0.0) or 0.0)
        if a < 1.0 and g in missing_by:
            missing_by[g].append(str(r.get('name') or r.get('feature')))
        details.append({
            'feature':r.get('feature'),'name':r.get('name'),'diagnostic_role':g,
            'diagnostic_role_name':ROLE_NAMES.get(g,str(g)),'canonical_weight':w,
            'observed_components':no,'expected_components':ne,'availability_fraction':a,
            'coverage_contribution':a*w,'missing_weight':(1-a)*w,'status':status,
        })
    coverage=(observed_w/total) if total>0 else 0.0
    coverage=float(max(0.0,min(1.0,coverage)))
    level='High' if coverage>=high_threshold else 'Moderate' if coverage>=moderate_threshold else 'Low'
    missing_weight=max(0.0,total-observed_w)
    critical=[]
    for role in (1.0,0.85,0.70,-0.50):
        if missing_by[role]: critical.append(f"{ROLE_NAMES[role]}: {', '.join(missing_by[role])}")
    reason=(f"{coverage*100:.1f}% of canonical diagnostic evidence weight is observed; "
            f"{(1-coverage)*100:.1f}% is unavailable or partially unavailable.")
    if critical: reason += ' Critical unresolved evidence — ' + '; '.join(critical) + '.'
    else: reason += ' No Pathognomonic/Hallmark/Major/Exclusionary EFN is unresolved.'
    return ConfidenceAssessment(
        disease=trace.disease,evidence_coverage=coverage,confidence_score=coverage,
        confidence_level=level,observed_weight=observed_w,total_weight=total,missing_weight=missing_weight,
        observed_features=int(trace.observed_features),missing_features=int(trace.missing_features),partial_features=partial,
        observed_components=obs_c,expected_components=exp_c,missing_components=max(0,exp_c-obs_c),
        missing_pathognomonic=missing_by[1.0],missing_hallmark=missing_by[0.85],missing_major=missing_by[0.70],
        missing_exclusionary=missing_by[-0.50],reason=reason,feature_rows=details)
