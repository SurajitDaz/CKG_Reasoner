"""Fixed-threshold hard assignment on a target CKG disease score."""
from .separation import HardAssignment
__all__=["HardAssignment"]
