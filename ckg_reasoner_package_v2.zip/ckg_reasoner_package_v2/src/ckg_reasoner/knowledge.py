from __future__ import annotations
from pathlib import Path
from importlib.resources import files
from typing import Any
import yaml
import copy

FILE_TYPES = ("laboratory", "manifestation", "progression", "severity")


def _deep_fill(defaults: dict, explicit: dict | None) -> dict:
    """Return explicit metadata with every missing node filled from defaults.

    Explicit YAML values always win. Nested mappings (e.g. maintenance) are
    filled recursively. This affects metadata resolution only; it does not
    rewrite clinical criteria.
    """
    out = copy.deepcopy(defaults or {})
    for key, value in (explicit or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_fill(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _resolve_profile_metadata(feature: dict, defaults: dict) -> dict:
    feature = copy.deepcopy(feature)
    profile = feature.get("profile")
    if not isinstance(profile, dict):
        return feature
    for _, component in profile.items():
        if not isinstance(component, dict):
            continue
        component["metadata"] = _deep_fill(defaults, component.get("metadata"))
    return feature

class KnowledgeBase:
    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else Path(str(files("ckg_reasoner").joinpath("data/diseases")))
        self.reference_vectors: dict[str, dict[str, dict[str, Any]]] = {}
        defaults_path = self.path.parent.parent / "metadata_defaults.yaml"
        if not defaults_path.exists():
            defaults_path = Path(str(files("ckg_reasoner").joinpath("data/metadata_defaults.yaml")))
        raw_defaults = yaml.safe_load(defaults_path.read_text(encoding="utf-8")) if defaults_path.exists() else {}
        self.metadata_defaults = (raw_defaults or {}).get("metadata_defaults", {})
        self.disease_names: dict[str, str] = {}
        self.reload()

    def reload(self):
        self.reference_vectors.clear(); self.disease_names.clear()
        if not self.path.exists():
            raise FileNotFoundError(f"Knowledge-base directory not found: {self.path}")
        for folder in sorted(p for p in self.path.iterdir() if p.is_dir()):
            vectors = {}
            display_name = folder.name.title()
            for kind in FILE_TYPES:
                yp = folder / f"{folder.name.lower()}_{kind}.yaml"
                if not yp.exists():
                    continue
                data = yaml.safe_load(yp.read_text(encoding="utf-8")) or {}
                display_name = (data.get("disease") or {}).get("name", display_name)
                for code, feat in (data.get("features") or {}).items():
                    feat = _resolve_profile_metadata(feat, self.metadata_defaults)
                    ef = feat.get("expected_frequency", {})
                    ef = ef.get("value") if isinstance(ef, dict) else ef
                    vectors[f"{code}_{kind}"] = {
                        "feature_name": code,
                        "name": feat.get("name", code),
                        "source_file": yp.name,
                        "stage": data.get("stage", "unknown"),
                        "expected_frequency": ef,
                        **{k:v for k,v in feat.items() if k not in {"name","expected_frequency"}},
                    }
            if vectors:
                key = folder.name.lower()
                self.reference_vectors[key] = vectors
                self.disease_names[key] = display_name
        return self

    def audit(self) -> dict:
        yaml_files=list(self.path.glob("*/*.yaml")) if self.path.exists() else []
        return {"knowledge_base_path":str(self.path),"disease_graph_count":len(self.reference_vectors),"diseases":self.diseases,"yaml_file_count":len(yaml_files)}

    @property
    def diseases(self) -> list[str]:
        return [self.disease_names[k] for k in self.reference_vectors]

    def vectors(self, disease: str):
        key = self.resolve(disease)
        return self.reference_vectors[key]

    def resolve(self, disease: str) -> str:
        q = str(disease).strip().lower()
        for key, name in self.disease_names.items():
            if q in {key, name.lower()} or q == name.lower().replace(" fever", ""):
                return key
        raise KeyError(f"Unknown disease {disease!r}. Available: {self.diseases}")
