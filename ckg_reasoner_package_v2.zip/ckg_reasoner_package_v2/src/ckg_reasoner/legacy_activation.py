"""Compatibility activation functions from the audited CKG notebook."""
from __future__ import annotations
from typing import Dict, List, Tuple, Any, Optional, Union
import numpy as np

DEBUG_MODE = False

NORMAL_RANGES = {
    'HGB': {'min': 13.5, 'max': 17.5, 'unit': 'g/dl'},
    'NEU': {'min': 40, 'max': 70, 'unit': '%'},
    'LYM': {'min': 20, 'max': 40, 'unit': '%'},
    'MON': {'min': 2, 'max': 10, 'unit': '%'},
    'EOS': {'min': 1, 'max': 4, 'unit': '%'},
    'RBC': {'min': 4.5, 'max': 5.9, 'unit': 'million/μL'},
    'HCT': {'min': 41, 'max': 53, 'unit': '%'},
    'MCV': {'min': 80, 'max': 100, 'unit': 'fl'},
    'MCH': {'min': 27, 'max': 33, 'unit': 'pg'},
    'MCHC': {'min': 32, 'max': 36, 'unit': 'g/dl'},
    'RDW-CV': {'min': 11.5, 'max': 14.5, 'unit': '%'},
    'MTP': {'min': 150000, 'max': 450000, 'unit': '/cumm'},
    'MPV': {'min': 7.4, 'max': 10.4, 'unit': 'fl'},
    'PDW': {'min': 9.0, 'max': 17.0, 'unit': '%'},
    'PCT': {'min': 0.12, 'max': 0.40, 'unit': '%'},
    'LEU': {'min': 4500, 'max': 11000, 'unit': '/cumm'},
}

ENCODINGS = {
    'diagnostic_role': {
        'Pathognomonic': 1.0, 'Hallmark': 0.85, 'Major': 0.7,
        'Supportive': 0.5, 'Associated': 0.3, 'Nonspecific': 0.15,
        'Exclusionary': -0.5
    },
    'importance': {
        'Critical': 1.0, 'Major': 0.75, 'Moderate': 0.5, 'Minor': 0.25
    },
    'support': {
        'Decisive': 1.0, 'Strong': 0.8, 'Moderate': 0.6,
        'Slight': 0.3, 'None': 0.0
    },
    'contradiction': {
        'Decisive': -1.0, 'Strong': -0.7, 'Moderate': -0.4,
        'Mild': -0.2, 'None': 0.0
    },
    'expected_frequency': {
        'Almost_Always': 1.0, 'Very_Common': 0.8, 'Common': 0.6,
        'Occasional': 0.4, 'Rare': 0.2
    },
    'onset': {
        'sudden': 1.0, 'acute': 0.8, 'subacute': 0.6,
        'gradual': 0.4, 'insidious': 0.2, 'abrupt': 0.9
    },
    'severity': {
        'none': 0.0, 'mild': 0.25, 'moderate': 0.5,
        'severe': 0.75, 'very_severe': 1.0
    },
    'trend': {
        'decreased': 0.0, 'normal': 0.0, 'increased': 1.0
    },
    'result': {
        'positive': 1.0, 'detected': 1.0, 'present': 1.0,
        'negative': 0.0, 'absent': 0.0, 'not_detected': 0.0
    },
    'pattern': {
        'continuous': 1.0, 'intermittent': 0.6, 'remittent': 0.5,
        'cyclic': 0.3, 'biphasic': 0.4, 'quotidian': 0.35,
        'tertian': 0.3, 'quartan': 0.25
    },
    'location': {
        'retro_orbital': 1.0, 'joint': 1.0, 'muscle': 1.0,
        'head': 1.0, 'chest': 1.0, 'abdomen': 1.0,
        'back': 1.0, 'neck': 1.0
    },
    'type': {
        'maculopapular': 1.0, 'petechial': 1.0, 'vesicular': 1.0,
        'urticarial': 1.0, 'erythematous': 1.0
    },
    'art_severity': {
        'none': 0.0, 'mild': 0.25, 'moderate': 0.5,
        'severe': 0.75, 'very_severe': 1.0
    }
}

GAUSSIAN_PARAMS = {
    'temperature_c': {'mean': 39.5, 'std': 0.5, 'scaling': 1.0},
    'duration_days': {'mean': 4.5, 'std': 2.0, 'scaling': 1.0},
    'MTP': {'mean': 300000, 'std': 100000, 'scaling': 1.0},
    'LEU': {'mean': 7750, 'std': 2500, 'scaling': 1.0},
    'HGB': {'mean': 15.5, 'std': 1.5, 'scaling': 1.0},
    'NEU': {'mean': 55, 'std': 10, 'scaling': 1.0},
    'LYM': {'mean': 30, 'std': 8, 'scaling': 1.0},
    'EOS': {'mean': 2.5, 'std': 1.5, 'scaling': 1.0},
    'HCT': {'mean': 47, 'std': 5, 'scaling': 1.0},
    'MCH': {'mean': 30, 'std': 3, 'scaling': 1.0},
    'MCHC': {'mean': 34, 'std': 2, 'scaling': 1.0},
    'RDW': {'mean': 13, 'std': 2, 'scaling': 1.0},
    'MPV': {'mean': 9, 'std': 1.5, 'scaling': 1.0},
    'PDW': {'mean': 13, 'std': 3, 'scaling': 1.0},
    'PCT': {'mean': 0.26, 'std': 0.1, 'scaling': 1.0},
    'MCV': {'mean': 90, 'std': 8, 'scaling': 1.0},
    'RBC': {'mean': 5.2, 'std': 0.5, 'scaling': 1.0},
    'MON': {'mean': 6, 'std': 3, 'scaling': 1.0},
    'default': {'mean': 0, 'std': 1, 'scaling': 1.0}
}

def gaussian_function(value: float, mean: float, std: float, scaling_factor: float = 1.0) -> float:
    """Calculate Gaussian probability for a value."""
    if std == 0:
        return 1.0 if value == mean else 0.0

    exponent = -((value - mean) ** 2) / (2 * (std ** 2))
    result = (1 / (std * np.sqrt(2 * np.pi))) * np.exp(exponent)
    result = result * scaling_factor
    return min(1.0, max(0.0, result))

def get_feature_range(feature_name: str) -> Optional[Dict]:
    """Get the normal range for a laboratory feature."""
    # Direct match
    if feature_name.upper() in NORMAL_RANGES:
        return NORMAL_RANGES.get(feature_name.upper())

    # Map component names to feature names
    component_to_feature = {
        'platelet_count': 'MTP',
        'wbc': 'LEU',
        'hemoglobin_g_dl': 'HGB',
        'hemoglobin': 'HGB',
        'rbc': 'RBC',
        'mcv': 'MCV',
        'mch': 'MCH',
        'mchc': 'MCHC',
        'rdw': 'RDW-CV',
        'mpv': 'MPV',
        'pdw': 'PDW',
        'pct': 'PCT',
        'neutrophil_count': 'NEU',
        'lymphocyte_count': 'LYM',
        'monocyte_count': 'MON',
        'eosinophil_count': 'EOS',
    }

    mapped = component_to_feature.get(feature_name.lower())
    if mapped and mapped in NORMAL_RANGES:
        return NORMAL_RANGES[mapped]

    return None

def get_gaussian_params(component_name: str, ref_range: Dict = None) -> Dict:
    """Get Gaussian parameters for a component."""
    if component_name in GAUSSIAN_PARAMS:
        return GAUSSIAN_PARAMS[component_name]

    base_name = component_name.split('_')[0] if '_' in component_name else component_name
    if base_name in GAUSSIAN_PARAMS:
        return GAUSSIAN_PARAMS[base_name]

    if ref_range and 'min' in ref_range and 'max' in ref_range:
        mean = (ref_range['min'] + ref_range['max']) / 2
        std = (ref_range['max'] - ref_range['min']) / 2
        return {'mean': mean, 'std': std, 'scaling': 1.0}

    return GAUSSIAN_PARAMS['default']

def encode_value(value: Any) -> Union[float, Any]:
    """Encode a value using the ENCODINGS dictionary."""
    if value is None:
        return 0.0

    if isinstance(value, dict):
        for v in value.values():
            if isinstance(v, str):
                value = v
                break
        else:
            return value

    if not isinstance(value, str):
        return value

    value_lower = value.lower()

    for encoding_name, encoding_map in ENCODINGS.items():
        for key, encoded_val in encoding_map.items():
            if key.lower() == value_lower:
                return encoded_val

    return value

def calculate_l2_norm(values: List[float]) -> float:
    """Calculate L2 norm (Euclidean norm) of a list of values."""
    if not values:
        return 0.0
    return np.sqrt(sum(v ** 2 for v in values))

def parse_feature_key(key: str) -> Tuple[str, str]:
    """Parse a composite feature key."""
    if '_' in key:
        parts = key.split('_', 1)
        return parts[0], parts[1]
    return key, ''

def find_component_in_reference(component_name: str, ref_vector: Dict, feature_name: str = None) -> Tuple[str, Any]:
    """
    Find matching component in reference vector with fuzzy matching.
    Handles 'default' as a special case.
    """
    # ============================================================
    # NEW: Check for 'default' at feature level first
    # ============================================================
    if component_name == 'default' or component_name.lower() == 'default':
        if 'default' in ref_vector:
            return 'default', ref_vector['default']

    # Search inside 'profile'
    if 'profile' in ref_vector and isinstance(ref_vector['profile'], dict):
        profile = ref_vector['profile']

        # Direct match
        if component_name in profile:
            return component_name, profile[component_name]

        # Case-insensitive match
        component_lower = component_name.lower()
        for k, v in profile.items():
            if k.lower() == component_lower:
                return k, v

        # Fuzzy match - handle shortened names
        for k, v in profile.items():
            k_lower = k.lower()

            if k_lower.startswith(component_lower):
                return k, v
            if component_lower.startswith(k_lower):
                return k, v
            if component_lower in k_lower:
                return k, v
            if k_lower in component_lower:
                return k, v
            # Common abbreviations
            if 'period' in component_lower and 'periodicity' in k_lower:
                return k, v
            if 'associate' in component_lower and 'associated' in k_lower:
                return k, v
            if 'temp' in component_lower and 'temperature' in k_lower:
                return k, v
            if 'dur' in component_lower and 'duration' in k_lower:
                return k, v

    # Search outside profile
    skip_keys = ['profile', 'feature_name', 'name', 'source_file', 'stage', 'default']

    for k, v in ref_vector.items():
        if k in skip_keys:
            continue

        if k == component_name:
            return k, v
        if k.lower() == component_name.lower():
            return k, v

        k_lower = k.lower()
        if k_lower.startswith(component_name.lower()):
            return k, v
        if component_name.lower().startswith(k_lower):
            return k, v
        if component_name.lower() in k_lower:
            return k, v
        if k_lower in component_name.lower():
            return k, v

    return None, None

def extract_ref_value(ref_value: Any) -> Any:
    """
    Extract actual value from YAML structures that may be wrapped in 'value' or 'values' keys.
    Handles:
    - {'value': [24, 48, 72]} -> [24, 48, 72]
    - {'values': [24, 48, 72]} -> [24, 48, 72]
    - [24, 48, 72] -> [24, 48, 72]
    - {'min': 3, 'max': 30} -> {'min': 3, 'max': 30} (unchanged)
    """
    # If it's a dict with 'values' key (plural) - your YAML format
    if isinstance(ref_value, dict) and 'values' in ref_value:
        return ref_value['values']

    # If it's a dict with 'value' key (singular)
    if isinstance(ref_value, dict) and 'value' in ref_value:
        return ref_value['value']

    # If it's a range (min/max), return as is
    if isinstance(ref_value, dict) and 'min' in ref_value and 'max' in ref_value:
        return ref_value

    # If it's a categorical range (low_value/high_value), return as is
    if isinstance(ref_value, dict) and 'low_value' in ref_value and 'high_value' in ref_value:
        return ref_value

    # If it's already a list or other type, return as is
    return ref_value

def calculate_numeric_score(value: float, ref_value: Any, component_name: str = "") -> float:

    # Extract the actual value if it's wrapped in 'value' or 'values'
    ref_value = extract_ref_value(ref_value)

    # ============================================================
    # CASE 1: Handle categorical trends (decreased, normal, increased)
    # Score increases sharply when value moves OUTSIDE normal range
    # ============================================================
    if isinstance(ref_value, dict) and 'trend' in ref_value:
        trend_obj = ref_value['trend']
        trend = str(trend_obj.get('value') if isinstance(trend_obj, dict) else trend_obj).lower()

        # v0.9.5 reference semantics:
        # DReference is explicitly disease-favouring and takes priority.
        # NReference is the normal physiological interval.
        # Profile components that contain no reference key (for example fever
        # temperature min/max) retain their existing scoring behaviour.
        criterion = ref_value.get('DReference')
        if isinstance(criterion, dict) and criterion.get('threshold') is not None:
            threshold = float(criterion['threshold'])
            op = str(criterion.get('operator', '<' if trend == 'decreased' else '>')).strip()
            if trend == 'decreased' and op in ('<', '<='):
                if value >= threshold:
                    return 0.0
                distance = (threshold - value) / max(abs(threshold), 1e-12)
                return min(1.0, max(0.0, 1 - np.exp(-distance * 5)))
            if trend == 'increased' and op in ('>', '>='):
                if value <= threshold:
                    return 0.0
                distance = (value - threshold) / max(abs(threshold), 1e-12)
                return min(1.0, max(0.0, 1 - np.exp(-distance * 4)))

        # NReference is the normal physiological interval. It is used with
        # the declared trend to quantify abnormality, but is not itself a
        # disease-favouring interval.
        normal_range = ref_value.get('NReference')
        # Prefer a disease/component-specific range embedded in the YAML.
        # Fall back to the legacy global table for backward compatibility.
        if not normal_range:
            normal_range = get_feature_range(component_name.upper())

        if normal_range:
            min_val = normal_range['min']
            max_val = normal_range['max']

            if trend == 'decreased':
                # Score is 0 when within normal range
                # Score increases sharply as value goes below min_val
                if value >= min_val:
                    # Within or above normal range → not decreased
                    return 0.0
                else:
                    # Below normal range → score increases sharply
                    # At min_val: score = 0
                    # At min_val * 0.5: score ≈ 0.5
                    # At min_val * 0.3: score ≈ 1.0
                    # Use sigmoid-like sharp increase
                    distance = (min_val - value) / min_val  # 0 at min_val, 0.5 at half, 0.7 at 30%
                    # Sharp exponential increase
                    score = 1 - np.exp(-distance * 5)
                    return min(1.0, max(0.0, score))

            elif trend == 'increased':
                # Score is 0 when within normal range
                # Score increases sharply as value goes above max_val
                if value <= max_val:
                    # Within or below normal range → not increased
                    return 0.0
                else:
                    # Above normal range → score increases sharply
                    # At max_val: score = 0
                    # At max_val * 1.5: score ≈ 0.5
                    # At max_val * 2.0: score ≈ 1.0
                    distance = (value - max_val) / max_val  # 0 at max_val, 0.5 at 1.5x, 1.0 at 2x
                    score = 1 - np.exp(-distance * 4)
                    return min(1.0, max(0.0, score))

            elif trend == 'normal' or trend == 'no change':
                # Score is 1.0 when within normal range
                # Score decreases as value moves outside
                if min_val <= value <= max_val:
                    return 1.0
                else:
                    # Outside normal range → decrease score
                    if value < min_val:
                        distance = (min_val - value) / min_val
                    else:
                        distance = (value - max_val) / max_val
                    score = np.exp(-distance * 3)
                    return max(0.0, score)

        # If no normal range found, fall back to encoding
        encoded = encode_value(trend)
        if isinstance(encoded, (int, float)):
            return encoded
        return 0.0

    # ============================================================
    # CASE 2: Handle array/list values
    # ============================================================
    if isinstance(ref_value, list):
        def compare_values(val1, val2):
            if isinstance(val1, str) and isinstance(val2, str):
                return val1.lower() == val2.lower()
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                return abs(val1 - val2) < 0.01
            try:
                if isinstance(val1, str):
                    num1 = float(val1)
                else:
                    num1 = val1
                if isinstance(val2, str):
                    num2 = float(val2)
                else:
                    num2 = val2
                return abs(num1 - num2) < 0.01
            except (ValueError, TypeError):
                pass
            return str(val1).lower() == str(val2).lower()

        for v in ref_value:
            if compare_values(value, v):
                return 1.0
        return 0.0

    # ============================================================
    # CASE 3: Handle dictionary with min/max range
    # Inside = 1.0, Outside = Gaussian decrease
    # ============================================================
    if isinstance(ref_value, dict) and 'min' in ref_value and 'max' in ref_value:
        min_val = ref_value['min']
        max_val = ref_value['max']

        if isinstance(value, str):
            try:
                value = float(value)
            except ValueError:
                return 0.0

        if min_val <= value <= max_val:
            return 1.0

        params = get_gaussian_params(component_name, ref_value)
        return gaussian_function(value, params['mean'], params['std'], params.get('scaling', 1.0))

    # ============================================================
    # CASE 4: Handle single numeric value
    # ============================================================
    elif isinstance(ref_value, (int, float)):
        if isinstance(value, str):
            try:
                value = float(value)
            except ValueError:
                return 0.0
        return 1.0 if abs(ref_value - value) < 0.01 else 0.0

    # ============================================================
    # CASE 5: Handle string value (categorical)
    # ============================================================
    elif isinstance(ref_value, str):
        encoded = encode_value(ref_value)
        if isinstance(encoded, (int, float)):
            return encoded
        return 1.0 if str(value).lower() == ref_value.lower() else 0.0

    return 0.0

def get_all_reference_components(ref_vector: Dict) -> List[Tuple[str, Any]]:
    """
    Get all components from a reference vector.
    Includes profile components, default, and expected_frequency.
    Returns list of (component_name, ref_value) tuples.
    """
    components = []

    # Get default if present
    if 'default' in ref_vector:
        default_value = ref_vector['default']
        if default_value is not None:
            components.append(('default', default_value))

    # Get profile components
    if 'profile' in ref_vector and isinstance(ref_vector['profile'], dict):
        for key, value in ref_vector['profile'].items():
            components.append((key, value))

    # Get expected_frequency if present
    if 'expected_frequency' in ref_vector:
        expected_freq = ref_vector['expected_frequency']
        if expected_freq is not None:
            components.append(('expected_frequency', expected_freq))

    return components

def get_reference_component_score(ref_value: Any) -> float:
    """
    Calculate reference score for a component.
    For arrays/lists -> 1.0 (feature exists)
    For ranges (min/max) -> 1.0
    For trends (decreased/normal/increased) -> 1.0 (feature exists)
    For single values -> encode or return value
    """
    # Extract the actual value if it's wrapped in 'value' or 'values'
    ref_value = extract_ref_value(ref_value)

    # ============================================================
    # FIX: Handle trend values - they should have reference score = 1.0
    # ============================================================
    if isinstance(ref_value, dict) and 'trend' in ref_value:
        return 1.0  # Feature exists in reference

    # Array/list values get 1.0 (feature presence)
    if isinstance(ref_value, list):
        return 1.0

    # Range values get 1.0 (feature presence)
    if isinstance(ref_value, dict) and 'min' in ref_value and 'max' in ref_value:
        return 1.0

    # Categorical range (low_value/high_value) gets 1.0
    if isinstance(ref_value, dict) and 'low_value' in ref_value and 'high_value' in ref_value:
        return 1.0

    # Single numeric value
    if isinstance(ref_value, (int, float)):
        return ref_value

    # String value - encode it
    if isinstance(ref_value, str):
        encoded = encode_value(ref_value)
        if isinstance(encoded, (int, float)):
            return encoded
        return 1.0

    # Dict with 'value' field
    if isinstance(ref_value, dict) and 'value' in ref_value:
        if isinstance(ref_value['value'], list):
            return 1.0  # Array inside value
        encoded = encode_value(ref_value['value'])
        if isinstance(encoded, (int, float)):
            return encoded
        return 1.0

    return 0.0

def _construct_patient_single_reference(
    patient_data: Dict[str, Any],
    reference_vectors: Dict[str, Dict],
    debug: bool = DEBUG_MODE
) -> Dict[str, Dict]:
    """
    Construct patient scores and reference scores simultaneously using L2 norm.
    AND gate ONLY applied to 'default' components.
    """

    result = {}
    processed_features = set()

    skip_fields = ['id', 'IP_Number', 'Gender', 'Sex', 'Age', 'Residence_Area', 'DOA',
                  'Discharge_Date', 'Primary_Code', 'Diagnosis_Type', 'Target',
                  'Dengue_Outcome', 'Malaria_Outcome', 'Area', 'AreaType',
                  'HouseType', 'District']

    composite_features = {}
    simple_features = {}

    for key, value in patient_data.items():
        if key in skip_fields:
            continue

        if '_' in key:
            composite_features[key] = value
        else:
            simple_features[key] = value

    # Track patient-provided components per feature
    patient_provided_components = {}

    # Process composite features
    for key, value in composite_features.items():
        feature_name, component_name = parse_feature_key(key)

        # Find reference vector for this feature
        ref_vector = None
        ref_full_key = None

        for ref_key, vector in reference_vectors.items():
            if ref_key.startswith(feature_name):
                ref_vector = vector
                ref_full_key = ref_key
                break

        if ref_vector is None:
            continue

        # Initialize feature in result if not already
        if feature_name not in result:
            # Get encoded reference values
            dx_role = encode_value(ref_vector.get('diagnostic_role'))
            importance = encode_value(ref_vector.get('importance'))
            support = encode_value(ref_vector.get('support'))
            contradiction = encode_value(ref_vector.get('contradiction'))
            expected_freq = encode_value(ref_vector.get('expected_frequency'))

            # Get ALL reference components (profile + expected_frequency)
            all_ref_components = get_all_reference_components(ref_vector)

            result[feature_name] = {
                'patient_score': 0.0,
                'reference_score': 0.0,
                'components': {},
                'patient_values': {},
                'reference_metadata': {
                    'name': ref_vector.get('name', feature_name),
                    'stage': ref_vector.get('stage', 'unknown'),
                    'diagnostic_role': dx_role,
                    'importance': importance,
                    'support': support,
                    'contradiction': contradiction,
                    'expected_frequency': expected_freq,
                    'all_reference_components': all_ref_components,
                    'condition': ref_vector.get('condition')
                }
            }
            patient_provided_components[feature_name] = set()

        # Mark that patient provided this component
        if feature_name not in patient_provided_components:
            patient_provided_components[feature_name] = set()
        patient_provided_components[feature_name].add(component_name)

        # If component is expected_frequency, handle it specially
        if component_name in ['expected_frequency', 'frequency']:
            # Encode the patient's frequency value
            encoded_freq = encode_value(value)
            # Unknown frequency labels must not propagate as raw strings into
            # numerical geometry. They are treated as non-matching activation.
            if not isinstance(encoded_freq, (int, float, np.integer, np.floating)):
                encoded_freq = 0.0

            # Reference frequency score
            ref_freq_score = result[feature_name]['reference_metadata']['expected_frequency']

            # Add as a component
            result[feature_name]['components']['expected_frequency'] = {
                'patient_value': value,
                'patient_score': encoded_freq,
                'reference_score': ref_freq_score,
                'processing_type': 'FREQUENCY',
                'ref_value': ref_freq_score,
                'from_patient': True
            }
            result[feature_name]['patient_values']['expected_frequency'] = value
            processed_features.add(feature_name)
            continue

        # For other composite features (duration_days, temperature_c, period_hr, associate, etc.)
        matched_component, ref_value = find_component_in_reference(component_name, ref_vector)

        if matched_component is None:
            continue

        # Extract the actual value if it's wrapped in 'value' or 'values'
        ref_value = extract_ref_value(ref_value)

        patient_component_score = 0.0
        reference_component_score = 0.0
        # Always initialise this metadata field. Some real cohort values can
        # arrive as pandas/numpy scalar or missing-value types that do not
        # enter the legacy numeric/string branches below.
        processing_type = "UNSUPPORTED"

        # Convert string values to numbers if ref_value is a list of numbers
        if isinstance(value, str) and isinstance(ref_value, list):
            try:
                has_number = any(isinstance(v, (int, float)) for v in ref_value)
                if has_number:
                    if value.isdigit():
                        value = int(value)
                    else:
                        value = float(value)
            except (ValueError, AttributeError):
                pass

        # Calculate patient score. Boolean must be checked before numeric
        # because bool is a subclass of int in Python. Include NumPy scalars
        # because dataframe rows commonly contain np.integer/np.floating.
        if isinstance(value, (bool, np.bool_)):
            processing_type = "BOOLEAN"
            patient_component_score = 1.0 if bool(value) else 0.0

        elif isinstance(value, (int, float, np.integer, np.floating)):
            patient_component_score = calculate_numeric_score(float(value), ref_value, component_name)
            processing_type = "NUMERIC"

        elif isinstance(value, str):
            # Categorical patient values must become bounded numeric activations.
            # Unknown labels are compared to the candidate-specific reference rather
            # than being allowed to leak through encode_value() as raw strings.
            value_norm = value.strip().casefold()
            if isinstance(ref_value, list):
                patient_component_score = float(any(
                    str(v).strip().casefold() == value_norm for v in ref_value
                ))
                processing_type = "CATEGORICAL_ARRAY"
            elif isinstance(ref_value, str):
                patient_component_score = float(
                    value_norm == ref_value.strip().casefold()
                )
                processing_type = "CATEGORICAL_EQUAL"
            else:
                encoded = encode_value(value)
                patient_component_score = float(encoded) if isinstance(encoded, (int, float, np.integer, np.floating)) else 0.0
                processing_type = "CATEGORICAL"

        # Calculate reference score for this component
        reference_component_score = get_reference_component_score(ref_value)

        # Store component details
        result[feature_name]['components'][matched_component] = {
            'patient_value': value,
            'patient_score': patient_component_score,
            'reference_score': reference_component_score,
            'processing_type': processing_type,
            'ref_value': ref_value,
            'from_patient': True
        }
        result[feature_name]['patient_values'][matched_component] = value
        processed_features.add(feature_name)

    # ============================================================
    # PROCESS SIMPLE FEATURES (no underscore) - WITH DEFAULT SUPPORT
    # ============================================================
    for key, value in simple_features.items():
        if key in skip_fields or key in processed_features:
            continue

        ref_vector = None
        ref_full_key = None

        for ref_key, vector in reference_vectors.items():
            if ref_key.startswith(key):
                ref_vector = vector
                ref_full_key = ref_key
                break

        if ref_vector is None:
            continue

        # Initialize feature in result
        dx_role = encode_value(ref_vector.get('diagnostic_role'))
        importance = encode_value(ref_vector.get('importance'))
        support = encode_value(ref_vector.get('support'))
        contradiction = encode_value(ref_vector.get('contradiction'))
        expected_freq = encode_value(ref_vector.get('expected_frequency'))

        all_ref_components = get_all_reference_components(ref_vector)

        if key not in result:
            result[key] = {
                'patient_score': 0.0,
                'reference_score': 0.0,
                'components': {},
                'patient_values': {},
                'reference_metadata': {
                    'name': ref_vector.get('name', key),
                    'stage': ref_vector.get('stage', 'unknown'),
                    'diagnostic_role': dx_role,
                    'importance': importance,
                    'support': support,
                    'contradiction': contradiction,
                    'expected_frequency': expected_freq,
                    'all_reference_components': all_ref_components,
                    'condition': ref_vector.get('condition')
                }
            }

        # ============================================================
        # CHECK FOR FEATURE-LEVEL DEFAULT (outside profile)
        # ============================================================
        default_value = ref_vector.get('default')

        if default_value is not None:
            # Extract the actual value if wrapped
            default_value = extract_ref_value(default_value)

            if key not in patient_provided_components:
                patient_provided_components[key] = set()
            patient_provided_components[key].add('default')

            # ============================================================
            # Patient score = 1.0 if patient has data (value 0 or 1)
            # Reference score = value from YAML (0.0 or 1.0)
            # AND gate applied later during L2 norm calculation
            # ============================================================
            reference_component_score = get_reference_component_score(default_value)
            # A default component is a reference value, not a multiplicative
            # gate. Score the observed patient value against that reference.
            # This prevents default: 0 from annihilating the component solely
            # because the reference value is zero.
            profile = ref_vector.get('profile') or {}
            profile_values = [extract_ref_value(v) for v in profile.values()] if isinstance(profile, dict) else []
            if isinstance(value, (bool, np.bool_)) or (isinstance(value, (int, np.integer)) and value in (0, 1)):
                # Binary cohort columns conventionally encode presence/positivity.
                patient_component_score = float(bool(value))
            elif isinstance(value, (int, float, np.integer, np.floating)) and profile_values:
                patient_component_score = max(float(calculate_numeric_score(float(value), rv, 'default')) for rv in profile_values)
            elif isinstance(value, str) and profile_values:
                vn=value.strip().casefold()
                patient_component_score = float(any(vn == str(rv).strip().casefold() for rv in profile_values))
            elif isinstance(value, (int, float, np.integer, np.floating)):
                patient_component_score = float(calculate_numeric_score(float(value), default_value, 'default'))
            elif isinstance(value, str):
                patient_component_score = float(value.strip().casefold() == str(default_value).strip().casefold())
            else:
                patient_component_score = 0.0

            # Store component details
            result[key]['components']['default'] = {
                'patient_value': value,
                'patient_score': patient_component_score,
                'reference_score': reference_component_score,
                'processing_type': "BOOLEAN",
                'ref_value': default_value,
                'from_patient': True,
                'is_default': True
            }
            result[key]['patient_values']['default'] = value
            processed_features.add(key)
            continue

        # ============================================================
        # NO DEFAULT - Process the profile
        # ============================================================
        if key not in patient_provided_components:
            patient_provided_components[key] = set()
        patient_provided_components[key].add('main')

        patient_component_score = 0.0
        reference_component_score = 0.0
        processing_type = ""

        # Calculate patient score
        if isinstance(value, (bool, int)) and value in [0, 1, True, False]:
            processing_type = "BOOLEAN"
            patient_component_score = 1.0 if value in [1, True] else 0.0

        elif isinstance(value, (int, float)):
            processing_type = "NUMERIC"
            normal_range = get_feature_range(key)
            if normal_range:
                if normal_range['min'] <= value <= normal_range['max']:
                    patient_component_score = 1.0
                else:
                    params = get_gaussian_params(key, normal_range)
                    patient_component_score = gaussian_function(value, params['mean'], params['std'], params.get('scaling', 1.0))
            else:
                for k, v in ref_vector.items():
                    if k not in ['feature_name', 'name', 'source_file', 'profile', 'expected_frequency', 'stage', 'default']:
                        v = extract_ref_value(v)
                        if isinstance(v, list):
                            if value in v:
                                patient_component_score = 1.0
                            else:
                                for arr_val in v:
                                    if isinstance(arr_val, (int, float)) and abs(arr_val - value) < 0.01:
                                        patient_component_score = 1.0
                                        break
                            break
                        elif isinstance(v, dict) and 'min' in v and 'max' in v:
                            if v['min'] <= value <= v['max']:
                                patient_component_score = 1.0
                                break
                        elif isinstance(v, dict) and 'low_value' in v and 'high_value' in v:
                            low_encoded = encode_value(v['low_value'])
                            high_encoded = encode_value(v['high_value'])
                            if isinstance(low_encoded, (int, float)) and isinstance(high_encoded, (int, float)):
                                if low_encoded <= value <= high_encoded:
                                    patient_component_score = 1.0
                                    break
                        elif isinstance(v, (int, float)):
                            if abs(v - value) < 0.01:
                                patient_component_score = 1.0
                                break
                if patient_component_score == 0.0:
                    patient_component_score = 0.0

        elif isinstance(value, str):
            processing_type = "CATEGORICAL"
            # Loop through the ref_vector's top-level keys (like 'severity', 'type', etc.)
            for k, v in ref_vector.items():
                # Skip internal keys
                if k in ['feature_name', 'name', 'source_file', 'profile', 'expected_frequency', 'stage', 'default']:
                    continue
                # Extract the actual value from the profile
                v = extract_ref_value(v)

                # --- FIX: Check for low_value/high_value pattern ---
                if isinstance(v, dict) and 'low_value' in v and 'high_value' in v:
                    # This is a category range, e.g., low_value: "Moderate", high_value: "Severe"
                    # Check if the patient's value is within this category list
                    allowed_values = [v['low_value'], v['high_value']]
                    if value.lower() in [str(av).lower() for av in allowed_values]:
                        patient_component_score = 1.0
                        processing_type = "CATEGORICAL_RANGE"
                        break
                # --- END FIX ---

                # Keep the original list/array and single-value checks as fallbacks
                elif isinstance(v, list):
                    if value.lower() in [str(arr_val).lower() for arr_val in v]:
                        patient_component_score = 1.0
                        processing_type = "CATEGORICAL_ARRAY"
                        break
                elif isinstance(v, str):
                    if value.lower() == v.lower():
                        patient_component_score = 1.0
                        processing_type = "CATEGORICAL_EQUAL"
                        break
                # single numeric value check (keep for completeness, though unlikely here)
                elif isinstance(v, (int, float)):
                    # ... this check is primarily for numeric features, which wouldn't have a 'severity' profile ...
                    pass

            # If none of the checks matched, the score remains 0.0
            # (This is where your ROP and HDH were failing)
            if patient_component_score == 0.0:
                patient_component_score = encode_value(value)
                if patient_component_score == value:  # encode_value did nothing
                    patient_component_score = 0.0  # Keep as 0

        # Calculate reference score for this component
        for k, v in ref_vector.items():
            if k not in ['feature_name', 'name', 'source_file', 'profile', 'expected_frequency', 'stage', 'default']:
                # Use get_reference_component_score which handles this correctly
                reference_component_score = get_reference_component_score(v)
                # We should also ensure the reference score for the range is 1.0
                v = extract_ref_value(v)
                if isinstance(v, dict) and 'low_value' in v and 'high_value' in v:
                    reference_component_score = 1.0
                break

        result[key]['components']['main'] = {
            'patient_value': value,
            'patient_score': patient_component_score,
            'reference_score': reference_component_score,
            'processing_type': processing_type,
            'from_patient': True
        }
        result[key]['patient_values']['main'] = value
        processed_features.add(key)

    # ============================================================
    # ADD MISSING REFERENCE COMPONENTS (patient didn't provide)
    # ============================================================
    for feature_name, data in result.items():
        ref_vector = None
        for ref_key, vector in reference_vectors.items():
            if ref_key.startswith(feature_name):
                ref_vector = vector
                break

        if ref_vector is None:
            continue

        # Get all reference components
        all_ref_components = get_all_reference_components(ref_vector)

        # Get components patient provided
        provided = patient_provided_components.get(feature_name, set())

        for comp_name, ref_value in all_ref_components:
            # Skip if patient already provided this component
            if comp_name in provided:
                continue

            # Skip if already in components
            if comp_name in data['components']:
                continue

            # Calculate reference score
            reference_component_score = get_reference_component_score(ref_value)

            # Add missing component with patient_score = 0
            data['components'][comp_name] = {
                'patient_value': f"",
                'patient_score': 0.0,
                'reference_score': reference_component_score,
                'processing_type': 'MISSING',
                'ref_value': ref_value,
                'from_patient': False,
                'from_reference': True
            }
            data['patient_values'][comp_name] = ''

    # ============================================================
    # CALCULATE FINAL L2 NORMS
    # AND GATE ONLY APPLIED TO 'default' COMPONENTS
    # ============================================================
    for feature_name, data in result.items():
        if data['components']:
            # Collect reference scores for |E| - ALL components (except 'main')
            reference_scores = []
            reference_component_names = []

            # Collect patient scores for |P| - normal for non-default, AND for default
            patient_scores = []
            patient_component_names = []

            for comp_name, comp_data in data['components'].items():
                # Skip 'main' component
                if comp_name == 'main':
                    continue

                r_score = comp_data.get('reference_score', 0.0)
                p_score = comp_data.get('patient_score', 0.0)

                # Reference L2 norm: ALL components with non-zero ref scores
                if isinstance(r_score, (int, float)) and r_score > 0:
                    reference_scores.append(r_score)
                    reference_component_names.append(comp_name)

                # ============================================================
                # Patient |P|: AND gate ONLY for 'default' components
                # ============================================================
                if comp_name == 'default':
                    # Use the patient-reference match computed
                    # above. Do not multiply by the raw patient value or the
                    # reference default.
                    if isinstance(p_score, (int, float)) and p_score > 0:
                        patient_scores.append(p_score)
                        patient_component_names.append(comp_name)
                else:
                    # Normal: Patient score as-is
                    if isinstance(p_score, (int, float)) and p_score > 0:
                        patient_scores.append(p_score)
                        patient_component_names.append(comp_name)

            # Calculate L2 norm for reference scores (|E|)
            if reference_scores:
                data['reference_score'] = calculate_l2_norm(reference_scores)
            else:
                data['reference_score'] = 0.0

            # Calculate L2 norm for patient scores (|P|)
            if patient_scores:
                data['patient_score'] = calculate_l2_norm(patient_scores)
            else:
                data['patient_score'] = 0.0

    # If debug mode is on, print detailed vector components
    if debug:
        print_vector_components(result)

    return result


def construct_patient_with_reference_scores(
    patient_data: Dict[str, Any],
    reference_vectors: Dict[str, Dict],
    debug: bool = DEBUG_MODE
) -> Dict[str, Dict]:
    """Build stage-specific EFN activations without collapsing duplicate codes.

    Each reference-vector entry is evaluated independently against the same
    patient record.  The returned dictionary is keyed by the full reference
    key (for example ``VOM_manifestation`` and ``VOM_progression``), while
    ``feature_code`` preserves the patient-facing EFN code (``VOM``).
    """
    out: Dict[str, Dict] = {}
    for ref_key, ref_vector in reference_vectors.items():
        single = _construct_patient_single_reference(
            patient_data, {ref_key: ref_vector}, debug=False
        )
        feature_code = ref_vector.get('feature_name')
        if feature_code in single:
            data = single[feature_code]
            meta = data.setdefault('reference_metadata', {})
            meta['feature_code'] = feature_code
            meta['reference_key'] = ref_key
            meta['source_file'] = ref_vector.get('source_file')
            out[ref_key] = data
    if debug:
        print_vector_components(out)
    return out

def calculate_cosine_similarity(patient_vector: Dict, reference_vector: Dict) -> float:
    """Calculate cosine similarity between patient and reference vectors using L2 norm."""
    patient_values = []
    reference_values = []

    for key, value in patient_vector.items():
        if key in ['patient_score', 'reference_score', 'components', 'patient_values', 'reference_metadata']:
            continue
        if isinstance(value, (int, float)):
            patient_values.append(value)

    for key, value in reference_vector.items():
        if key in ['patient_score', 'reference_score', 'components', 'patient_values', 'reference_metadata']:
            continue
        if isinstance(value, (int, float)):
            reference_values.append(value)

    if len(patient_values) != len(reference_values):
        min_len = min(len(patient_values), len(reference_values))
        patient_values = patient_values[:min_len]
        reference_values = reference_values[:min_len]

    if not patient_values or sum(patient_values) == 0 or sum(reference_values) == 0:
        return 0.0

    dot_product = sum(a * b for a, b in zip(patient_values, reference_values))
    norm_patient = np.sqrt(sum(a * a for a in patient_values))
    norm_reference = np.sqrt(sum(b * b for b in reference_values))

    if norm_patient == 0 or norm_reference == 0:
        return 0.0

    return dot_product / (norm_patient * norm_reference)
