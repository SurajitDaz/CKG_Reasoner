from __future__ import annotations

from dataclasses import dataclass
from typing import Any
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


@dataclass
class SeparationResult:
    method: str
    assignments: pd.DataFrame
    diagnostics: pd.DataFrame | None = None
    metadata: dict | None = None


CLUSTERING_VARIABLES = ("P_evidence", "r", "c", "Confidence_Score")

def _score_frame(score_matrix: pd.DataFrame, target_disease: str, variables=None):
    """Validate the post-KG clustering frame and a user-selected subset of S0 coordinates."""
    if not isinstance(score_matrix, pd.DataFrame) or score_matrix.empty:
        raise ValueError("clustering_matrix must be a non-empty pandas DataFrame.")
    required = list(CLUSTERING_VARIABLES)
    if variables is None:
        selected = required.copy()
    else:
        if isinstance(variables, str): variables = [variables]
        selected = list(variables)
        if not selected: raise ValueError("variables must contain at least one clustering variable.")
        unknown = [c for c in selected if c not in required]
        if unknown: raise ValueError(f"Unknown clustering variable(s): {unknown}. Allowed: {required}.")
        if len(set(selected)) != len(selected): raise ValueError("variables must not contain duplicates.")
    missing = [c for c in required if c not in score_matrix.columns]
    if missing:
        raise KeyError(f"Clustering matrix is missing required component(s): {missing}. Expected [P_evidence, r, c, Confidence_Score].")
    sm = score_matrix[required].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    # Fitting uses only the user-selected coordinates. P_evidence/r/c are additionally
    # required for the pre-specified semantic ordering of discovered groups. An
    # unselected Confidence_Score must therefore never exclude an otherwise usable row.
    needed = list(dict.fromkeys(list(selected) + ["P_evidence", "r", "c"]))
    valid = sm.dropna(subset=needed, how="any")
    if len(valid) < 6:
        raise ValueError(f"At least 6 rows complete for clustering variables {selected} and ordering variables ['P_evidence', 'r', 'c'] are required.")
    if len(np.unique(np.round(valid[selected].to_numpy(float), 12), axis=0)) < 2:
        raise ValueError(f"The selected clustering vector {selected} is constant; separation is undefined.")
    return sm, valid, selected


def _target_score_frame(score_matrix: pd.DataFrame, target_disease: str):
    """Backward-compatible alias returning the 4-D evidence/similarity/confidence clustering frame."""
    sm, valid, _ = _score_frame(score_matrix, target_disease)
    return sm, valid


def _ordering_value(frame: pd.DataFrame) -> np.ndarray:
    """R(D_j) orders discovered groups; it is never a clustering coordinate."""
    pe=np.maximum(0.0,frame["P_evidence"].to_numpy(float))
    r=np.maximum(0.0,frame["r"].to_numpy(float))
    c=np.maximum(0.0,frame["c"].to_numpy(float))
    return pe + r + c


def _ordered_tags(labels_raw, ordering_values, k):
    means=[]
    for j in range(k):
        vals=np.asarray(ordering_values)[np.asarray(labels_raw)==j]
        means.append(float(np.mean(vals)) if len(vals) else np.nan)
    finite=[m for m in means if np.isfinite(m)]; fill=float(np.mean(finite)) if finite else 0.0
    sortable=np.array([fill if not np.isfinite(m) else m for m in means],dtype=float)
    order=np.argsort(sortable); remap={int(old):int(new) for new,old in enumerate(order)}
    labels=np.array([remap[int(v)] for v in labels_raw],dtype=int)
    tags=np.full(len(labels),"indeterminate",dtype=object); tags[labels==0]="negative"; tags[labels==k-1]="positive"
    return labels,[float(sortable[o]) for o in order],order


def auto_kmeans_scores(score_matrix: pd.DataFrame, target_disease: str, *,
                       min_k=3, max_k=10, random_state=42, n_init=20, n_clusters=None, variables=None) -> SeparationResult:
    """K-means on a user-selected subset of [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)].

    R(D_j) is NOT an input coordinate. It is retained only as an audit/order value
    after clusters have been learned in standardized selected-variable space.
    """
    _,valid,cols=_score_frame(score_matrix,target_disease,variables=variables); n=len(valid)
    scaler=StandardScaler(); z=scaler.fit_transform(valid[cols].to_numpy(float))
    unique_rows=len(np.unique(np.round(z,12),axis=0)); lo=max(2,int(min_k)); hi=min(int(max_k),unique_rows,n-1)
    if hi<lo: raise ValueError(f"K-means requires at least {lo} distinct selected-variable vectors {cols}.")
    diagnostics=[]; models={}
    for k in range(lo,hi+1):
        km=KMeans(n_clusters=k,random_state=random_state,n_init=n_init); raw=km.fit_predict(z)
        sil=float(silhouette_score(z,raw)) if len(np.unique(raw))>1 and n>k else np.nan
        diagnostics.append({"k":k,"inertia":float(km.inertia_),"silhouette":sil}); models[k]=(km,raw)
    diag=pd.DataFrame(diagnostics); finite=diag[np.isfinite(diag.silhouette)]
    recommended_k=int((finite if not finite.empty else diag).sort_values(["silhouette","k"],ascending=[False,True],na_position="last").iloc[0].k)
    selected_k=recommended_k if n_clusters is None else int(n_clusters)
    if selected_k not in models: raise ValueError(f"n_clusters must be between {lo} and {hi}; got {selected_k}.")
    km,raw=models[selected_k]; order_value=_ordering_value(valid); labels,ordered_means,order=_ordered_tags(raw,order_value,selected_k)
    tags=np.full(n,"indeterminate",dtype=object); tags[labels==0]="negative"; tags[labels==selected_k-1]="positive"
    centers_orig=scaler.inverse_transform(km.cluster_centers_)[order]
    a=valid.copy(); a["P_Evidence"]=a["P_evidence"]; a["Magnitude_Ratio_r"]=a["r"]; a["Cosine_c"]=a["c"]; a["Confidence"]=a["Confidence_Score"]; a["Target_Disease_Score"]=order_value
    a["KMeans_Cluster"]=labels; a["Cluster"]=labels
    names=["Low"]+[f"Intermediate {i}" for i in range(1,selected_k-1)]+["High"] if selected_k>2 else ["Low","High"]
    a["Cluster_Label"]=[names[int(c)] for c in labels]; a["Predicted_Result"]=tags
    return SeparationResult("kmeans",a,diag,{"selected_k":selected_k,"recommended_k":recommended_k,"selection_mode":"automatic" if n_clusters is None else "manual",
        "criterion":f"maximum silhouette score on standardized selected variables {cols}","target_disease":target_disease,
        "score_dimensions":cols,"available_score_dimensions":list(CLUSTERING_VARIABLES),"clustering_basis":f"selected post-KG S0 coordinates {cols}; ranking score R(D_j) is not used for fitting",
        "ordered_product_means":ordered_means,"ordered_target_score_means":ordered_means,"ordered_centers":centers_orig.tolist(),"random_state":random_state,"n_init":n_init})


def gaussian_separation(score_matrix: pd.DataFrame, target_disease: str, *, min_components=3,max_components=10,random_state=42,n_init=10,reg_covar=1e-6,n_components=None,variables=None)->SeparationResult:
    """GMM on a user-selected subset of [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)], selected by BIC."""
    _,valid,cols=_score_frame(score_matrix,target_disease,variables=variables); n=len(valid); scaler=StandardScaler(); z=scaler.fit_transform(valid[cols].to_numpy(float))
    unique_rows=len(np.unique(np.round(z,12),axis=0)); lo=max(2,int(min_components)); hi=min(int(max_components),unique_rows,max(lo,n//3))
    if hi<lo: raise ValueError(f"Gaussian mixture requires at least {lo} distinct selected-variable vectors {cols}.")
    rows=[]; models={}
    for k in range(lo,hi+1):
        gm=GaussianMixture(n_components=k,covariance_type="full",random_state=random_state,n_init=n_init,reg_covar=reg_covar).fit(z)
        rows.append({"k":k,"bic":float(gm.bic(z)),"aic":float(gm.aic(z)),"converged":bool(gm.converged_),"iterations":int(gm.n_iter_)}); models[k]=gm
    diag=pd.DataFrame(rows); recommended_k=int(diag.sort_values(["bic","k"]).iloc[0].k); selected_k=recommended_k if n_components is None else int(n_components)
    if selected_k not in models: raise ValueError(f"n_components must be between {lo} and {hi}; got {selected_k}.")
    gm=models[selected_k]; posterior_raw=gm.predict_proba(z); raw=posterior_raw.argmax(axis=1); means_orig=scaler.inverse_transform(gm.means_)
    order_value=_ordering_value(valid); product_means=np.array([float(np.mean(order_value[raw==j])) if np.any(raw==j) else np.nan for j in range(selected_k)]); order=np.argsort(np.nan_to_num(product_means,nan=np.nanmean(product_means))); remap={int(old):int(new) for new,old in enumerate(order)}
    labels=np.array([remap[int(v)] for v in raw]); posterior=posterior_raw[:,order]; membership=posterior[np.arange(n),labels]
    tags=np.full(n,"indeterminate",dtype=object); tags[labels==0]="negative"; tags[labels==selected_k-1]="positive"
    ordered_means=means_orig[order]; ordered_cov=np.asarray(gm.covariances_)[order]; ordered_weights=gm.weights_[order]
    a=valid.copy(); a["P_Evidence"]=a.P_evidence; a["Magnitude_Ratio_r"]=a.r; a["Cosine_c"]=a.c; a["Confidence"]=a.Confidence_Score; a["Target_Disease_Score"]=_ordering_value(valid)
    a["Gaussian_Component"]=labels; a["Gaussian_Component_Target_Mean"]=np.asarray(product_means)[order][labels]; a["Gaussian_Posterior"]=membership; a["Predicted_Result"]=tags
    return SeparationResult("gaussian",a,diag,{"selected_k":selected_k,"recommended_k":recommended_k,"selection_mode":"automatic" if n_components is None else "manual",
        "criterion":f"minimum BIC in standardized selected-variable space {cols}","target_disease":target_disease,"score_dimensions":cols,"available_score_dimensions":list(CLUSTERING_VARIABLES),
        "clustering_basis":f"selected post-KG S0 coordinates {cols}; ranking score R(D_j) is not used for fitting","ordered_component_means":ordered_means.tolist(),
        "ordered_product_means":np.asarray(product_means)[order].tolist(),"ordered_target_score_means":np.asarray(product_means)[order].tolist(),
        "ordered_component_weights":ordered_weights.tolist(),"ordered_component_covariances_standardized":ordered_cov.tolist(),
        "ordered_target_variances":[float(np.nan) for _ in range(selected_k)],"random_state":random_state,"n_init":n_init})


def mahalanobis_separation(score_matrix: pd.DataFrame, target_disease: str, *, min_clusters=3,max_clusters=10,random_state=42,n_init=20,ridge=1e-6,n_clusters=None,variables=None)->SeparationResult:
    """Covariance-aware Mahalanobis clustering on selected post-KG S0 coordinates.

    ``variables=None`` uses all four eligible coordinates.  A supplied non-empty
    subset changes only the clustering/distance geometry; semantic ordering remains
    based on the established P_evidence + r + c ordering value.
    """
    _,valid,cols=_score_frame(score_matrix,target_disease,variables=variables); n=len(valid)
    x=valid[cols].to_numpy(float); scaler=StandardScaler(); z=scaler.fit_transform(x)
    unique_rows=len(np.unique(np.round(z,12),axis=0)); lo=max(2,int(min_clusters)); hi=min(int(max_clusters),unique_rows,n-1)
    if hi<lo: raise ValueError(f"Mahalanobis partitioning requires at least {lo} candidate clusters from selected variables {cols}.")
    rows=[]; models={}
    for k in range(lo,hi+1):
        km=KMeans(n_clusters=k,random_state=random_state,n_init=n_init); raw=km.fit_predict(z)
        sil=float(silhouette_score(z,raw)) if len(np.unique(raw))>1 and n>k else np.nan
        rows.append({"k":k,"inertia":float(km.inertia_),"silhouette":sil}); models[k]=(km,raw)
    diag=pd.DataFrame(rows); finite=diag[np.isfinite(diag.silhouette)]; recommended_k=int((finite if not finite.empty else diag).sort_values(["silhouette","k"],ascending=[False,True]).iloc[0].k)
    selected_k=recommended_k if n_clusters is None else int(n_clusters)
    if selected_k not in models: raise ValueError(f"n_clusters must be between {lo} and {hi}; got {selected_k}.")
    _,raw=models[selected_k]; centroids=np.vstack([x[raw==j].mean(axis=0) for j in range(selected_k)])
    residuals=np.vstack([x[raw==j]-centroids[j] for j in range(selected_k) if np.any(raw==j)]); cov=np.atleast_2d(np.cov(residuals,rowvar=False)).astype(float)
    scale=float(np.trace(cov)/max(cov.shape[0],1)) if cov.size else 1.0; cov=cov+np.eye(cov.shape[0])*max(ridge,ridge*max(scale,1.0)); inv=np.linalg.pinv(cov)
    distances=np.empty((n,selected_k))
    for j in range(selected_k):
        delta=x-centroids[j]; distances[:,j]=np.sqrt(np.maximum(0,np.einsum("ij,jk,ik->i",delta,inv,delta)))
    assigned=distances.argmin(axis=1); ordering=_ordering_value(valid)
    cluster_means=[float(np.mean(ordering[assigned==j])) if np.any(assigned==j) else float('nan') for j in range(selected_k)]
    order=np.argsort(np.nan_to_num(cluster_means,nan=np.inf)); remap={int(old):int(new) for new,old in enumerate(order)}; labels=np.array([remap[int(v)] for v in assigned])
    tags=np.full(n,"indeterminate",dtype=object); tags[labels==0]="negative"; tags[labels==selected_k-1]="positive"
    sim=np.exp(-.5*np.square(distances)); denom=sim.sum(axis=1,keepdims=True); soft=np.divide(sim,denom,out=np.zeros_like(sim),where=denom>0)
    a=valid.copy(); a["P_Evidence"]=a.P_evidence; a["Magnitude_Ratio_r"]=a.r; a["Cosine_c"]=a.c; a["Confidence"]=a.Confidence_Score; a["Target_Disease_Score"]=ordering; a["Mahalanobis_Cluster"]=labels
    a["Mahalanobis_Distance"]=distances[np.arange(n),assigned]; a["Mahalanobis_Relative_Proximity"]=soft[np.arange(n),assigned]; a["Predicted_Result"]=tags
    return SeparationResult("mahalanobis",a,diag,{"selected_k":selected_k,"recommended_k":recommended_k,"selection_mode":"automatic" if n_clusters is None else "manual",
        "criterion":f"silhouette-selected reference groups followed by minimum Mahalanobis distance in standardized selected-variable space {cols}","target_disease":target_disease,
        "score_dimensions":cols,"available_score_dimensions":list(CLUSTERING_VARIABLES),"clustering_basis":f"selected post-KG S0 coordinates {cols}; variables=None uses all four; ranking score R(D_j) is not used for fitting",
        "ordered_product_means":[float(cluster_means[o]) for o in order],"ordered_target_score_means":[float(cluster_means[o]) for o in order],"pooled_covariance_matrix":cov.tolist(),"ordered_reference_centroids":centroids[order].tolist(),"random_state":random_state,"n_init":n_init})


def auto_kmeans_1d(scores, *, min_k=2, max_k=10, random_state=42, n_init=20) -> SeparationResult:
    """Legacy 1-D K-means helper for backward compatibility only.

    New disease clustering must use ``auto_kmeans_scores`` with the 3-D
    [P_evidence(D_j), r_j, c_j] vector. This helper intentionally remains independent
    so old notebooks cannot accidentally enter the new 3-D validator.
    """
    s = pd.to_numeric(pd.Series(scores), errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
    n, unique = len(s), int(s.nunique())
    lo, hi = max(2, int(min_k)), min(int(max_k), unique, n - 1)
    if hi < lo:
        raise ValueError(f"Legacy 1-D K-means requires at least {lo} usable distinct scores.")
    scaler = StandardScaler(); z = scaler.fit_transform(s.to_numpy().reshape(-1, 1))
    rows=[]; fits={}
    for k in range(lo, hi+1):
        km=KMeans(n_clusters=k, random_state=random_state, n_init=n_init); raw=km.fit_predict(z)
        sil=float(silhouette_score(z, raw)) if len(np.unique(raw))>1 and n>k else np.nan
        rows.append({"k":k,"inertia":float(km.inertia_),"silhouette":sil}); fits[k]=(km,raw)
    diag=pd.DataFrame(rows); finite=diag[np.isfinite(diag.silhouette)]
    chosen=int((finite if not finite.empty else diag).sort_values(["silhouette","k"],ascending=[False,True],na_position="last").iloc[0].k)
    km,raw=fits[chosen]; centers=scaler.inverse_transform(km.cluster_centers_).ravel(); order=np.argsort(centers)
    remap={int(old):int(new) for new,old in enumerate(order)}; lab=np.array([remap[int(v)] for v in raw])
    labels_text={i:("Low" if i==0 else "High" if i==chosen-1 else f"Intermediate {i}") for i in range(chosen)}
    a=pd.DataFrame({"Best_Score":s.values,"Cluster":lab,"Cluster_Label":[labels_text[int(v)] for v in lab]},index=s.index)
    return SeparationResult("kmeans",a,diag,{"selected_k":chosen,"criterion":"maximum silhouette score (legacy 1-D helper)","centers":centers[order].tolist(),"random_state":random_state,"n_init":n_init})


class BasePartitionMethod:
    """Estimator-style post-KG partitioning interface.

    fit() accepts only disease-support scores. Ground-truth labels are intentionally not
    part of the method API. A fitted object can be passed to model.evaluate(),
    model.evalute_tag()/evaluate_tag(), and model.output().
    """
    name = "base"
    def __init__(self):
        self.fitted_ = False
        self.assignments_ = None
        self.diagnostics_ = None
        self.metadata_ = {}
        self.target_disease_ = None
        self.score_dimensions_ = []
        self.score_matrix_ = None
    def fit(self, score_matrix: pd.DataFrame, target_disease: str):
        raise NotImplementedError
    def get_params(self):
        return {k:v for k,v in self.__dict__.items() if not k.endswith("_")}
    def __repr__(self):
        params=", ".join(f"{k}={v!r}" for k,v in self.get_params().items())
        return f"{self.__class__.__name__}({params})"
    @property
    def predictions_(self):
        if not self.fitted_: raise RuntimeError("Partition method is not fitted.")
        return self.assignments_["Predicted_Result"].copy()
    @property
    def labels_(self):
        return self.predictions_
    @property
    def n_partitions_(self):
        return self.metadata_.get("selected_k")
    @property
    def centers_(self):
        return self.metadata_.get("ordered_centers", self.metadata_.get("ordered_component_means", self.metadata_.get("ordered_reference_centroids")))
    def _fit_from_result(self, score_matrix, target_disease, res):
        self.score_matrix_ = score_matrix.copy()
        self.target_disease_ = target_disease
        self.assignments_ = res.assignments.copy()
        self.diagnostics_ = None if res.diagnostics is None else res.diagnostics.copy()
        self.metadata_ = dict(res.metadata or {})
        self.score_dimensions_ = list(self.metadata_.get("score_dimensions", []))
        self.fitted_ = True
        return self
    def visualize(self, y_true=None):
        if not self.fitted_: raise RuntimeError("Fit the method before visualize().")
        from .visualization import visualize_partition
        self.visualization_summary_ = visualize_partition(self, y_true=y_true)
        return self


class HardAssignment(BasePartitionMethod):
    name = "hard"
    def __init__(self, negative_threshold=0.20, positive_threshold=0.80):
        super().__init__(); self.negative_threshold=float(negative_threshold); self.positive_threshold=float(positive_threshold)
        if not self.negative_threshold < self.positive_threshold:
            raise ValueError("negative_threshold must be smaller than positive_threshold.")
    def fit(self, score_matrix, target_disease):
        if target_disease not in score_matrix.columns: raise KeyError(target_disease)
        s=pd.to_numeric(score_matrix[target_disease],errors="coerce")
        pred=np.full(len(s),"indeterminate",dtype=object)
        arr=s.to_numpy(float); pred[np.isfinite(arr)&(arr<=self.negative_threshold)]="negative"; pred[np.isfinite(arr)&(arr>=self.positive_threshold)]="positive"
        a=pd.DataFrame({"Target_Disease_Score":s,"Predicted_Result":pred},index=score_matrix.index)
        res=SeparationResult("hard",a,None,{"target_disease":target_disease,"negative_threshold":self.negative_threshold,"positive_threshold":self.positive_threshold,"score_dimensions":[target_disease]})
        return self._fit_from_result(score_matrix,target_disease,res)


class KMeansPartition(BasePartitionMethod):
    name = "kmeans"
    def __init__(self, n_clusters=None, min_clusters=3, max_clusters=10, random_state=42, n_init=20, variables=None):
        super().__init__(); self.n_clusters=n_clusters; self.min_clusters=min_clusters; self.max_clusters=max_clusters; self.random_state=random_state; self.n_init=n_init; self.variables=variables
    def fit(self, score_matrix, target_disease):
        return self._fit_from_result(score_matrix,target_disease,auto_kmeans_scores(score_matrix,target_disease,min_k=self.min_clusters,max_k=self.max_clusters,random_state=self.random_state,n_init=self.n_init,n_clusters=self.n_clusters,variables=self.variables))


class GaussianPartition(BasePartitionMethod):
    name = "gaussian"
    def __init__(self, n_components=None, min_components=3, max_components=10, random_state=42, n_init=10, reg_covar=1e-6, variables=None):
        super().__init__(); self.n_components=n_components; self.min_components=min_components; self.max_components=max_components; self.random_state=random_state; self.n_init=n_init; self.reg_covar=reg_covar; self.variables=variables
    def fit(self, score_matrix, target_disease):
        return self._fit_from_result(score_matrix,target_disease,gaussian_separation(score_matrix,target_disease,min_components=self.min_components,max_components=self.max_components,random_state=self.random_state,n_init=self.n_init,reg_covar=self.reg_covar,n_components=self.n_components,variables=self.variables))
    @property
    def posterior_probabilities_(self):
        if not self.fitted_: raise RuntimeError("Partition method is not fitted.")
        return self.assignments_.get("Gaussian_Posterior")
    @property
    def bic_scores_(self):
        if self.diagnostics_ is None: return None
        return self.diagnostics_.set_index("k")["bic"].copy()


class MahalanobisPartition(BasePartitionMethod):
    name = "mahalanobis"
    def __init__(self, n_clusters=None, min_clusters=3, max_clusters=10, random_state=42, n_init=20, ridge=1e-6, variables=None):
        super().__init__(); self.n_clusters=n_clusters; self.min_clusters=min_clusters; self.max_clusters=max_clusters; self.random_state=random_state; self.n_init=n_init; self.ridge=ridge; self.variables=variables
    def fit(self, score_matrix, target_disease):
        return self._fit_from_result(score_matrix,target_disease,mahalanobis_separation(score_matrix,target_disease,min_clusters=self.min_clusters,max_clusters=self.max_clusters,random_state=self.random_state,n_init=self.n_init,ridge=self.ridge,n_clusters=self.n_clusters,variables=self.variables))
    @property
    def mahalanobis_distances_(self):
        if not self.fitted_: raise RuntimeError("Partition method is not fitted.")
        return self.assignments_.get("Mahalanobis_Distance")


def _visualize_method(method: BasePartitionMethod):
    """Generate method-specific visual outputs using disease-score data only."""
    a=method.assignments_; target=method.target_disease_
    # 1) Target-score distribution by final three-way label.
    plt.figure(figsize=(10,6))
    for lab in ["negative","indeterminate","positive"]:
        vals=pd.to_numeric(a.loc[a["Predicted_Result"]==lab,"Target_Disease_Score"],errors="coerce").dropna()
        if len(vals): plt.hist(vals,bins=30,alpha=.55,label=lab)
    plt.xlabel(f"{target} diagnostic-support score"); plt.ylabel("Frequency")
    plt.title(f"{method.name.title()} partition: target disease-score distribution")
    plt.legend(); plt.grid(alpha=.25); plt.show()

    # 2) Disease-score-space projection (only adaptive multivariate methods).
    dims=[c for c in method.score_dimensions_ if c in method.score_matrix_.columns]
    if method.name != "hard" and len(dims)>=2:
        x=method.score_matrix_.loc[a.index,dims].apply(pd.to_numeric,errors="coerce").dropna()
        aa=a.loc[x.index]
        z=StandardScaler().fit_transform(x)
        p=PCA(n_components=2).fit_transform(z)
        plt.figure(figsize=(9,7))
        for lab in ["negative","indeterminate","positive"]:
            m=(aa["Predicted_Result"]==lab).to_numpy()
            if m.any(): plt.scatter(p[m,0],p[m,1],s=18,alpha=.6,label=lab)
        plt.xlabel("Score-space PC1"); plt.ylabel("Score-space PC2")
        plt.title(f"{method.name.title()} partition in multivariate disease-score space")
        plt.legend(); plt.grid(alpha=.25); plt.show()

    # 3) Method-specific target-score visualization.
    if method.name=="hard":
        plt.figure(figsize=(10,6))
        vals=pd.to_numeric(a["Target_Disease_Score"],errors="coerce").dropna()
        plt.hist(vals,bins=40,alpha=.6)
        plt.axvline(method.negative_threshold,linestyle="--",label=f"Negative threshold={method.negative_threshold:.2f}")
        plt.axvline(method.positive_threshold,linestyle="--",label=f"Positive threshold={method.positive_threshold:.2f}")
        plt.xlabel(f"{target} diagnostic-support score"); plt.ylabel("Frequency")
        plt.title("Hard-assignment decision boundaries"); plt.legend(); plt.grid(alpha=.25); plt.show()
    elif method.name=="kmeans":
        plt.figure(figsize=(10,6))
        vals=pd.to_numeric(a["Target_Disease_Score"],errors="coerce").dropna()
        plt.hist(vals,bins=40,alpha=.5)
        for j,mu in enumerate(method.metadata_["ordered_target_score_means"]):
            plt.axvline(mu,linestyle="--",label=f"Partition {j+1} mean={mu:.3f}")
        plt.xlabel(f"{target} diagnostic-support score"); plt.ylabel("Frequency")
        plt.title("K-means target-score regions"); plt.legend(); plt.grid(alpha=.25); plt.show()
    elif method.name=="gaussian":
        vals=pd.to_numeric(a["Target_Disease_Score"],errors="coerce").dropna().to_numpy(float)
        if len(vals):
            grid=np.linspace(float(np.min(vals)),float(np.max(vals)),500)
            means=np.asarray(method.metadata_["ordered_target_score_means"],float)
            vars_=np.asarray(method.metadata_["ordered_target_variances"],float)
            weights=np.asarray(method.metadata_["ordered_component_weights"],float)
            total=np.zeros_like(grid)
            plt.figure(figsize=(10,6)); plt.hist(vals,bins=40,density=True,alpha=.35)
            for j,(mu,var,w) in enumerate(zip(means,vars_,weights)):
                sd=max(float(np.sqrt(max(var,1e-12))),1e-9)
                dens=w*np.exp(-0.5*((grid-mu)/sd)**2)/(sd*np.sqrt(2*np.pi))
                total+=dens; plt.plot(grid,dens,label=f"Component {j+1}: mean={mu:.3f}")
            plt.plot(grid,total,linewidth=2,label="Mixture marginal density")
            plt.xlabel(f"{target} diagnostic-support score"); plt.ylabel("Density")
            plt.title("Gaussian-mixture target-score marginal components")
            plt.legend(); plt.grid(alpha=.25); plt.show()
    elif method.name=="mahalanobis":
        plt.figure(figsize=(10,6))
        for lab in ["negative","indeterminate","positive"]:
            vals=pd.to_numeric(a.loc[a["Predicted_Result"]==lab,"Mahalanobis_Distance"],errors="coerce").dropna()
            if len(vals): plt.hist(vals,bins=30,alpha=.5,label=lab)
        plt.xlabel("Mahalanobis distance to assigned reference group"); plt.ylabel("Frequency")
        plt.title("Mahalanobis assignment-distance distribution")
        plt.legend(); plt.grid(alpha=.25); plt.show()

    # 4) Automatic model-selection diagnostics.
    d=method.diagnostics_
    if d is not None and len(d):
        if method.name in {"kmeans","mahalanobis"}:
            plt.figure(figsize=(9,6)); plt.plot(d["k"],d["silhouette"],"o-")
            plt.axvline(method.metadata_["selected_k"],linestyle="--",label=f"Selected K={method.metadata_['selected_k']}")
            plt.xlabel("Number of partitions (K)"); plt.ylabel("Silhouette score")
            plt.title(f"Automatic K selection: {method.name.title()}")
            plt.legend(); plt.grid(alpha=.25); plt.show()
        elif method.name=="gaussian":
            plt.figure(figsize=(9,6)); plt.plot(d["k"],d["bic"],"o-",label="BIC"); plt.plot(d["k"],d["aic"],"o-",label="AIC")
            plt.axvline(method.metadata_["selected_k"],linestyle="--",label=f"Selected K={method.metadata_['selected_k']}")
            plt.xlabel("Gaussian components (K)"); plt.ylabel("Information criterion")
            plt.title("Automatic Gaussian component selection")
            plt.legend(); plt.grid(alpha=.25); plt.show()
