"""Visualization family for fitted CKG score-only partition methods."""
from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


def _cluster_col(method):
    return {"kmeans":"KMeans_Cluster","gaussian":"Gaussian_Component","mahalanobis":"Mahalanobis_Cluster"}.get(method.name)



def _kmeans_four_panel(method, y_true=None):
    """Historical CKG-style four-panel K-means visualization only."""
    a=method.assignments_.copy(); target=method.target_disease_; cc="KMeans_Cluster"
    order=(a.groupby(cc)["Target_Disease_Score"].mean().sort_values().index.tolist())
    # assignments are already ordered low -> high, but keep this robust.
    label_map={}
    k=len(order)
    for pos,c in enumerate(order):
        if k==3:
            lab=["Very Low","High","Very High"][pos]
        elif pos==0: lab="Low"
        elif pos==k-1: lab="High"
        else: lab=f"Intermediate {pos}"
        label_map[c]=lab

    fig,axes=plt.subplots(2,2,figsize=(15,10))

    # (a) Histogram, with cluster mean/count annotation.
    ax=axes[0,0]
    for c in order:
        vals=pd.to_numeric(a.loc[a[cc]==c,"Target_Disease_Score"],errors="coerce").dropna()
        ax.hist(vals,bins=30,alpha=.55,label=f"Cluster {c} ({label_map[c]})")
        if len(vals):
            mu=float(vals.mean()); n=len(vals)
            ax.axvline(mu,ls="--",alpha=.8)
            ax.annotate(f"Cluster {c}\nMean = {mu:.4f}\n(N = {n})",
                        xy=(mu,max(1,n*.45)),xytext=(5,5),textcoords="offset points",fontsize=9)
    ax.set(xlabel="Best_Score",ylabel="Number of Patients",title="(a) Histogram of Best_Score by Cluster")
    ax.legend(); ax.grid(alpha=.18)

    # (b) Box plot.
    ax=axes[0,1]
    groups=[pd.to_numeric(a.loc[a[cc]==c,"Target_Disease_Score"],errors="coerce").dropna().to_numpy() for c in order]
    labels=[f"{c} ({label_map[c]})" for c in order]
    ax.boxplot(groups,tick_labels=labels,showmeans=True,meanline=True)
    ax.set(xlabel="Cluster",ylabel="Best_Score",title="(b) Box plot showing cluster separation"); ax.grid(alpha=.18)

    # (c) Actual-outcome composition as 100% stacked bars, strictly post-fit.
    ax=axes[1,0]
    if y_true is not None:
        yt=pd.Series(y_true,index=getattr(y_true,"index",a.index)).reindex(a.index)
        tmp=pd.DataFrame({"cluster":a[cc],"actual":yt},index=a.index).dropna()
        ct=pd.crosstab(tmp.cluster,tmp.actual).reindex(order,fill_value=0)
        pct=ct.div(ct.sum(axis=1).replace(0,np.nan),axis=0)*100
        bottom=np.zeros(len(pct))
        for outcome in pct.columns:
            vals=pct[outcome].fillna(0).to_numpy(float)
            ax.bar(range(len(order)),vals,bottom=bottom,label=str(outcome),alpha=.82)
            counts=ct[outcome].to_numpy(int)
            for j,(p,nc,b) in enumerate(zip(vals,counts,bottom)):
                if p>=7:
                    ax.text(j,b+p/2,f"{p:.1f}%\n({nc})",ha="center",va="center",fontsize=9)
            bottom+=vals
        ax.set_ylim(0,100); ax.legend(title="Actual outcome",loc="upper center",bbox_to_anchor=(.5,-.12),ncol=max(1,len(pct.columns)))
    else:
        ax.text(.5,.5,"Provide y_true to show actual-outcome composition",ha="center",va="center",transform=ax.transAxes)
    ax.set_xticks(range(len(order))); ax.set_xticklabels([f"{c} ({label_map[c]})" for c in order])
    ax.set(xlabel="Cluster",ylabel="Percentage (%)",title="(c) Cluster composition by actual outcome"); ax.grid(alpha=.12,axis="y")

    # (d) Jitter/scatter by cluster, colored by actual outcome when provided.
    ax=axes[1,1]; rng=np.random.default_rng(42)
    xs=[]; ys=[]; cs=[]
    yt=None if y_true is None else pd.Series(y_true,index=getattr(y_true,"index",a.index)).reindex(a.index)
    for j,c in enumerate(order):
        idx=a.index[a[cc]==c]; vals=pd.to_numeric(a.loc[idx,"Target_Disease_Score"],errors="coerce")
        good=vals.notna(); idx=idx[good]; vals=vals[good]
        x=j+rng.normal(0,.055,len(vals)); xs.extend(x); ys.extend(vals.to_numpy(float))
        if yt is not None: cs.extend(yt.reindex(idx).astype(str).tolist())
        if len(vals): ax.text(j,float(vals.mean())+.05,f"Mean = {float(vals.mean()):.4f}\n(N = {len(vals)})",ha="center",fontsize=9)
    if yt is None:
        ax.scatter(xs,ys,s=18,alpha=.55)
    else:
        cs=np.asarray(cs); xs=np.asarray(xs); ys=np.asarray(ys)
        for outcome in pd.unique(cs):
            m=cs==outcome; ax.scatter(xs[m],ys[m],s=18,alpha=.5,label=str(outcome))
        ax.legend(title="Actual outcome")
    ax.set_xticks(range(len(order))); ax.set_xticklabels([f"{c} ({label_map[c]})" for c in order])
    ax.set(xlabel="Cluster",ylabel="Best_Score",title="(d) Scatter plot with jitter showing score distribution"); ax.grid(alpha=.18)

    plt.tight_layout(); plt.show()
    return a.groupby(cc)["Target_Disease_Score"].agg(["mean","count","min","max"]).reset_index()

def visualize_partition(method, y_true=None):
    """Render the full post-clustering visualization family.

    Clustering coordinates are always disease-score vectors. ``y_true`` is optional and
    used only for the descriptive actual-outcome composition plot after fitting.
    """
    if not method.fitted_: raise RuntimeError("Fit the partition method before visualization.")
    if method.name == "kmeans":
        return _kmeans_four_panel(method, y_true=y_true)
    a=method.assignments_.copy(); target=method.target_disease_; cc=_cluster_col(method)
    group=cc if cc in a.columns else "Predicted_Result"

    # 1 histogram by cluster/group
    fig,ax=plt.subplots(figsize=(9,5))
    for g in sorted(a[group].dropna().unique(),key=str):
        v=pd.to_numeric(a.loc[a[group]==g,"Target_Disease_Score"],errors="coerce").dropna()
        if len(v): ax.hist(v,bins=30,alpha=.45,label=str(g))
    ax.set(xlabel=f"{target} disease score",ylabel="Count",title=f"{method.name.title()}: histogram by cluster"); ax.legend(title=group); ax.grid(alpha=.2); plt.show()

    # 2 box plot by cluster
    groups=[]; labels=[]
    for g in sorted(a[group].dropna().unique(),key=str):
        v=pd.to_numeric(a.loc[a[group]==g,"Target_Disease_Score"],errors="coerce").dropna().to_numpy()
        if len(v): groups.append(v); labels.append(str(g))
    if groups:
        fig,ax=plt.subplots(figsize=(9,5)); ax.boxplot(groups,tick_labels=labels); ax.set(xlabel=group,ylabel=f"{target} disease score",title=f"{method.name.title()}: score box plot"); ax.grid(alpha=.2); plt.show()

    # 3 actual outcome composition (post-fit descriptive only)
    if y_true is not None:
        yt=pd.Series(y_true,index=getattr(y_true,"index",a.index)).reindex(a.index)
        comp=pd.crosstab(a[group],yt,normalize="index")
        ax=comp.plot(kind="bar",stacked=True,figsize=(9,5)); ax.set(xlabel=group,ylabel="Proportion",title=f"{method.name.title()}: actual-outcome composition (not used for fitting)"); ax.legend(title="Actual outcome",bbox_to_anchor=(1.02,1),loc="upper left"); plt.tight_layout(); plt.show()

    # 4 jitter/scatter of target score by cluster
    if cc and cc in a:
        rng=np.random.default_rng(42); x=a[cc].to_numpy(float)+rng.normal(0,.055,len(a)); y=pd.to_numeric(a.Target_Disease_Score,errors="coerce").to_numpy(float)
        fig,ax=plt.subplots(figsize=(9,5)); ax.scatter(x,y,s=20,alpha=.6); ax.set(xlabel=cc,ylabel=f"{target} disease score",title=f"{method.name.title()}: jittered cluster-score scatter"); ax.grid(alpha=.2); plt.show()

    # 5 cluster means and counts
    summary=a.groupby(group)["Target_Disease_Score"].agg(["mean","count"]).reset_index()
    fig,ax=plt.subplots(figsize=(9,5)); ax.bar(summary[group].astype(str),summary["mean"]); ax.set(xlabel=group,ylabel=f"Mean {target} score",title=f"{method.name.title()}: cluster means"); ax.grid(alpha=.2,axis="y"); plt.show()
    fig,ax=plt.subplots(figsize=(9,5)); ax.bar(summary[group].astype(str),summary["count"]); ax.set(xlabel=group,ylabel="Count",title=f"{method.name.title()}: cluster counts"); ax.grid(alpha=.2,axis="y"); plt.show()

    # 6 existing score-space visualization (PCA projection) for multivariate methods
    dims=[c for c in method.score_dimensions_ if c in method.score_matrix_.columns]
    if method.name!="hard" and len(dims)>=2:
        x=method.score_matrix_.loc[a.index,dims].apply(pd.to_numeric,errors="coerce").dropna(); aa=a.loc[x.index]
        p=PCA(n_components=2).fit_transform(StandardScaler().fit_transform(x))
        fig,ax=plt.subplots(figsize=(8,6))
        for g in sorted(aa[group].dropna().unique(),key=str):
            m=(aa[group]==g).to_numpy(); ax.scatter(p[m,0],p[m,1],s=22,alpha=.6,label=str(g))
        ax.set(xlabel="Disease-score PC1",ylabel="Disease-score PC2",title=f"{method.name.title()}: disease-score space"); ax.legend(title=group); ax.grid(alpha=.2); plt.show()

    # 7 method-specific score visualization
    if method.name=="gaussian":
        vals=pd.to_numeric(a.Target_Disease_Score,errors="coerce").dropna().to_numpy(float)
        if len(vals):
            grid=np.linspace(vals.min(),vals.max(),500); means=np.asarray(method.metadata_["ordered_target_score_means"]); vars_=np.asarray(method.metadata_["ordered_target_variances"]); weights=np.asarray(method.metadata_["ordered_component_weights"]); total=np.zeros_like(grid)
            fig,ax=plt.subplots(figsize=(9,5)); ax.hist(vals,bins=35,density=True,alpha=.25)
            for j,(mu,var,w) in enumerate(zip(means,vars_,weights)):
                sd=max(np.sqrt(max(var,1e-12)),1e-9); dens=w*np.exp(-.5*((grid-mu)/sd)**2)/(sd*np.sqrt(2*np.pi)); total+=dens; ax.plot(grid,dens,label=f"Component {j+1}")
            ax.plot(grid,total,lw=2,label="Mixture density"); ax.set(xlabel=f"{target} score",ylabel="Density",title="Gaussian component densities after manual/automatic fit"); ax.legend(); ax.grid(alpha=.2); plt.show()
    elif method.name=="mahalanobis" and "Mahalanobis_Distance" in a:
        fig,ax=plt.subplots(figsize=(9,5))
        for g in sorted(a[group].dropna().unique(),key=str):
            v=pd.to_numeric(a.loc[a[group]==g,"Mahalanobis_Distance"],errors="coerce").dropna(); ax.hist(v,bins=30,alpha=.45,label=str(g))
        ax.set(xlabel="Assigned Mahalanobis distance",ylabel="Count",title="Mahalanobis assignment-distance distribution"); ax.legend(); ax.grid(alpha=.2); plt.show()
    elif method.name=="hard":
        fig,ax=plt.subplots(figsize=(9,5)); vals=pd.to_numeric(a.Target_Disease_Score,errors="coerce").dropna(); ax.hist(vals,bins=35,alpha=.5); ax.axvline(method.negative_threshold,ls="--",label="negative threshold"); ax.axvline(method.positive_threshold,ls="--",label="positive threshold"); ax.legend(); ax.set(xlabel=f"{target} score",ylabel="Count",title="Hard-assignment thresholds"); ax.grid(alpha=.2); plt.show()
    return summary
