from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import math
from .functions import (information_gate_geometry, manuscript_evidence_contributions, disease_profile_similarity,
                        positive_similarity_gate, canonical_net_evidence, normalized_evidence_probability,
                        reduce_total_contradiction, disease_ranking_score)
from .condition_logic import evaluate_condition
import numpy as np
import pandas as pd
from .legacy_activation import (
    construct_patient_with_reference_scores, ENCODINGS, encode_value,
    get_all_reference_components, get_reference_component_score, calculate_l2_norm,
)

@dataclass
class DiseaseTrace:
    disease: str
    positive_evidence: float
    negative_evidence: float
    net_evidence: float
    evidence_probability: float
    canonical_net_evidence: float
    cosine_similarity: float
    magnitude_ratio: float
    logistic_similarity: float  # compatibility field; current scorer stores NaN
    pre_rule_score: float        # scalar ranking score before hard-rule overrides
    final_score: float           # scalar disease score after hard-rule overrides
    pathognomonic_triggered: bool
    exclusionary_triggered: bool
    observed_features: int
    missing_features: int
    feature_rows: list[dict[str, Any]]
    def flat(self):
        d=asdict(self); d.pop("feature_rows",None); return d

def _sigmoid(x: float) -> float:
    return float(1.0/(1.0+np.exp(-np.clip(x,-700,700))))

def _component_activations(data: dict) -> list[float]:
    """Return q_ijc in canonical component order, including zero activations.

    This preserves the archived component scorers but not the archived feature-level
    L2 gate.  Each retained component is clipped to [0,1], as required by the
    finalized manuscript definition of q_ijc.
    """
    out=[]
    for name,c in (data.get("components",{}) or {}).items():
        if name == "main" or not bool(c.get("from_patient")):
            continue
        # All components, including ``default``, now carry an explicit
        # patient-reference match score from the activation layer.
        v=float(c.get("patient_score",0.0) or 0.0)
        out.append(float(np.clip(v,0.0,1.0)))
    return out

def _feature_geometry(q: list[float]) -> tuple[float,float,float,float,int]:
    return information_gate_geometry(q)

def _conditioned_q(data: dict, q: list[float]) -> list[float]:
    """Apply optional recursive feature condition without changing legacy YAML behaviour."""
    condition=(data.get("reference_metadata",{}) or {}).get("condition")
    if not condition:
        return q
    comps=data.get("components",{}) or {}
    names=[n for n,c in comps.items() if n != "main" and bool(c.get("from_patient"))]
    qmap={n:v for n,v in zip(names,q)}
    def resolve(name):
        # Direct profile-component leaf (temperature, duration, etc.).
        if name in qmap: return qmap[name]
        # Subcomponent/reference leaf (DReference, trend, value). For a single
        # observed profile component, its already computed q is the compatible
        # activation. This preserves old scoring while making admissible logic explicit.
        hits=[]
        for cname,c in comps.items():
            if not bool(c.get("from_patient")): continue
            rv=c.get("ref_value")
            if isinstance(rv,dict) and name in rv:
                hits.append(qmap.get(cname,0.0))
        return max(hits) if hits else 0.0
    gate=evaluate_condition(condition,resolve)
    # The condition is itself the feature-compatible activation geometry.
    return [gate]

def score_candidate(patient: dict, disease_name: str, vectors: dict, config) -> DiseaseTrace:
    activated=construct_patient_with_reference_scores(patient,vectors,debug=False)
    # ``activated`` is keyed by the full reference key so repeated EFN codes
    # in different disease stages remain independent evidence nodes.

    # Materialize untouched EFNs so missingness is explicit rather than zero evidence.
    for ref_key,ref_vector in vectors.items():
        feature_name=ref_vector.get("feature_name")
        if not feature_name or ref_key in activated: continue
        dx_role=encode_value(ref_vector.get("diagnostic_role")); importance=encode_value(ref_vector.get("importance"))
        support=encode_value(ref_vector.get("support")); contradiction=encode_value(ref_vector.get("contradiction"))
        expected_freq=encode_value(ref_vector.get("expected_frequency")); comps={}; ref_scores=[]
        for comp_name,ref_value in get_all_reference_components(ref_vector):
            rs=get_reference_component_score(ref_value)
            comps[comp_name]={"patient_value":"","patient_score":0.0,"reference_score":rs,"processing_type":"MISSING","ref_value":ref_value,"from_patient":False,"from_reference":True}
            if comp_name != "main" and isinstance(rs,(int,float)) and rs>0: ref_scores.append(float(rs))
        activated[ref_key]={"patient_score":0.0,"reference_score":calculate_l2_norm(ref_scores) if ref_scores else 0.0,"components":comps,"patient_values":{},"reference_metadata":{"name":ref_vector.get("name",feature_name),"feature_code":feature_name,"reference_key":ref_key,"stage":ref_vector.get("stage","unknown"),"diagnostic_role":dx_role,"importance":importance,"support":support,"contradiction":contradiction,"expected_frequency":expected_freq,"source_file":ref_vector.get("source_file"),"all_reference_components":get_all_reference_components(ref_vector),"condition":ref_vector.get("condition")}}

    pos=neg=0.0; P=[]; E=[]; rows=[]; patho=False; excl=False; missing=0; observed=0; canonical_params=[]
    for feature_key,data in activated.items():
        meta=data.get("reference_metadata",{}) or {}; components=data.get("components",{}) or {}
        actually_observed=any(bool(v.get("from_patient")) and v.get("patient_value") not in (None,"") and not pd.isna(v.get("patient_value")) for v in components.values())
        q=_component_activations(data); q=_conditioned_q(data,q); pij,cosij,rhoij,ig,m=_feature_geometry(q)
        Ri=float(meta.get("diagnostic_role",0.0) or 0.0); Ii=float(meta.get("importance",0.0) or 0.0)
        Si=max(0.0,float(meta.get("support",0.0) or 0.0)); Ci=abs(float(meta.get("contradiction",0.0) or 0.0))
        row={"feature":feature_key,"code":meta.get("feature_code",feature_key.split("_",1)[0]),"name":meta.get("name",feature_key),
             "patient_activation":ig,  # compatibility alias: finalized feature similarity is IG
             "information_gate":ig,"patient_magnitude":pij,"feature_cosine":cosij,"feature_rho":rhoij,
             "canonical_magnitude":math.sqrt(m) if m else 0.0,"component_count":m,
             "reference_magnitude":math.sqrt(m) if m else 0.0,"diagnostic_role":Ri,"clinical_importance":Ii,
             "diagnostic_role_effective":Ri,"clinical_importance_effective":Ii,
             "diagnostic_role_function":"identity","clinical_importance_function":"identity",
             "positive_similarity_gate":positive_similarity_gate(ig),
             "support":Si,"contradiction":Ci,"observed":actually_observed,"stage":meta.get("stage"),
             "source_file":meta.get("source_file"),"components":components}
        if config.missing_aware and not actually_observed:
            missing+=1; row.update({"positive_contribution":0.0,"negative_contribution":0.0}); rows.append(row); continue
        observed += int(actually_observed)
        # In missing-aware mode the canonical evidence denominator must use the
        # same observed evidence support as the patient numerator. Otherwise
        # diseases with larger knowledge graphs are penalized simply because the
        # cohort does not measure many of their features.
        canonical_params.append((Ri,Ii,Si,Ci))
        # Disease-level profile similarity deliberately uses only Hallmark and Major
        # diagnostic-role features. Pathognomonic features remain in their hard-rule path.
        if Ri in (ENCODINGS['diagnostic_role']['Hallmark'], ENCODINGS['diagnostic_role']['Major']):
            P.append(pij); E.append(math.sqrt(m) if m else 0.0)
        patho = patho or (Ri == ENCODINGS['diagnostic_role']['Pathognomonic'] and ig >= config.pathognomonic_threshold)
        excl = excl or (Ri == ENCODINGS['diagnostic_role']['Exclusionary'] and ig >= config.exclusionary_threshold)
        pcon,ncon=manuscript_evidence_contributions(information_gate=ig,diagnostic_role=Ri,importance=Ii,support=Si,contradiction=Ci)
        pos+=pcon; neg+=ncon; row.update({"positive_contribution":pcon,"negative_contribution":ncon}); rows.append(row)

    # Feature-level contradiction is f(1-IG)*C. No additional aggregate
    # contradiction discount is applied under the active unit scaling.
    neg=reduce_total_contradiction(neg)
    enet=pos-neg
    canonical_enet=canonical_net_evidence(canonical_params)
    pe=normalized_evidence_probability(enet,canonical_enet)
    cos,ratio=disease_profile_similarity(P,E)
    # Preserve the raw patient coordinates independently for clustering:
    # S0(D_j) = [P_evidence(D_j), r_j, c_j]^T.
    # Ranking is separate.  It compares the sum of the three patient-derived
    # components with the sum of the corresponding canonical components.
    # Canonical evidence is passed through the same normalization equation, and
    # the canonical profile is compared with itself through the same similarity
    # function; therefore the denominator is derived rather than hard-coded.
    pe_can=normalized_evidence_probability(canonical_enet,canonical_enet)
    cos_can,ratio_can=disease_profile_similarity(E,E)
    ranking=disease_ranking_score(
        pe, ratio, cos, pe_can, ratio_can, cos_can
    )
    final=1.0 if patho else 0.0 if excl else ranking
    return DiseaseTrace(disease_name,pos,neg,enet,pe,canonical_enet,cos,ratio,float("nan"),ranking,final,patho,excl,observed,missing,rows)
