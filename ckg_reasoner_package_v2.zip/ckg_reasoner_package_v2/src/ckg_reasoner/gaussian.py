"""Gaussian-mixture diagnostics for selectable post-KG clustering variables."""
from __future__ import annotations
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler
from .separation import GaussianPartition, _score_frame


def diagnose_gaussian(score_matrix: pd.DataFrame, target_disease: str, min_components=2, max_components=10,
                      random_state=42, n_init=10, reg_covar=1e-6, show=True, variables=None,
                      print_recommendations=False) -> pd.DataFrame:
    """Compute BIC/AIC in the selected post-KG variable space."""
    _,valid,cols=_score_frame(score_matrix,target_disease,variables=variables); scaler=StandardScaler(); z=scaler.fit_transform(valid[cols].to_numpy(float))
    unique_rows=len(np.unique(np.round(z,12),axis=0)); lo=max(2,int(min_components)); hi=min(int(max_components),unique_rows,max(lo,len(valid)//3))
    if hi<lo: raise ValueError(f"Gaussian diagnostics require at least {lo} candidate components.")
    rows=[]; models={}
    for k in range(lo,hi+1):
        gm=GaussianMixture(n_components=k,covariance_type="full",random_state=random_state,n_init=n_init,reg_covar=reg_covar).fit(z)
        rows.append({"n":k,"k":k,"bic":float(gm.bic(z)),"aic":float(gm.aic(z)),"converged":bool(gm.converged_),"iterations":int(gm.n_iter_)}); models[k]=gm
    d=pd.DataFrame(rows); bic_k=int(d.sort_values(["bic","k"]).iloc[0].k); aic_k=int(d.sort_values(["aic","k"]).iloc[0].k)
    basis=("4-D [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] vectors" if cols==["P_evidence","r","c","Confidence_Score"] else f"standardized selected post-KG variables {cols}")
    d.attrs.update({"recommended_n":bic_k,"bic_recommended_n":bic_k,"aic_recommended_n":aic_k,"basis":basis,"variables":list(cols)})
    if print_recommendations:
        print(f"BIC-recommended component number: {bic_k}"); print(f"AIC-recommended component number: {aic_k}")
    if show:
        fig,ax=plt.subplots(figsize=(8,5)); ax.plot(d.k,d.bic,"o-",label="BIC"); ax.plot(d.k,d.aic,"o-",label="AIC"); ax.axvline(bic_k,ls="--",label=f"BIC recommendation={bic_k}"); ax.set(xlabel="Components",ylabel="Information criterion",title="Gaussian-mixture BIC/AIC diagnostics"); ax.legend(); ax.grid(alpha=.25); plt.show()
        if z.shape[1]>=2:
            from sklearn.decomposition import PCA
            pca=PCA(n_components=2).fit(z); pts=pca.transform(z); ctr=pca.transform(models[bic_k].means_)
            fig,ax=plt.subplots(figsize=(8,6)); ax.scatter(pts[:,0],pts[:,1],s=16,alpha=.45,label="Patients"); ax.scatter(ctr[:,0],ctr[:,1],s=90,marker="x",label="GMM component means"); ax.set(xlabel="PC1",ylabel="PC2",title=f"GMM projection of selected space (BIC-recommended n={bic_k})"); ax.legend(); ax.grid(alpha=.25); plt.tight_layout(); plt.show()
    return d

__all__=["GaussianPartition","diagnose_gaussian"]
