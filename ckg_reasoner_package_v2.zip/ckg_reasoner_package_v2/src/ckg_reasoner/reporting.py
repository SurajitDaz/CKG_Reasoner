from __future__ import annotations
from typing import Iterable
from .explanation import ExplanationObject


def deterministic_report(obj: ExplanationObject, top_evidence: int = 8) -> str:
    """Render a grounded human-readable report from an ExplanationObject.

    This is deliberately deterministic: every clinical/numerical statement is copied
    from the inference object, so the verbalizer cannot revise the diagnosis or invent
    unsupported evidence. A constrained LLM can later replace only this realization
    step while retaining the same object/verifier contract.
    """
    c=obj.continuous_facts; d=obj.deterministic_facts; u=obj.uncertainty_facts
    lines=[f"Candidate disease: {obj.disease}", f"Patient/row: {obj.patient_id}", "", "Evidence:"]
    ranked=sorted(obj.evidence_facts,key=lambda x:abs(x.get("positive_contribution",0.0))+abs(x.get("negative_contribution",0.0)),reverse=True)
    for e in ranked[:max(1,int(top_evidence))]:
        state="observed" if e.get("observed") else "unresolved"
        lines.append(
            f"- {e['name']} [{e['feature']}] ({state}): similarity={e['similarity']:.4g}, "
            f"importance={e['clinical_importance']:.4g}, specificity={e['specificity']:.4g}, "
            f"support={e['support']:.4g}, contradiction={e['contradiction']:.4g}."
        )
    lines += ["", "Continuous reasoning:",
              f"- Positive evidence={c['positive_evidence']:.6g}; negative evidence={c['negative_evidence']:.6g}; net evidence={c['net_evidence']:.6g}.",
              f"- Evidence score={c['evidence_probability']:.6g}; magnitude ratio r={c['magnitude_ratio']:.6g}; cosine c={c['cosine_similarity']:.6g}; disease ranking score={c['diagnostic_support']:.6g}.",
              "", "Deterministic reasoning:",
              f"- Pathognomonic trigger: {'yes' if d['pathognomonic_triggered'] else 'no'}.",
              f"- Exclusionary trigger: {'yes' if d['exclusionary_triggered'] else 'no'}." ]
    if d.get("responsible_features"):
        lines.append("- Responsible hard-rule feature(s): "+", ".join(map(str,d["responsible_features"]))+".")
    if u:
        lines += ["", "Uncertainty:",
                  f"- Support interval=[{u['lower']:.6g}, {u['upper']:.6g}], width={u['width']:.6g}.",
                  f"- Selective decision={u['decision_label']}; solver={u['method']}; exact extrema={u['exact_extrema']}." ]
        if u.get("uncertain_features"):
            lines.append(f"- Unresolved EFNs: {len(u['uncertain_features'])}.")
    if "evidence_coverage" in c:
        lines += ["", "Diagnostic confidence:",
                  f"- Evidence coverage={100*c['evidence_coverage']:.1f}%; confidence score={c['confidence_score']:.4g}; level={d.get('confidence_level','') }.",
                  f"- Reason: {d.get('confidence_reason','')}" ]
        critical=[]
        for label,key in (("Pathognomonic","missing_pathognomonic"),("Hallmark","missing_hallmark"),("Major","missing_major"),("Exclusionary","missing_exclusionary")):
            vals=d.get(key,[]) or []
            if vals: critical.append(f"{label}: {', '.join(map(str,vals))}")
        if critical: lines.append("- Critical missing evidence: "+"; ".join(critical)+".")
    lines += ["", "Decision:",
              f"- Candidate score={obj.decision['score']:.6g}.",
              f"- Selective decision={obj.decision.get('selective_decision') or 'not requested'}." ]
    return "\n".join(lines)


def verify_explanation_object(obj: ExplanationObject) -> dict:
    """Deterministically verify internal numerical/rule/decision consistency."""
    errors=[]
    c=obj.continuous_facts; d=obj.deterministic_facts; u=obj.uncertainty_facts
    if abs((c["positive_evidence"]-c["negative_evidence"])-c["net_evidence"]) > 1e-9:
        errors.append("net_evidence mismatch")
    if abs(c["diagnostic_support"]-obj.decision["score"]) > 1e-12:
        errors.append("decision score mismatch")
    if u:
        if u["lower"] > u["upper"]:
            errors.append("support interval lower > upper")
        if abs((u["upper"]-u["lower"])-u["width"]) > 1e-9:
            errors.append("support interval width mismatch")
        if obj.decision.get("selective_decision") != u.get("decision_label"):
            errors.append("selective decision mismatch")
    # Responsible features must correspond to an emitted hard-rule predicate.
    fol="\n".join(obj.fol_facts)
    for f in d.get("responsible_features",[]):
        if f not in fol:
            errors.append(f"hard-rule provenance missing for {f}")
    return {"valid":not errors,"errors":errors,"checked":"numerical, interval, rule-provenance, and decision consistency"}
