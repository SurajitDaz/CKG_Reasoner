"""Unit-aware normalization for mapped CKG feature components.

Every mapped component is routed through this module. Categorical/dimensionless
components pass through unchanged. Numeric components with a registered physical
unit are converted to the ontology canonical unit before activation/scoring.
Unknown or incompatible explicit units are never silently converted.
"""
from __future__ import annotations
import re
import numpy as np
import pandas as pd

# Canonical units are representation units used by the current EFN reference ranges.
COMPONENT_UNITS = {
    "Age": "year", "FEV_dura_dy": "day", "FEV_temperature_c": "degC",
    "MTP_platelet_count": "/uL", "THR_platelet_count": "/uL", "LEU_wbc": "/uL",
    "HGB_hemoglobin_g_dl": "g/dL", "NEU_neutrophil_count": "%",
    "LYM_lymphocyte_count": "%", "MON_monocyte_count": "%", "EOS_eosinophil_count": "%",
    "RBC1_rbc": "million/uL", "HCT_hematocrit": "%", "MCV_mcv": "fL",
    "MCH_mch": "pg", "MCHC_mchc": "g/dL", "RDW_rdw": "%", "MPV_mpv": "fL",
    "PDW_pdw": "%", "PCT_pct": "%",
}

# Dataset schemas whose unit is known even when the heading omits it.
SCHEMA_SOURCE_UNITS = {
    "C1_Bangladesh_Dengue_1000": {
        "Age":"year", "FEV_dura_dy":"day", "FEV_temperature_c":"degC",
        "MTP_platelet_count":"/uL", "LEU_wbc":"/uL",
    },
    "C2_D4_Dengue_Hematology_1523": {
        "HGB_hemoglobin_g_dl":"g/dL", "NEU_neutrophil_count":"%", "LYM_lymphocyte_count":"%",
        "MON_monocyte_count":"%", "EOS_eosinophil_count":"%", "RBC1_rbc":"million/uL",
        "HCT_hematocrit":"%", "MCV_mcv":"fL", "MCH_mch":"pg", "MCHC_mchc":"g/dL",
        "RDW_rdw":"%", "MTP_platelet_count":"/uL", "MPV_mpv":"fL", "PDW_pdw":"%",
        "PCT_pct":"%", "LEU_wbc":"/uL",
    },
}

def _clean(u):
    if u is None: return None
    s=str(u).strip().lower().replace('μ','u').replace('µ','u').replace('³','3')
    s=s.replace('litre','l').replace('liter','l').replace('cumm','mm3')
    s=re.sub(r'\s+','',s)
    aliases={
      '/ul':'/uL','cells/ul':'/uL','cell/ul':'/uL','/mm3':'/uL','cells/mm3':'/uL',
      '/ml':'/mL','cells/ml':'/mL','/l':'/L','cells/l':'/L','10^9/l':'10^9/L','x10^9/l':'10^9/L','10e9/l':'10^9/L',
      'g/dl':'g/dL','g/l':'g/L','%':'%','percent':'%','fraction':'fraction','ratio':'fraction',
      'fl':'fL','pg':'pg','year':'year','years':'year','yr':'year','yrs':'year','day':'day','days':'day','hr':'hour','hrs':'hour','hour':'hour','hours':'hour',
      'c':'degC','°c':'degC','degc':'degC','f':'degF','°f':'degF','degf':'degF',
      'million/ul':'million/uL','10^6/ul':'million/uL','x10^6/ul':'million/uL','cells/ul_rbc':'/uL_RBC'
    }
    return aliases.get(s,u)

def infer_unit_from_heading(heading):
    s=str(heading).lower().replace('μ','u').replace('µ','u').replace('³','3')
    # order matters: /mL before /L; g/dL before /L
    patterns=[
      (r'g\s*/\s*dl','g/dL'),(r'g\s*/\s*l','g/L'),(r'million\s*/\s*u?l','million/uL'),(r'(?:10\^?6|x10\^?6)\s*/\s*u?l','million/uL'),
      (r'(?:/|per\s*)cumm|/\s*mm3','/uL'),(r'/\s*u?l','/uL'),(r'/\s*ml','/mL'),(r'(?:10\^?9|x10\^?9)\s*/\s*l','10^9/L'),
      (r'\(%\)|percent','%'),(r'\(fl\)','fL'),(r'\(pg\)','pg'),(r'fahrenheit|\(f\)|°f','degF'),(r'celsius|\(c\)|°c','degC'),
    ]
    for p,u in patterns:
        if re.search(p,s): return u
    return None

def convert_value(value, source_unit, canonical_unit):
    if value is None or (isinstance(value,float) and np.isnan(value)): return value
    src=_clean(source_unit); dst=_clean(canonical_unit)
    if src is None or dst is None or src==dst: return value
    x=pd.to_numeric(pd.Series([value]),errors='coerce').iloc[0]
    if pd.isna(x): return value
    x=float(x)
    # cell counts
    if dst=='/uL':
        if src=='/mL': return x/1000.0
        if src=='/L': return x/1_000_000.0
        if src=='10^9/L': return x*1000.0
    # RBC canonical million/uL
    if dst=='million/uL':
        if src=='/uL': return x/1_000_000.0
        if src=='/mL': return x/1_000_000_000.0
        if src=='10^9/L': return x/1000.0
    if dst=='g/dL' and src=='g/L': return x/10.0
    if dst=='%' and src=='fraction': return x*100.0
    if dst=='day' and src=='hour': return x/24.0
    if dst=='degC' and src=='degF': return (x-32.0)*5.0/9.0
    raise ValueError(f"Incompatible or unsupported unit conversion: {source_unit!r} -> {canonical_unit!r}")

def normalize_mapped_dataframe(df, original_to_new, schema=None):
    """Normalize every mapped component; returns (df, audit rows).

    Registered numeric components are converted to canonical units. All other mapped
    components are explicitly recorded as pass-through (categorical/dimensionless).
    """
    out=df.copy(); audit=[]
    for original, canonical in original_to_new.items():
        if canonical not in out.columns: continue
        dst=COMPONENT_UNITS.get(canonical)
        if dst is None:
            audit.append({"dataset_heading":original,"ontology_heading":canonical,"source_unit":None,"canonical_unit":None,"unit_status":"pass_through"})
            continue
        src=infer_unit_from_heading(original) or SCHEMA_SOURCE_UNITS.get(schema,{}).get(canonical)
        if src is None:
            # No guessing: retain value but flag unresolved so callers can audit it.
            audit.append({"dataset_heading":original,"ontology_heading":canonical,"source_unit":None,"canonical_unit":dst,"unit_status":"unresolved"})
            continue
        try:
            out[canonical]=out[canonical].map(lambda v: convert_value(v,src,dst))
            status='canonical' if _clean(src)==_clean(dst) else 'converted'
        except ValueError:
            status='incompatible'
        audit.append({"dataset_heading":original,"ontology_heading":canonical,"source_unit":src,"canonical_unit":dst,"unit_status":status})
    return out,audit
