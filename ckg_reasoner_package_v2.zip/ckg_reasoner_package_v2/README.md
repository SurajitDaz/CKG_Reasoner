# CKG Reasoner v2 — current clustering semantics

The current v2 post-KG clustering representation is the **four-dimensional** vector

```text
S0(D_j) = [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)]^T
```

These four coordinates are standardized before K-means, Gaussian-mixture, and Mahalanobis partitioning. `Confidence_Score` is an outcome-label-independent evidence-completeness quantity. The separate disease-ranking score `R(D_j)` is **not** a clustering coordinate. Raw patient variables are not directly supplied to K-means; they contribute upstream through the knowledge-graph reasoning pipeline. Historical build logs describing 2-D or 3-D clustering document earlier package versions and are superseded by this v2 definition for the active implementation.

## Optional manual mismatch calculation audit (v1.0.4)

`model.output()` can generate a human-readable reconstruction of the first mismatched records. Logging is **off by default**.

```python
model.output(
    "CKG_output.xlsx",
    positive_disease="Dengue",
    method=kmeans,
    manual_log=True,
    manual_log_format="latex",   # "latex"/"tex" or "pdf"
    manual_log_limit=10,
)
print(model.manual_log_path_)
```

Disable it with `manual_log=False`. The LaTeX audit requires no extra Python dependency. PDF output requires `reportlab`. The audit is generated from stored deterministic traces and does not modify inference.

## Manual calculation audit: matched controls (v1.0.5)

The optional manual audit can now include both error cases and correctly classified controls.

```python
model.output(
    output_path,
    positive_disease="Dengue",
    method=kmeans,
    manual_log=True,
    manual_log_format="pdf",
    manual_log_mismatch_limit=10,
    manual_log_match_limit=5,
)
```

`manual_log_limit` remains a backward-compatible alias for the mismatch limit. If
`manual_log_mismatch_limit` is supplied, it takes precedence. The audit remains OFF by
default and never changes inference, scores, rules, clustering, or predictions.



## Symmetric nonlinear contradiction gating (v1.0.7)

The current contradiction channel uses the complementary mismatch as a
temporary proxy, but passes it through the **same nonlinear transform** used
for positive similarity:

```text
pcon = f(IG)     * max(g, 0) * I * S
ncon = f(1 - IG) * C
f(x) = 1 / (1 + 0.05 * exp(-10 * (x - 0.85)))
```

This replaces the previous raw-complement equation `ncon=(1-IG)*C`.
`1-IG` is still a proxy rather than an independently measured contradictory
similarity; a future two-reference implementation can replace that proxy
without changing the evidence-channel interface.

Because `f(0)` is non-zero, the canonical denominator is evaluated with the
same equations and is therefore

```text
E_net(D_canonical)
  = sum_i [f(1)*max(g_i,0)*I_i*S_i - f(0)*C_i].
```

## Canonical evidence normalization (v1.0.6)
`P_evidence` is now the direct ratio `E_net(D_j) / E_net(D_canonical,j)`. The old sigmoid of net evidence is no longer used. The canonical denominator is evaluated with all disease-feature Information Gates equal to 1 under the same positive-evidence equation. No sigmoid or clipping is applied to the ratio. Manual audit output prints the formulas and numerical substitutions.


## Aggregate contradiction scaling

For this experimental formulation, feature-level contradiction remains:

`ncon_i = f(1 - IG_i) * C_i`

and total disease contradiction uses the same unit scale:

`E- = sum_i(ncon_i)`

and:

`E_net = E+ - E-`.

The same aggregate factor is used in the canonical denominator so patient and
canonical evidence remain normalized under the same scoring formulation.


## Quick clustering help (v2 freeze)

The three adaptive partitioning methods use the same selectable post-KG variable API.
The eligible variables are `P_evidence`, `r`, `c`, and `Confidence_Score`.

**Default rule:** if `variables` is omitted or `variables=None`, **all four eligible variables participate in clustering/partitioning**.

```python
model.help()                         # concise in-session help
model.help("clustering")

# all four variables (default)
km = model.kmeans_partition("Dengue")
gm = model.gaussian("Dengue")
ma = model.mahalanobis("Dengue")

# explicit subset; same API for all three methods
vars3 = ["P_evidence", "r", "c"]
km = model.kmeans_partition("Dengue", variables=vars3)
gm = model.gaussian("Dengue", variables=vars3)
ma = model.mahalanobis("Dengue", variables=vars3)

# diagnostics use the same variable subset
model.diagnostics("kmeans", "Dengue", variables=vars3)
model.diagnostics("gaussian", "Dengue", variables=vars3)
model.diagnostics("mahalanobis", "Dengue", variables=vars3)
```

Variable selection affects clustering geometry only. The established semantic ordering of discovered groups remains based on `P_evidence + r + c`. Raw patient variables, outcome labels, and the separate ranking score `R(D_j)` are not clustering coordinates.
