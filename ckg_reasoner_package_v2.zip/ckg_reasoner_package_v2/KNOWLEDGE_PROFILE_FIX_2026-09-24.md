# Knowledge/profile correction — 2026-09-24

## Changes
1. Missing-aware canonical evidence normalization now uses the same observed evidence support as the patient numerator. Unobserved EFNs no longer inflate the canonical denominator in missing-aware mode.
2. Malaria hematology gained literature-supported executable decreased-direction references for hemoglobin, total WBC, lymphocytes, and hematocrit, using the package's pre-existing lower reference boundaries. No M1 outcome labels were used to fit directions or thresholds.
3. The canonical-normalized additive disease-rank equation is unchanged.
4. Hallmark/Major profile geometry is unchanged. An experimental expansion to all positive diagnostic roles was tested and rejected because it degraded cross-disease ranking by allowing interoperability-only fields to dominate geometry.

## Malaria cohort audit
On C3_M1_Malaria_Bangladesh_2190, the original canonical-rank package ranked Malaria above Dengue in 691/1068 malaria-positive records. After the missing-aware denominator correction plus literature-supported malaria directionality updates, this became 700/1068. This audit is diagnostic only and was not used to tune parameters.

## Literature provenance
- PMID 38857772: 2024 review of hematological changes due to malaria.
- PMID 32574170: systematic review/meta-analysis of total leukocyte reduction in malaria.
- PMID 38309088: systematic review/meta-analysis of altered red-cell parameters in malaria.

> **Current v2 clustering state:** standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`; `R(D_j)` is separate from clustering. This note does not rewrite the historical changes documented above.
