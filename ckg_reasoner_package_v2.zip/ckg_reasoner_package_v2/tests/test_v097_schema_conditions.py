import yaml
from pathlib import Path
from ckg_reasoner.condition_logic import evaluate_condition
from ckg_reasoner import CKGModel, __version__

def test_recursive_conditions():
    r=lambda k:{"A":.5,"B":.4,"C":.2,"D":.5}[k]
    assert abs(evaluate_condition({"operator":"AND","components":["A",{"operator":"OR","components":["B","C"]}]},r)-(.5*(1-(1-.4)*(1-.2))))<1e-12

def test_package_complete_and_kb_loads():
    assert __version__=="2"
    m=CKGModel()
    assert len(m.kb.diseases)==3
    assert m.kb.audit()["yaml_file_count"]>=12

def test_yaml_processing_metadata_separation():
    base=Path(__file__).parents[1]/"src/ckg_reasoner/data/diseases"
    for yp in base.glob("*/*_laboratory.yaml"):
        data=yaml.safe_load(yp.read_text())
        assert isinstance(data.get("features"),dict)
        for feat in data["features"].values():
            for comp in (feat.get("profile") or {}).values():
                if not isinstance(comp,dict): continue
                for key in ("NReference","DReference","trend"):
                    obj=comp.get(key)
                    if isinstance(obj,dict) and "metadata" in obj:
                        assert isinstance(obj["metadata"],dict)  # v0.9.8: component-local maintenance/processing descriptors

def test_dengue_leu_condition():
    yp=Path(__file__).parents[1]/"src/ckg_reasoner/data/diseases/dengue/dengue_laboratory.yaml"
    d=yaml.safe_load(yp.read_text())
    assert d["features"]["LEU"]["condition"]=={"operator":"OR","components":["DReference","trend"]}
