import pandas as pd
from ckg_reasoner import CKGModel


def test_existing_dengue_schema():
    df=pd.DataFrame([{"id":1,"Gender":"Female","Age":30,"NS1":1,"IGG":0,"IGM":1,"MTP_platelet_count:":110000,"LEU_wbc":4000,"Dengue_Outcome":1}])
    m=CKGModel().hmap(df,interactive=False)
    assert m.detected_schema_=="C1_Bangladesh_Dengue_1000"
    assert "MTP_platelet_count" in m.df_
    assert "LEU_wbc" in m.df_


def test_d4_schema():
    df=pd.DataFrame([{"Gender":"Male","Age":21,"Hemoglobin(g/dl)":14.8,"Neutrophils(%)":48,"Lymphocytes(%)":47,"Monocytes(%)":3,"Eosinophils(%)":2,"RBC":5,"HCT(%)":48,"MCV(fl)":96,"MCH(pg)":29.6,"MCHC(g/dl)":30.8,"RDW-CV(%)":11.6,"Total Platelet Count(/cumm)":112000,"MPV(fl)":10.7,"PDW(%)":15.4,"PCT(%)":0.12,"Total WBC count(/cumm)":5100,"Result":"positive"}])
    m=CKGModel().hmap(df,interactive=False)
    assert m.detected_schema_=="C2_D4_Dengue_Hematology_1523"
    for c in ["HGB_hemoglobin_g_dl","MTP_platelet_count","LEU_wbc","RBC1_rbc","HCT_hematocrit"]: assert c in m.df_


def test_m1_schema_and_eosinophil_conversion():
    df=pd.DataFrame([{"Sex":"Male","Age":26,"Hemoglobin(Hb%)":15.3,"Total WBC count(/cumm)":5800,"Neutrophils":43,"Lymphocytes":41,"Total Cir.Eosinophils":245,"HTC/PCV(%)":48.5,"MCH(pg)":30.1,"MCHC(g/dl)":31.67,"RDW-CV(%)":15.22,"Platelet Count":195000,"Result":"negative"}])
    m=CKGModel().hmap(df,interactive=False)
    assert m.detected_schema_=="C3_M1_Malaria_2190"
    assert "THR_platelet_count" in m.df_
    assert abs(float(m.df_.iloc[0]["EOS_eosinophil_count"])-(245/5800*100)) < 1e-8


def test_i1_schema_and_lab_normalization():
    df=pd.DataFrame([{"CollectionDate":"September-10","RealTimePCRforInfluenzaABAFRIMS":"Flu A/H3","Collection_site":"OPD","Gender":"Male","Age":20,"Sec2_Medic_01_specify":"","Vaccine12mo_yn":"No","Sec3_Fever":"Yes","Sec3_Cough":"Yes","Sec3_Sore":"No","Sec3_Breathing":"No","Sec3_Headache":"Yes","Sec3_Malaise":"Yes","Sec3_Runny":"No","Sec3_Generalized":"Yes","Sec3_Chill":"Yes","Sec3_Diarrhea":"No","Sec3_Injected_pharynx":"No","Sec3_Injected_tympanic":"No","Sec4_Ifrapid":"Positive","year":2010,"month":9,"Flu_final_posneg":1}])
    m=CKGModel().hmap(df,interactive=False)
    assert m.detected_schema_=="C4_I1_Thailand_Influenza_4569"
    assert m.df_.iloc[0]["PCR_virus_detected"]=="Influenza_A_or_B"
    assert m.df_.iloc[0]["AGT_result"]=="Positive"
    assert m.df_.iloc[0]["FEV"]==1
