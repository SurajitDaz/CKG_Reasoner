from ckg_reasoner.knowledge import KnowledgeBase

def test_metadata_defaults_fill_missing_nodes():
    kb=KnowledgeBase()
    den=kb.vectors('Dengue Fever')
    fev=den['FEV_manifestation']['profile']
    onset=fev['onset']['metadata']
    assert onset['value_type']=='categorical'
    assert onset['unit_policy']=='pass_through'
    assert onset['activation_function']=='categorical_match'
    assert onset['source']=='clinical_knowledge'
    assert onset['canonical_unit'] is None
    assert onset['maintenance']['status']=='active'

def test_explicit_metadata_overrides_defaults():
    kb=KnowledgeBase()
    fev=kb.vectors('Dengue Fever')['FEV_manifestation']['profile']
    t=fev['temperature_c']['metadata']
    d=fev['dura_dy']['metadata']
    assert t['canonical_unit']=='degC'
    assert t['value_type']=='continuous'
    assert t['unit_policy']=='normalize_before_activation'
    assert d['canonical_unit']=='day'
    assert d['activation_function']=='threshold_exponential'

def test_all_manifestation_components_resolve_complete_metadata():
    kb=KnowledgeBase()
    required={'canonical_unit','value_type','unit_policy','activation_function','source','notes','maintenance'}
    for disease in kb.diseases:
        for key, feat in kb.vectors(disease).items():
            if not key.endswith('_manifestation'): continue
            for component in (feat.get('profile') or {}).values():
                if isinstance(component,dict):
                    assert required <= set(component['metadata'])
                    assert {'last_reviewed','status'} <= set(component['metadata']['maintenance'])
