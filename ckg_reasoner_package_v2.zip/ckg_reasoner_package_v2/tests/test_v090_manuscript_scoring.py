import math
import numpy as np
from ckg_reasoner.reasoning import _feature_geometry


def test_feature_geometry_matches_manuscript():
    p,c,rho,ig,m=_feature_geometry([0.8,0.8])
    assert m == 2
    assert np.isclose(p, math.sqrt(.8**2+.8**2))
    assert p > 1.0
    assert np.isclose(c,1.0)
    assert np.isclose(rho,.8)
    assert np.isclose(ig,math.sqrt((1+.8**2)/2))
    assert 0 <= ig <= 1


def test_zero_feature_has_zero_gate():
    p,c,rho,ig,m=_feature_geometry([0,0,0])
    assert (p,c,rho,ig,m)==(0.0,0.0,0.0,0.0,3)
