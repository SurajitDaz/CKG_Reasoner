import numpy as np
import pandas as pd
from ckg_reasoner.evaluation import evaluate_predictions


def test_plain_f1_alias_for_binary_evaluation():
    y_true = pd.Series(["0", "0", "1", "1", "1"])
    y_pred = pd.Series(["0", "1", "1", "0", "1"])
    out = evaluate_predictions(y_true, y_pred, positive_label="1")
    # TP=2, FP=1, FN=1 -> F1=4/(4+1+1)=2/3
    assert np.isclose(out["f1"], 2/3)
    assert np.isclose(out["f1_positive"], 2/3)
