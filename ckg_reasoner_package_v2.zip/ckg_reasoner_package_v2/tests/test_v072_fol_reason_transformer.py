import pandas as pd
from ckg_reasoner import CKGModel, KMeansPartition

def _model():
    df=pd.DataFrame({"id":list(range(101,109)),"Fever":[1,1,0,1,0,1,0,1],"HDH":[1,0,0,1,0,0,1,1],"MYA":[1,0,0,1,0,1,0,1]})
    m=CKGModel(); m.hmap(df,interactive=False,disease_hint="Dengue"); m.graphfit(auto_kmeans=False); return m

def test_reason_blank_until_fol(tmp_path):
    m=_model(); km=m.partition(KMeansPartition(n_clusters=3),positive_disease="Dengue",show=False)
    p=tmp_path/'a.xlsx'; m.output(p,positive_disease="Dengue",method=km)
    x=pd.read_excel(p,keep_default_na=False); assert (x.Reason=='').all(); assert x.Predicted_Result.ne('').all()

def test_reason_populated_only_for_explained_record(tmp_path):
    m=_model(); km=m.partition(KMeansPartition(n_clusters=3),positive_disease="Dengue",show=False)
    m.explain("Dengue",row=0,format="fol")
    p=tmp_path/'b.xlsx'; m.output(p,positive_disease="Dengue",method=km)
    x=pd.read_excel(p,keep_default_na=False); assert x.loc[0,'Reason']!=''; assert x.loc[1,'Reason']==''

def test_report_by_id_executes_fol_and_transformer():
    m=_model(); km=m.partition(KMeansPartition(n_clusters=3),positive_disease="Dengue",show=False)
    r=m.clinical_report(id=102,disease="Dengue",method=km)
    assert 'Clinical decision-support report for ID' in r
    assert 1 in m.fol_explanations_ or len(m.fol_explanations_)==1

def test_uncertain_report_requests_confirmatory_test():
    m=_model(); d=m._infer_positive_disease("Dengue"); obj=m.explain(d,row=0,format="object")[d]
    text=m.clinical_transformer_.transform(obj,predicted_result="indeterminate",uncertainty_test="pathological test")
    assert "pathological test" in text
    assert "uncertain/indeterminate" in text
