from pathlib import Path
import yaml
from ckg_reasoner.legacy_activation import calculate_numeric_score

ROOT = Path(__file__).resolve().parents[1] / 'src' / 'ckg_reasoner' / 'data' / 'diseases'

def load(rel):
    return yaml.safe_load((ROOT/rel).read_text())

def test_dengue_platelet_has_explicit_n_and_d_reference():
    y=load('dengue/dengue_laboratory.yaml')
    p=y['features']['MTP']['profile']['platelet_count']
    assert p['NReference']['min']==150000 and p['NReference']['max']==450000
    assert isinstance(p['NReference'].get('metadata'),dict)
    assert p['DReference']['operator']=='<'
    assert p['DReference']['threshold']==150000
    assert calculate_numeric_score(200000,p,'MTP') == 0.0
    assert calculate_numeric_score(100000,p,'MTP') > 0.0

def test_nreference_drives_trend_abnormality():
    p={'trend':'Decreased','NReference':{'min':4500,'max':11000}}
    assert calculate_numeric_score(6000,p,'LEU') == 0.0
    assert calculate_numeric_score(3000,p,'LEU') > 0.0

def test_fever_profile_ranges_are_untouched():
    y=load('dengue/dengue_manifestation.yaml')
    p=y['features']['FEV']['profile']
    assert p['temperature_c']['min'] == 39.0
    assert p['temperature_c']['max'] == 40.0
    assert p['temperature_c']['metadata']['maintenance']['status'] == 'active'
    assert p['dura_dy']['min'] == 2
    assert p['dura_dy']['max'] == 7
    assert p['dura_dy']['metadata']['maintenance']['status'] == 'active'
    assert 'NReference' not in p['temperature_c'] and 'DReference' not in p['temperature_c']

def test_no_legacy_reference_labels_in_bundled_yamls():
    forbidden={'normal_range','reference_interval','disease_criterion'}
    def walk(x):
        if isinstance(x,dict):
            assert not (forbidden & set(x))
            for v in x.values(): walk(v)
        elif isinstance(x,list):
            for v in x: walk(v)
    for f in ROOT.rglob('*.yaml'):
        walk(yaml.safe_load(f.read_text()))
