from pathlib import Path
from datetime import date
import yaml

EVAL_KEYS = {'value','min','max','operator','threshold','range','values','pattern','unit'}

def _walk(node, path=''):
    if isinstance(node, dict):
        if any(k in node for k in EVAL_KEYS):
            md = node.get('metadata')
            assert isinstance(md, dict), f'missing metadata at {path}'
            assert md.get('notes'), f'missing notes at {path}'
            m = md.get('maintenance')
            assert isinstance(m, dict), f'missing maintenance at {path}'
            reviewed = date.fromisoformat(str(m.get('last_reviewed')))
            assert reviewed <= date.today(), path
            assert m.get('status') == 'active', path
        for k,v in node.items():
            if k != 'metadata':
                _walk(v, f'{path}.{k}' if path else k)
    elif isinstance(node, list):
        for i,v in enumerate(node): _walk(v, f'{path}[{i}]')

def test_all_profile_components_have_non_executable_maintenance_metadata():
    root = Path(__file__).parents[1] / 'src' / 'ckg_reasoner' / 'data' / 'diseases'
    files = sorted(root.rglob('*.yaml'))
    assert len(files) == 12
    for f in files:
        data = yaml.safe_load(f.read_text())
        for feat, fd in (data.get('features') or {}).items():
            _walk(fd.get('profile') or {}, f'{f.name}:{feat}.profile')
