import math
from ckg_reasoner import CKGModel, __version__
from test_v06_estimator_api import cohort

def test_v210_four_component_s0_and_three_component_ranking():
    assert __version__ == "2"
    m=CKGModel(); m.hmap(cohort(),interactive=False,disease_hint="Dengue"); m.graphfit(auto_kmeans=False)
    v=m.clustering_vectors("Dengue")
    assert list(v.columns)==["P_evidence","r","c","Confidence_Score"]
    tr=m.traces_[v.index[0]][m._infer_positive_disease("Dengue")]
    expected=(
        min(1.0,max(0.0,tr.evidence_probability))
        + min(1.0,max(0.0,tr.magnitude_ratio))
        + min(1.0,max(0.0,tr.cosine_similarity))
    )/3.0
    if tr.pathognomonic_triggered:
        assert tr.final_score == 1.0
    elif tr.exclusionary_triggered:
        assert tr.final_score == 0.0
    else:
        assert math.isclose(tr.final_score,expected,rel_tol=1e-12,abs_tol=1e-12)
    assert math.isnan(tr.logistic_similarity)
