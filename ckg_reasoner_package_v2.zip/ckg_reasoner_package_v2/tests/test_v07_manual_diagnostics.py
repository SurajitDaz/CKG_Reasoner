import matplotlib
matplotlib.use("Agg")
import pandas as pd
from ckg_reasoner import CKGModel, KMeansPartition, GaussianPartition, MahalanobisPartition
from test_v06_estimator_api import cohort


def test_diagnostics_manual_n_and_string_api(tmp_path):
    m=CKGModel().hmap(cohort(),interactive=False).graphfit(strategy="exhaustive")
    dk=m.diagnostics("kmeans",positive_disease="Dengue",show=False,min_clusters=2,max_clusters=6)
    dg=m.diagnostics("gaussian",positive_disease="Dengue",show=False,min_components=2,max_components=6)
    dm=m.diagnostics("mahalanobis",positive_disease="Dengue",show=False,min_clusters=2,max_clusters=6)
    assert {"inertia","silhouette"}.issubset(dk.columns)
    assert {"bic","aic"}.issubset(dg.columns)
    assert {"silhouette","davies_bouldin","calinski_harabasz","covariance_condition","mean_assigned_mahalanobis"}.issubset(dm.columns)
    assert dk.attrs.get("basis")=="standardized 4-D [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] vector (post-KG)"
    assert all("[P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)]" in d.attrs.get("basis","") for d in [dg,dm])

    km=m.partition(KMeansPartition(n_clusters=3,min_clusters=2,max_clusters=6),"Dengue",show=False)
    gm=m.partition(GaussianPartition(n_components=3,min_components=2,max_components=6),"Dengue",show=False)
    ma=m.partition(MahalanobisPartition(n_clusters=3,min_clusters=2,max_clusters=6),"Dengue",show=False)
    for obj in [km,gm,ma]:
        assert obj.metadata_["selection_mode"]=="manual"
        assert obj.metadata_["selected_k"]==3
        assert obj.score_dimensions_ == ["P_evidence", "r", "c", "Confidence_Score"]

    ev=m.evaluate("Dengue_Outcome",positive_disease="Dengue",positive_label=1,method="gaussian",n=3,min_components=2,max_components=6)
    et=m.evaluate_tag("Dengue_Outcome",positive_disease="Dengue",positive_label=1,method="mahalanobis",n=3,min_clusters=2,max_clusters=6)
    assert ev["tag_method"]=="gaussian" and et["tag_method"]=="mahalanobis"

    p=tmp_path/"manual_kmeans.xlsx"
    m.output(p,positive_disease="Dengue",method="kmeans",n=3,min_clusters=2,max_clusters=6)
    out=pd.read_excel(p)
    assert "id" in out and "Predicted_Result" in out and "Reason" in out
    assert out["Reason"].isna().all()  # v0.7.2: blank until FOL/explanation executes


def test_full_visualization_family_runs():
    m=CKGModel().hmap(cohort(),interactive=False).graphfit(strategy="exhaustive")
    obj=m.partition(KMeansPartition(n_clusters=3,min_clusters=2,max_clusters=5),"Dengue",show=False)
    obj.visualize(y_true=m.df_["Dengue_Outcome"])
    assert hasattr(obj,"visualization_summary_")
