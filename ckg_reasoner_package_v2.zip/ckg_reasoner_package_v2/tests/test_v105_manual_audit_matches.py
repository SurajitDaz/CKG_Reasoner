from pathlib import Path
import pandas as pd
from ckg_reasoner.manual_audit import _select_cases
from ckg_reasoner import __version__

def test_version_v105():
    assert __version__ == "2"

def test_select_mismatch_and_match_limits():
    df=pd.DataFrame({"Mismatch":[True,False,True,False,False,True,False]})
    bad,good=_select_cases(df,mismatch_limit=2,match_limit=3)
    assert bad == [0,2]
    assert good == [1,3,4]

def test_zero_limits():
    df=pd.DataFrame({"Mismatch":[True,False]})
    bad,good=_select_cases(df,0,0)
    assert bad == [] and good == []
