import math
import pytest
from ckg_reasoner.functions import evidence_gate, positive_similarity_gate

def test_default_gate_matches_compatibility_alias():
    for x in (0.0, 0.2, 0.5, 0.85, 1.0):
        assert evidence_gate(x) == pytest.approx(positive_similarity_gate(x))

def test_parameterized_gate_formula():
    x=0.7; alpha=0.1; beta=4.0; gamma=0.6
    expected=1.0/(1.0+alpha*math.exp(-beta*(x-gamma)))
    assert evidence_gate(x,alpha=alpha,beta=beta,gamma=gamma) == pytest.approx(expected)
