import pandas as pd
from ckg_reasoner import CKGModel, HardAssignment, KMeansPartition, GaussianPartition, MahalanobisPartition


def cohort(n_each=12):
    patterns=[]
    for ns1,igg,igm,temp,plt,wbc,head,myalgia,rash,outcome in [
        (0,0,0,36.8,260000,8200,0,0,0,0),
        (0,0,1,38.0,150000,5200,1,1,0,1),
        (0,1,1,38.8,105000,4100,1,1,0,1),
        (1,1,1,40.0,55000,2800,1,1,1,1),
    ]:
        patterns.append({"NS1":ns1,"IGG":igg,"IGM":igm,"FEV_dura_dy":4,
                         "FEV_temperature_c":temp,"MTP_platelet_count:":plt,
                         "LEU_wbc":wbc,"ART_severity":"Moderate","HDH":head,
                         "ROP":head,"MYA":myalgia,"RSH":rash,"COU":0,"MAL":head,
                         "Dengue_Outcome":outcome})
    rows=[]
    for p in patterns:
        for i in range(n_each):
            r=p.copy(); r["FEV_temperature_c"] += (i%4)*0.03; r["FEV_dura_dy"] += i%2
            rows.append(r)
    return pd.DataFrame(rows)


def test_estimator_style_partition_evaluate_and_output(tmp_path):
    m=CKGModel().hmap(cohort(),interactive=False).graphfit(strategy="exhaustive")
    methods=[HardAssignment(),KMeansPartition(max_clusters=6),GaussianPartition(max_components=6),MahalanobisPartition(max_clusters=6)]
    for est in methods:
        fitted=m.partition(est,positive_disease="Dengue",show=False)
        assert fitted is est and fitted.fitted_
        assert set(fitted.predictions_).issubset({"negative","positive","indeterminate"})
        # Adaptive methods may use ONLY disease-support score dimensions.
        if est.name != "hard":
            assert fitted.score_dimensions_ == ["P_evidence", "r", "c", "Confidence_Score"]
            assert "Dengue_Outcome" not in fitted.score_dimensions_
            assert "NS1" not in fitted.score_dimensions_
        ev_all=m.evaluate("Dengue_Outcome",positive_disease="Dengue",positive_label=1,method=fitted)
        ev_sel=m.evalute_tag("Dengue_Outcome",positive_disease="Dengue",positive_label=1,method=fitted)
        assert ev_all["tag_method"]==est.name
        assert ev_sel["tag_method"]==est.name
        assert "coverage" in ev_sel
        out=tmp_path/f"{est.name}.xlsx"
        m.output(out,positive_disease="Dengue",method=fitted)
        df=pd.read_excel(out)
        assert "id" in df.columns and "Predicted_Result" in df.columns and "Reason" in df.columns
        assert df["Reason"].isna().all()  # v0.7.2: blank until FOL/explanation executes
