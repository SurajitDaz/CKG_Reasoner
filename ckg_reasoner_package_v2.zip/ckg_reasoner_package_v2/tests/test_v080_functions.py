import math
import numpy as np
from ckg_reasoner.functions import normalized_l2_activation, relevancy_threshold_soft_and, get_function, register_function
from ckg_reasoner import CKGModel, ReasoningConfig


def test_normalized_l2_is_bounded_and_within_one_efn():
    assert np.isclose(normalized_l2_activation([.8,.8]), .8)
    assert np.isclose(normalized_l2_activation([1,1,1]), 1.0)
    assert 0 <= normalized_l2_activation([.2,.7,1]) <= 1


def test_requested_56_percent_soft_and_rule():
    i=.75; g=.70
    below=relevancy_threshold_soft_and(relevancy=.55,importance=i,diagnostic_role=g,threshold=.56)
    above=relevancy_threshold_soft_and(relevancy=.56,importance=i,diagnostic_role=g,threshold=.56)
    assert np.isclose(below, i*(g*math.exp(g)))
    assert np.isclose(above, (i*math.exp(i))*(g*math.exp(g)))


def test_exclusionary_role_never_creates_positive_factor():
    assert relevancy_threshold_soft_and(relevancy=.9,importance=1,diagnostic_role=-.5) == 0.0


def test_registry_custom_function():
    register_function('activation','test_constant',lambda values,**kw: .42,overwrite=True)
    assert get_function('activation','test_constant')([1,2]) == .42


def test_default_config_uses_corrected_functions():
    c=ReasoningConfig()
    assert c.activation_function == 'information_gate'
    assert c.soft_and_function == 'manuscript_direct'
    assert c.relevancy_threshold == .56
