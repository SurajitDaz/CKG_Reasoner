import math
from ckg_reasoner.functions import disease_ranking_score


def test_zero_coordinate_does_not_veto_other_components():
    # canonical total = 1 + 1 + 1 = 3
    assert math.isclose(disease_ranking_score(0.4, 0.0, 0.9, 1, 1, 1), 1.3/3.0)
    assert math.isclose(disease_ranking_score(-0.4, 0.8, 0.9, 1, 1, 1), 1.7/3.0)


def test_rank_is_zero_when_patient_components_are_zero():
    assert disease_ranking_score(0.0, 0.0, 0.0, 1, 1, 1) == 0.0


def test_rank_uses_actual_canonical_total_not_fixed_three():
    # A disease with no canonical profile-similarity components can legitimately
    # have a denominator different from three.
    assert math.isclose(disease_ranking_score(0.5, 0.0, 0.0, 1.0, 0.0, 0.0), 0.5)


def test_nonpositive_canonical_total_returns_zero():
    assert disease_ranking_score(0.5, 0.5, 0.5, 0.0, 0.0, 0.0) == 0.0
