import numpy as np
import pandas as pd
from ckg_reasoner import CKGModel, KMeansPartition, GaussianPartition, MahalanobisPartition, __version__

def test_v109_clustering_vector_is_pevidence_r_c_confidence():
    assert __version__ == "2"
    from test_v06_estimator_api import cohort
    df=cohort()
    m=CKGModel(); m.hmap(df,interactive=False,disease_hint="Dengue"); m.graphfit(auto_kmeans=False)
    v=m.clustering_vectors("Dengue")
    assert list(v.columns)==["P_evidence","r","c","Confidence_Score"]
    for cls in (KMeansPartition, GaussianPartition, MahalanobisPartition):
        kw={"n_clusters":3,"min_clusters":2,"max_clusters":4} if cls is not GaussianPartition else {"n_components":3,"min_components":2,"max_components":4}
        obj=m.partition(cls(**kw),"Dengue",show=False)
        assert obj.score_dimensions_==["P_evidence","r","c","Confidence_Score"]
        assert "ranking score R(D_j) is not used for fitting" in obj.metadata_["clustering_basis"]
        assert np.allclose(obj.score_matrix_.loc[v.index,["P_evidence","r","c","Confidence_Score"]],v,equal_nan=True)
