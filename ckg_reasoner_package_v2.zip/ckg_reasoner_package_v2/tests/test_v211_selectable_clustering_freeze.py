import numpy as np, pandas as pd
from ckg_reasoner.kmeans import diagnose_kmeans
from ckg_reasoner.gaussian import diagnose_gaussian
from ckg_reasoner.separation import auto_kmeans_scores, gaussian_separation

def frame(n=30):
    x=np.linspace(.05,.95,n)
    return pd.DataFrame({'P_evidence':x,'r':np.clip(x+.03*np.sin(np.arange(n)),0,1),'c':np.clip(x+.04*np.cos(np.arange(n)),0,1),'Confidence_Score':np.linspace(.9,.4,n)})

def test_selected_variable_missing_confidence_does_not_drop():
    f=frame(); f.loc[0:4,'Confidence_Score']=np.nan
    out=auto_kmeans_scores(f,'Dengue',min_k=2,max_k=4,variables=['r','c'])
    assert len(out.assignments)==len(f)

def test_selected_constant_is_rejected_even_if_unselected_vary():
    f=frame(); f['r']=.5
    try: auto_kmeans_scores(f,'Dengue',min_k=2,max_k=4,variables=['r'])
    except ValueError as e: assert 'constant' in str(e)
    else: raise AssertionError('constant selected vector must fail')

def test_diagnostics_use_selected_variables_and_separate_recommendations():
    f=frame(); d=diagnose_kmeans(f,'Dengue',min_clusters=2,max_clusters=5,show=False,variables=['r','c'])
    assert d.attrs['variables']==['r','c']; assert isinstance(d.attrs['elbow_recommended_n'],int); assert isinstance(d.attrs['silhouette_recommended_n'],int)
    g=diagnose_gaussian(f,'Dengue',min_components=2,max_components=4,show=False,variables=['P_evidence'])
    assert g.attrs['variables']==['P_evidence']; assert isinstance(g.attrs['bic_recommended_n'],int)

def test_one_dimensional_gmm_fit():
    f=frame(); out=gaussian_separation(f,'Dengue',min_components=2,max_components=4,variables=['P_evidence'])
    assert out.metadata['score_dimensions']==['P_evidence']

def test_kmeans_combined_best_k_and_optional_print(capsys):
    import numpy as np, pandas as pd
    from ckg_reasoner.kmeans import diagnose_kmeans
    n=36
    df=pd.DataFrame({
        'disease':['Dengue']*n,
        'P_evidence':np.r_[np.linspace(.1,.2,12),np.linspace(.45,.55,12),np.linspace(.8,.9,12)],
        'r':np.r_[np.linspace(.1,.2,12),np.linspace(.45,.55,12),np.linspace(.8,.9,12)],
        'c':np.r_[np.linspace(.1,.2,12),np.linspace(.45,.55,12),np.linspace(.8,.9,12)],
        'Confidence_Score':[.8]*n,
    })
    d=diagnose_kmeans(df,'Dengue',max_clusters=6,show=False,print_recommendations=False)
    assert capsys.readouterr().out == ''
    assert isinstance(d.attrs['elbow_recommended_n'],int)
    assert isinstance(d.attrs['silhouette_recommended_n'],int)
    assert isinstance(d.attrs['best_k'],int)
    assert d.attrs['recommended_n']==d.attrs['best_k']
    assert 'combined_score' in d.columns
    diagnose_kmeans(df,'Dengue',max_clusters=6,show=False,print_recommendations=True)
    out=capsys.readouterr().out
    assert 'Elbow-recommended cluster number:' in out
    assert 'Silhouette-recommended cluster number:' in out
    assert 'Combined best cluster number:' in out

def test_kmeans_single_candidate_never_recommends_k1():
    import pandas as pd
    from ckg_reasoner.kmeans import diagnose_kmeans
    df=pd.DataFrame({
        "P_evidence":[.1,.2,.3,.7,.8,.9],
        "r":[.1,.2,.3,.7,.8,.9],
        "c":[.1,.2,.3,.7,.8,.9],
        "Confidence_Score":[.9]*6,
    })
    d=diagnose_kmeans(df,"Dengue",min_clusters=2,max_clusters=2,show=False)
    assert d.attrs["elbow_recommended_n"] == 2
    assert d.attrs["silhouette_recommended_n"] == 2
    assert d.attrs["best_k"] == 2
