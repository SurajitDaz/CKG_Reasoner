import numpy as np, pandas as pd
from ckg_reasoner.separation import _ordering_value

def test_partition_ordering_uses_additive_not_obsolete_product():
    x=pd.DataFrame({'P_evidence':[0.0,0.2],'r':[0.9,0.2],'c':[0.9,0.2]})
    v=_ordering_value(x)
    assert np.allclose(v,[1.8,0.6])
    assert v[0] > v[1]  # zero P must not annihilate r,c
