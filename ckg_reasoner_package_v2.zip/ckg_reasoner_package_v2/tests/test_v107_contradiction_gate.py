import math
from ckg_reasoner.functions import (
    positive_similarity_gate,
    manuscript_evidence_contributions,
    canonical_net_evidence,
    normalized_evidence_probability,
)

def test_contradiction_uses_same_nonlinear_transform_on_complement():
    ig=0.82
    C=0.7
    _,ncon=manuscript_evidence_contributions(
        information_gate=ig, diagnostic_role=0.85,
        importance=1.0, support=0.8, contradiction=C)
    expected=positive_similarity_gate(1.0-ig)*C
    assert math.isclose(ncon,expected,rel_tol=1e-12)

def test_low_similarity_does_not_receive_raw_complement_penalty():
    ig=0.20
    C=0.8
    _,ncon=manuscript_evidence_contributions(
        information_gate=ig, diagnostic_role=0.85,
        importance=1.0, support=0.8, contradiction=C)
    assert math.isclose(ncon,positive_similarity_gate(0.80)*C,rel_tol=1e-12)
    assert not math.isclose(ncon,(1.0-ig)*C,rel_tol=1e-6)

def test_canonical_denominator_uses_f0_contradiction():
    pars=[(0.85,1.0,0.8,0.5),(0.70,0.7,0.5,0.2)]
    den=canonical_net_evidence(pars)
    expected=(
        sum(positive_similarity_gate(1.0)*max(g,0.0)*I*S for g,I,S,C in pars)
        - sum(positive_similarity_gate(0.0)*abs(C) for g,I,S,C in pars)
    )
    assert math.isclose(den,expected,rel_tol=1e-12)
    assert normalized_evidence_probability(den,den)==1.0
