import pytest
from ckg_reasoner.functions import positive_similarity_gate, manuscript_evidence_contributions

def test_positive_similarity_gate_formula_and_transformed_contradiction():
    gated=positive_similarity_gate(0.8)
    assert gated == pytest.approx(0.9238420944089875)
    p,n=manuscript_evidence_contributions(information_gate=0.8, diagnostic_role=0.85, importance=1.0, support=0.8, contradiction=0.7)
    assert p == pytest.approx(0.6282126241981114)
    assert n == pytest.approx(positive_similarity_gate(1.0-0.8)*0.7)

def test_positive_gate_is_monotone():
    assert positive_similarity_gate(0.2) < positive_similarity_gate(0.5) < positive_similarity_gate(0.85) < positive_similarity_gate(1.0)
