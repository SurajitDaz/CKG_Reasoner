from ckg_reasoner.legacy_activation import construct_patient_with_reference_scores
from ckg_reasoner.reasoning import _component_activations


def _ref(expected="Influenza_A_or_B"):
    return {"PCR": {"feature_name":"PCR", "profile":{"virus_detected": expected},
                    "diagnostic_role":"Pathognomonic", "importance":"Critical",
                    "support":"Decisive", "contradiction":"Strong"}}


def test_unknown_categorical_exact_match_becomes_numeric_one():
    d=construct_patient_with_reference_scores({"PCR_virus_detected":"Influenza_A_or_B"}, _ref())
    c=d["PCR"]["components"]["virus_detected"]
    assert c["patient_score"] == 1.0
    assert _component_activations(d["PCR"]) == [1.0]


def test_unknown_categorical_mismatch_becomes_numeric_zero():
    d=construct_patient_with_reference_scores({"PCR_virus_detected":"SARS_CoV_2"}, _ref())
    c=d["PCR"]["components"]["virus_detected"]
    assert c["patient_score"] == 0.0
    assert _component_activations(d["PCR"]) == [0.0]
