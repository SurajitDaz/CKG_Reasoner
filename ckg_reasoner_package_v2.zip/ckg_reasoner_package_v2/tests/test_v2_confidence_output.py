import math
from types import SimpleNamespace
from ckg_reasoner.confidence import assess_confidence


def _row(name,g,I,S,observed=True,nobs=1,nexp=1):
    comps={}
    for i in range(nexp):
        comps[f'c{i}']={
            'from_reference':True,'ref_value':1,'reference_score':1.0,
            'from_patient': i<nobs,'patient_value': 1 if i<nobs else ''
        }
    return {'feature':name,'name':name,'diagnostic_role':g,'clinical_importance':I,
            'support':S,'contradiction':0.0,'observed':observed,'components':comps}


def test_missing_major_does_not_change_trace_score_and_reduces_coverage():
    rows=[_row('A',.85,.75,.8,True),_row('B',.70,1,.8,False,0,1),_row('C',.50,.5,.6,True)]
    tr=SimpleNamespace(disease='Dengue',feature_rows=rows,observed_features=2,missing_features=1,final_score=.87)
    a=assess_confidence(tr)
    expected=(.85*.75*.8 + .50*.5*.6)/(.85*.75*.8 + .70*1*.8 + .50*.5*.6)
    assert math.isclose(a.evidence_coverage,expected,rel_tol=1e-12)
    assert a.confidence_score==a.evidence_coverage
    assert a.missing_major==['B']
    assert tr.final_score==.87


def test_partial_components_are_fractional_coverage():
    rows=[_row('B',.70,1,.8,True,3,4)]
    tr=SimpleNamespace(disease='Dengue',feature_rows=rows,observed_features=1,missing_features=0)
    a=assess_confidence(tr)
    assert math.isclose(a.evidence_coverage,.75)
    assert a.partial_features==1
    assert a.observed_components==3 and a.expected_components==4 and a.missing_components==1
