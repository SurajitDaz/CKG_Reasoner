import numpy as np
from ckg_reasoner import CKGModel, __version__

def test_v109_uncertainty_uses_4d_clustering_vector():
    assert __version__ == "2"
    from test_v06_estimator_api import cohort
    df = cohort()
    m = CKGModel(); m.hmap(df, interactive=False, disease_hint="Dengue"); m.graphfit(auto_kmeans=False)
    out = m.Uncertainty("Dengue", row=0)
    exp = next(iter(out.values()))["exploratory"]
    # No legacy 1-D routing: if clustering is available it must declare exactly [P_evidence, M].
    if exp["kmeans_metadata"] is not None:
        assert exp["kmeans_metadata"]["score_dimensions"] == ["P_evidence", "r", "c", "Confidence_Score"]
        assert "ranking score R(D_j) is not used for fitting" in exp["kmeans_metadata"]["clustering_basis"]
        assert {"P_evidence", "r", "c", "Confidence_Score"}.issubset(exp["kmeans"].columns)
