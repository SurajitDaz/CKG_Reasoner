import math
from ckg_reasoner.functions import f_xe3
from ckg_reasoner.function_policy import load_function_assignments, apply_variable_function


def test_f_xe3_remains_available_as_inactive_legacy_function():
    assert math.isclose(f_xe3(0.5), 0.5 * math.exp(3.0))


def test_diagnostic_role_transform_is_disabled():
    p=load_function_assignments()
    y,name=apply_variable_function("diagnostic_role",0.85,p)
    assert name == "identity"
    assert y == 0.85


def test_importance_transform_is_disabled():
    p=load_function_assignments()
    for x in (0.50,0.55,0.75,1.0):
        y,name=apply_variable_function("clinical_importance",x,p)
        assert name == "identity"
        assert y == x
