from pathlib import Path
import yaml

ROOT=Path(__file__).resolve().parents[1]/'src'/'ckg_reasoner'/'data'/'diseases'

def test_all_12_yaml_files_parse():
    files=sorted(ROOT.glob('*/*.yaml'))
    assert len(files)==12
    for p in files:
        assert isinstance(yaml.safe_load(p.read_text(encoding='utf-8')),dict)

def test_reference_and_trend_schema():
    for p in ROOT.glob('*/*.yaml'):
        data=yaml.safe_load(p.read_text(encoding='utf-8')) or {}
        for feat in (data.get('features') or {}).values():
            for comp in (feat.get('profile') or {}).values():
                if not isinstance(comp,dict): continue
                assert 'normal_range' not in comp
                assert 'reference' not in comp
                for key in ('NReference','DReference'):
                    if key in comp:
                        assert isinstance(comp[key],dict)
                        assert isinstance(comp[key].get('metadata'),dict)
                if 'trend' in comp:
                    assert isinstance(comp['trend'],dict)
                    assert 'value' in comp['trend']
                    assert isinstance(comp['trend'].get('metadata'),dict)

def test_conditions_are_recursive_and_or_trees():
    def check(node):
        assert isinstance(node,dict)
        assert str(node.get('operator','')).upper() in {'AND','OR'}
        children=node.get('components')
        assert isinstance(children,list) and children
        for c in children:
            if isinstance(c,dict): check(c)
            else: assert isinstance(c,str) and c
    for p in ROOT.glob('*/*.yaml'):
        data=yaml.safe_load(p.read_text(encoding='utf-8')) or {}
        for feat in (data.get('features') or {}).values():
            if 'condition' in feat: check(feat['condition'])

def test_fever_ranges_not_rewritten_as_reference():
    for p in ROOT.glob('*/*.yaml'):
        data=yaml.safe_load(p.read_text(encoding='utf-8')) or {}
        fev=(data.get('features') or {}).get('FEV')
        if not fev: continue
        for comp in (fev.get('profile') or {}).values():
            if isinstance(comp,dict) and 'min' in comp and 'max' in comp:
                # Original direct range remains direct range.
                assert 'NReference' not in comp and 'DReference' not in comp
