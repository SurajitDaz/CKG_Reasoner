from pathlib import Path
import yaml
from ckg_reasoner.knowledge import KnowledgeBase
from ckg_reasoner.legacy_activation import calculate_numeric_score

ROOT=Path(__file__).resolve().parents[1]/'src'/'ckg_reasoner'/'data'/'diseases'

def test_three_disease_yaml_loads_and_has_dataset_evidence():
    for disease in ('dengue','malaria','influenza'):
        p=ROOT/disease/f'{disease}_laboratory.yaml'
        d=yaml.safe_load(p.read_text(encoding='utf-8'))
        assert d['dataset_evidence']['build_date'] in {'2026-09-19','2026-09-20'}
        assert d['dataset_evidence']['sources']
        assert d['features']

def test_malaria_hgb_is_single_usable_feature():
    d=yaml.safe_load((ROOT/'malaria'/'malaria_laboratory.yaml').read_text())
    h=d['features']['HGB']
    comp=h['profile']['hemoglobin_g_dl']
    assert comp['trend']['value']=='Decreased'
    assert comp['severity_context']['cdc_severe_adult_threshold']['threshold']==7.0
    assert comp['NReference']['metadata']['canonical_unit']=='g/dL'

def test_yaml_range_drives_numeric_activation():
    ref={'trend':'Decreased','DReference':{'operator':'<','threshold':150000},'NReference':{'min':150000,'max':450000},'canonical_unit':'/uL'}
    assert calculate_numeric_score(150000,ref,'platelet_count')==0.0
    assert calculate_numeric_score(96000,ref,'platelet_count')>0.8

def test_knowledge_base_compatibility():
    kb=KnowledgeBase(ROOT)
    assert {'dengue','malaria','influenza'} <= set(kb.reference_vectors)
    for d in ('dengue','malaria','influenza'):
        assert len(kb.reference_vectors[d])>0
