import pandas as pd
from ckg_reasoner.units import convert_value, normalize_mapped_dataframe

def test_equivalent_platelet_units():
    assert convert_value(150000,'/cumm','/uL') == 150000
    assert convert_value(150000000,'/mL','/uL') == 150000
    assert convert_value(150,'10^9/L','/uL') == 150000

def test_temperature_and_hemoglobin_units():
    assert abs(convert_value(98.6,'degF','degC')-37.0) < 1e-9
    assert convert_value(150,'g/L','g/dL') == 15

def test_all_mapped_components_are_audited():
    df=pd.DataFrame({'Platelets(/mL)':[150000000], 'NS1':[1]})
    mapping={'Platelets(/mL)':'MTP_platelet_count','NS1':'NS1'}
    renamed=df.rename(columns=mapping)
    out,audit=normalize_mapped_dataframe(renamed,mapping)
    assert len(audit)==2
    by={x['ontology_heading']:x for x in audit}
    assert by['MTP_platelet_count']['unit_status']=='converted'
    assert by['NS1']['unit_status']=='pass_through'
    assert out['MTP_platelet_count'].iloc[0]==150000
