import pandas as pd
from ckg_reasoner.separation import auto_kmeans_scores


def test_kmeans_accepts_four_dimensional_confidence_s0():
    x=pd.DataFrame({
        "P_evidence":[.1,.12,.15,.8,.85,.9],
        "r":[.2,.22,.25,.75,.8,.85],
        "c":[.15,.18,.2,.8,.82,.9],
        "Confidence_Score":[.4,.5,.6,.7,.8,.9],
    })
    out=auto_kmeans_scores(x,"Dengue",min_k=2,max_k=2,n_clusters=2)
    assert out.metadata["score_dimensions"] == ["P_evidence","r","c","Confidence_Score"]
    assert "Confidence_Score" in out.assignments.columns
    assert set(out.assignments["Predicted_Result"]) == {"negative","positive"}
