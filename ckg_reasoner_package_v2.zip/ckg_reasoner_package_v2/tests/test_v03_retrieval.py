import pandas as pd
from ckg_reasoner import CKGModel

def _df(): return pd.DataFrame([{"FEV_temperature_c":39.5,"FEV_dura_dy":4,"HDH":1,"ROP":1,"MYA":1,"NS1":1}])

def test_retrieval_candidate_audit():
    m=CKGModel().hmap(_df(),interactive=False).graphfit(strategy="retrieval",candidate_k=2)
    audit=m.candidate_graphs(0)
    assert audit["strategy"]=="retrieval"
    assert audit["candidate_count"] <= 2
    assert len(audit["candidates"]) <= 2

def test_exhaustive_backward_compatibility():
    m=CKGModel().hmap(_df(),interactive=False).graphfit(strategy="exhaustive")
    assert m.candidate_graphs(0)["candidate_count"]==3
    assert {"Dengue Fever","Influenza","Malaria"}.issubset(set(m.selected_diseases()))
