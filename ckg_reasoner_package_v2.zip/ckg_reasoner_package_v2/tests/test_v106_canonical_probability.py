import math
from ckg_reasoner.functions import (positive_similarity_gate, canonical_net_evidence, normalized_evidence_probability)

def test_canonical_probability_is_direct_ratio_no_sigmoid():
    pars=[(0.85,1.0,0.8,0.5),(0.70,0.7,0.5,0.0)]
    den=canonical_net_evidence(pars)
    expected=(positive_similarity_gate(1.0)*(0.85*1.0*0.8 + 0.70*0.7*0.5)
              - positive_similarity_gate(0.0)*(0.5+0.0))
    assert math.isclose(den,expected,rel_tol=1e-12)
    assert normalized_evidence_probability(den,den)==1.0
    assert math.isclose(normalized_evidence_probability(0.25*den,den),0.25,rel_tol=1e-12)
    assert normalized_evidence_probability(-0.1*den,den) < 0.0
