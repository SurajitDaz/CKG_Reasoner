import numpy as np, pandas as pd
from ckg_reasoner.separation import mahalanobis_separation, MahalanobisPartition, CLUSTERING_VARIABLES
from ckg_reasoner.mahalanobis import diagnose_mahalanobis

def frame(n=36):
    rng=np.random.default_rng(91)
    return pd.DataFrame({'P_evidence':rng.normal(size=n),'r':rng.normal(size=n),'c':rng.normal(size=n),'Confidence_Score':rng.normal(size=n)})

def test_mahalanobis_none_means_all_four():
    f=frame(); out=mahalanobis_separation(f,'Dengue',min_clusters=2,max_clusters=4,variables=None)
    assert out.metadata['score_dimensions']==list(CLUSTERING_VARIABLES)

def test_mahalanobis_subset_controls_geometry():
    f=frame(); out=mahalanobis_separation(f,'Dengue',min_clusters=2,max_clusters=4,variables=['r','c'])
    assert out.metadata['score_dimensions']==['r','c']
    assert np.asarray(out.metadata['pooled_covariance_matrix']).shape==(2,2)
    assert np.asarray(out.metadata['ordered_reference_centroids']).shape[1]==2

def test_mahalanobis_one_dimension():
    f=frame(); out=mahalanobis_separation(f,'Dengue',min_clusters=2,max_clusters=3,variables=['P_evidence'])
    assert np.asarray(out.metadata['pooled_covariance_matrix']).shape==(1,1)

def test_mahalanobis_diagnostics_subset():
    d=diagnose_mahalanobis(frame(),'Dengue',min_clusters=2,max_clusters=4,show=False,variables=['P_evidence','Confidence_Score'])
    assert d.attrs['variables']==['P_evidence','Confidence_Score']

def test_mahalanobis_estimator_accepts_variables():
    obj=MahalanobisPartition(min_clusters=2,max_clusters=4,variables=['r','c']).fit(frame(),'Dengue')
    assert obj.metadata_['score_dimensions']==['r','c']

def test_mahalanobis_reason_reports_selected_variables_not_fixed_4d():
    import inspect
    from ckg_reasoner.model import CKGModel
    src = inspect.getsource(CKGModel._selective_tags)
    assert "using selected post-KG variables {obj.metadata_.get('score_dimensions')}" in src
    assert "using the 4-D S0=[P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)] vector" not in src
