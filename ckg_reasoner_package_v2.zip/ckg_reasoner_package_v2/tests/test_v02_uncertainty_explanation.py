import pandas as pd
from ckg_reasoner import CKGModel


def _model():
    df=pd.DataFrame([{
        "FEV_temperature_c":39.5,"FEV_dura_dy":4,
        "HDH":1,"ROP":1,"MYA":1,"NS1":1
    }])
    return CKGModel().hmap(df,interactive=False).graphfit()


def test_high_dimensional_missingness_returns_safe_outer_bound():
    m=_model()
    out=m.bounded_support("Dengue")["Dengue Fever"]
    assert out["lower"] == 0.0 and out["upper"] == 1.0
    assert out["decision_label"] == "indeterminate"
    assert out["method"] == "certified_outer_score_range"
    assert out["exact_extrema"] is False
    assert out["certified_outer_bound"] is True


def test_declared_domains_enable_exact_enumeration():
    m=_model()
    tr=m.traces_[0]["Dengue Fever"]
    missing=[r["feature"] for r in tr.feature_rows if not r["observed"]]
    assert missing
    domains={f:0.0 for f in missing}
    domains[missing[0]]=(0.0,1.0)
    m.set_admissible_domains(domains,disease="Dengue")
    out=m.bounded_support("Dengue")["Dengue Fever"]
    assert out["method"] == "exact_enumeration"
    assert out["exact_extrema"] is True
    assert 0.0 <= out["lower"] <= out["upper"] <= 1.0


def test_explanation_fol_report_and_verifier():
    m=_model()
    facts=m.explain("Dengue",format="fol")["Dengue Fever"]
    assert "DiagnosticSupport" in facts
    assert "SupportInterval" in facts
    assert "PathognomonicTriggered" in facts
    report=m.explainable_layer("Dengue",format="report")["Dengue Fever"]
    assert "Continuous reasoning:" in report
    assert "Deterministic reasoning:" in report
    assert "Uncertainty:" in report
    check=m.verify_explanation("Dengue")["Dengue Fever"]
    assert check["valid"] is True, check["errors"]
