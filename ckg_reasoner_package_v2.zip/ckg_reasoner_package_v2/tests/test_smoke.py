import pandas as pd
from ckg_reasoner import CKGModel

def test_smoke():
    df=pd.DataFrame([{"FEV_temperature_c":39.5,"FEV_dura_dy":4,"HDH":1,"ROP":1,"MYA":1,"NS1":1}])
    m=CKGModel().hmap(df,interactive=False).graphfit()
    assert len(m.results_)==1
    assert {"Dengue Fever","Influenza","Malaria"}.issubset(set(m.selected_diseases()))
    assert "Dengue Fever" in m.Continuous_reasoning("Dengue")
