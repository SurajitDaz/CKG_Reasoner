import pandas as pd
from ckg_reasoner import CKGModel, HardAssignment


def test_manual_mismatch_latex_is_optional_and_contains_arithmetic(tmp_path):
    # Use a deliberately inverted truth column so at least one mismatch is guaranteed.
    df=pd.DataFrame({
        "id":[1,2,3,4],
        "NS1":[1,0,1,0],
        "HDH":[1,0,1,0],
        "MYA":[1,0,1,0],
        "Result":[0,1,0,1],
    })
    m=CKGModel(); m.hmap(df,interactive=False,disease_hint="Dengue",target="Result"); m.graphfit(auto_kmeans=False)
    hard=m.partition(HardAssignment(negative_threshold=0.4,positive_threshold=0.6),positive_disease="Dengue",show=False)
    xlsx=tmp_path/"audit.xlsx"
    m.output(xlsx,positive_disease="Dengue",method=hard,manual_log=True,manual_log_format="latex",manual_log_limit=10)
    assert xlsx.exists(); assert m.manual_log_path_.exists()
    text=m.manual_log_path_.read_text(encoding="utf-8")
    assert "Feature-level calculations" in text
    assert "pcon=f(IG)" in text
    assert "Disease-level reconstruction" in text
    assert "P_{evidence}" in text
    assert "M_j" in text


def test_manual_log_off_by_default(tmp_path):
    df=pd.DataFrame({"id":[1,2],"NS1":[1,0],"Result":[1,0]})
    m=CKGModel(); m.hmap(df,interactive=False,disease_hint="Dengue",target="Result"); m.graphfit(auto_kmeans=False)
    m.output(tmp_path/"plain.xlsx",positive_disease="Dengue",method="hard")
    assert m.manual_log_path_ is None
