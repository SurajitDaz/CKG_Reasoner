import yaml
from pathlib import Path
from ckg_reasoner.legacy_activation import calculate_numeric_score
ROOT=Path(__file__).resolve().parents[1]/"src"/"ckg_reasoner"/"data"/"diseases"

def test_dengue_uses_disease_criterion_not_reference_interval():
    d=yaml.safe_load((ROOT/"dengue"/"dengue_laboratory.yaml").read_text())
    p=d["features"]["MTP"]["profile"]["platelet_count"]
    assert p["NReference"]["min"]==150000
    assert p["DReference"]["threshold"]==150000
    assert p["severity_context"]["legacy_dhf_threshold"]["threshold"]==100000
    assert calculate_numeric_score(160000,p,"platelet_count")==0.0
    assert calculate_numeric_score(149999,p,"platelet_count")>0.0
    assert calculate_numeric_score(100000,p,"platelet_count")>0.8

def test_dengue_leukopenia_criterion_is_5000():
    d=yaml.safe_load((ROOT/"dengue"/"dengue_laboratory.yaml").read_text())
    p=d["features"]["LEU"]["profile"]["wbc"]
    assert p["DReference"]["threshold"]==5000
    assert calculate_numeric_score(5100,p,"wbc")==0.0
    assert calculate_numeric_score(4000,p,"wbc")>0.0
