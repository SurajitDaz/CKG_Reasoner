import pandas as pd
from ckg_reasoner import CKGModel


def _cohort(n=30):
    low={
        "NS1":0,"IGG":0,"IGM":0,"FEV_dura_dy":1,"FEV_temperature_c":37.0,
        "MTP_platelet_count:":230000,"LEU_wbc":7500,"ART_severity":"None",
        "HDH":0,"ROP":0,"MYA":0,"RSH":0,"Dengue_Outcome":0,
    }
    middle={
        "NS1":0,"IGG":1,"IGM":1,"FEV_dura_dy":4,"FEV_temperature_c":38.5,
        "MTP_platelet_count:":120000,"LEU_wbc":4500,"ART_severity":"Moderate",
        "HDH":1,"ROP":0,"MYA":1,"RSH":0,"Dengue_Outcome":1,
    }
    high={
        "NS1":1,"IGG":1,"IGM":1,"FEV_dura_dy":5,"FEV_temperature_c":39.5,
        "MTP_platelet_count:":70000,"LEU_wbc":3200,"ART_severity":"Severe",
        "HDH":1,"ROP":1,"MYA":1,"RSH":1,"Dengue_Outcome":1,
    }
    patterns=[low,middle,high]
    return pd.DataFrame([patterns[i%3].copy() for i in range(n)])


def test_id_auto_kmeans_output_and_tag_eval(tmp_path):
    df=_cohort()
    assert "id" not in df.columns
    m=CKGModel()
    m.hmap(df, interactive=False)
    assert m.id_created_ is True
    assert m.df_["id"].tolist() == list(range(1,len(df)+1))
    assert m.row_from_id(1) == m.df_.index[0]

    m.graphfit(strategy="exhaustive")
    assert m.kmeans_results_ is not None
    clusters=sorted(m.kmeans_results_["Cluster"].unique())
    assert clusters == list(range(len(clusters)))
    assert m.optimal_k_ == len(clusters)
    assert m.optimal_k_ >= 2

    tags=m.tag("Dengue")
    assert set(tags["Predicted_Result"]).issubset({"positive","negative","indeterminate"})

    metrics=m.evalute_tag("Dengue_Outcome",positive_disease="Dengue",positive_label=1)
    assert "coverage" in metrics
    assert "n_indeterminate" in metrics

    p=tmp_path/"result.xlsx"
    returned=m.output(p,positive_disease="Dengue")
    out=pd.read_excel(returned)
    assert "id" in out.columns
    assert "Predicted_Result" in out.columns
    assert "Reason" in out.columns
    assert len(out)==len(df)
