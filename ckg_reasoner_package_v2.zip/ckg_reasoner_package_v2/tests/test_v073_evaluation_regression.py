import numpy as np
import pandas as pd
import pytest
from ckg_reasoner.evaluation import encode_binary_truth, evaluate_predictions


def test_text_positive_negative_encoding():
    y = pd.Series(["positive", "negative", "Positive", " negative "])
    assert encode_binary_truth(y, positive_label=1).tolist() == [1, 0, 1, 0]


def test_numeric_encoding():
    y = pd.Series([1, 0, 1, 0])
    assert encode_binary_truth(y, positive_label=1).tolist() == [1, 0, 1, 0]


def test_ambiguous_labels_raise_instead_of_silent_all_zero():
    with pytest.raises(ValueError):
        encode_binary_truth(pd.Series(["case", "control", "case"]), positive_label=1)


def test_confusion_matrix_and_positive_f1_are_explicit():
    # TN=2 FP=1 FN=2 TP=3
    yt = pd.Series([0,0,0,1,1,1,1,1]).astype(str)
    yp = pd.Series([0,0,1,0,0,1,1,1]).astype(str)
    out = evaluate_predictions(yt, yp, positive_label="1")
    assert (out["tn"], out["fp"], out["fn"], out["tp"]) == (2,1,2,3)
    assert np.isclose(out["f1_positive"], 6/9)
