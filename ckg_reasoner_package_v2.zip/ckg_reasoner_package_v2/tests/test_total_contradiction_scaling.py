import math
from ckg_reasoner.functions import reduce_total_contradiction, manuscript_evidence_contributions

def test_total_ncon_uses_unit_scaling_without_discount():
    assert reduce_total_contradiction(4.0) == 4.0
    assert math.isclose(reduce_total_contradiction(0.8), 0.8, rel_tol=1e-12)

def test_feature_ncon_formula_itself_is_not_changed():
    _, n = manuscript_evidence_contributions(
        information_gate=0.4, diagnostic_role=0.85,
        importance=1.0, support=0.8, contradiction=0.7)
    # No aggregate discount is applied; the feature equation remains directly auditable.
    from ckg_reasoner.functions import positive_similarity_gate
    assert math.isclose(n, positive_similarity_gate(0.6)*0.7, rel_tol=1e-12)
