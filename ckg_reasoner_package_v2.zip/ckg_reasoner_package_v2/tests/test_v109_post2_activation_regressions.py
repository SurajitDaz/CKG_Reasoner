import numpy as np
from ckg_reasoner import CKGModel, __version__
from ckg_reasoner.legacy_activation import construct_patient_with_reference_scores


def test_version_post2():
    assert __version__ == "2"


def test_igg_igm_are_not_skipped_and_change_dengue_activation():
    m=CKGModel()
    vec=m.kb.vectors("Dengue")
    a=construct_patient_with_reference_scores({"IGG":1,"IGM":1},vec)
    assert "IGG_laboratory" in a and "IGM_laboratory" in a
    assert a["IGG_laboratory"]["components"]["default"]["patient_score"] > 0
    assert a["IGM_laboratory"]["components"]["default"]["patient_score"] > 0


def test_default_zero_does_not_annihilate_positive_binary_patient_value():
    ref={"X_laboratory":{"feature_name":"X","name":"X","stage":"lab","default":0,
         "profile":{"result":{"value":"Positive"}},"diagnostic_role":"Major",
         "importance":"Critical","support":"Strong","contradiction":"Strong","expected_frequency":"Common"}}
    a=construct_patient_with_reference_scores({"X":1},ref)
    c=a["X_laboratory"]["components"]["default"]
    assert c["reference_score"] == 0
    assert c["patient_score"] == 1


def test_duplicate_feature_codes_are_preserved_by_stage():
    m=CKGModel(); vec=m.kb.vectors("Malaria")
    a=construct_patient_with_reference_scores({"VOM":1},vec)
    assert "VOM_manifestation" in a
    assert "VOM_progression" in a
    assert a["VOM_manifestation"]["reference_metadata"]["stage"] != a["VOM_progression"]["reference_metadata"]["stage"]
