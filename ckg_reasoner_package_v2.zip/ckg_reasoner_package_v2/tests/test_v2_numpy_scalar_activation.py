import numpy as np
from ckg_reasoner.legacy_activation import construct_patient_with_reference_scores


def test_numpy_integer_composite_component_has_processing_type():
    ref = {
        "X_laboratory": {
            "feature_name": "X", "name": "X", "stage": "laboratory",
            "profile": {"value": 1},
            "diagnostic_role": "Major", "importance": "Critical",
            "support": "Strong", "contradiction": "Strong",
            "expected_frequency": "Common"
        }
    }
    out = construct_patient_with_reference_scores({"X_value": np.int64(1)}, ref)
    component = out["X_laboratory"]["components"]["value"]
    assert component["processing_type"] == "NUMERIC"
    assert isinstance(component["patient_score"], (int, float, np.integer, np.floating))
