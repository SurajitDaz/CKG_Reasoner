import pandas as pd
from ckg_reasoner import CKGModel


def _cohort(n_each=12):
    low={
        "NS1":0,"IGG":0,"IGM":0,"FEV_dura_dy":1,"FEV_temperature_c":36.8,
        "MTP_platelet_count:":260000,"LEU_wbc":8200,"ART_severity":"None",
        "HDH":0,"ROP":0,"MYA":0,"RSH":0,"COU":1,"MAL":0,"Dengue_Outcome":0,
    }
    mid1={
        "NS1":0,"IGG":0,"IGM":1,"FEV_dura_dy":3,"FEV_temperature_c":38.0,
        "MTP_platelet_count:":150000,"LEU_wbc":5200,"ART_severity":"Moderate",
        "HDH":1,"ROP":0,"MYA":1,"RSH":0,"COU":0,"MAL":1,"Dengue_Outcome":1,
    }
    mid2={
        "NS1":0,"IGG":1,"IGM":1,"FEV_dura_dy":4,"FEV_temperature_c":38.8,
        "MTP_platelet_count:":105000,"LEU_wbc":4100,"ART_severity":"Moderate",
        "HDH":1,"ROP":1,"MYA":1,"RSH":0,"COU":0,"MAL":1,"Dengue_Outcome":1,
    }
    high={
        "NS1":1,"IGG":1,"IGM":1,"FEV_dura_dy":6,"FEV_temperature_c":40.0,
        "MTP_platelet_count:":55000,"LEU_wbc":2800,"ART_severity":"Severe",
        "HDH":1,"ROP":1,"MYA":1,"RSH":1,"COU":0,"MAL":1,"Dengue_Outcome":1,
    }
    pats=[low,mid1,mid2,high]
    rows=[]
    for j,p in enumerate(pats):
        for i in range(n_each):
            r=p.copy()
            # small deterministic perturbations create non-degenerate score groups
            r["FEV_temperature_c"] += (i % 3) * 0.05
            r["FEV_dura_dy"] += (i % 2)
            rows.append(r)
    return pd.DataFrame(rows)


def test_gaussian_mahalanobis_hard_and_output(tmp_path):
    m=CKGModel().hmap(_cohort(), interactive=False).graphfit(strategy="exhaustive")

    g=m.tag("Dengue", method="gaussian", min_components=3, max_components=6)
    assert set(g["Predicted_Result"]).issubset({"positive","negative","indeterminate"})
    assert m.gaussian_metadata_["selected_k"] >= 3
    assert "BIC" in g.iloc[0]["Reason"]

    h=m.tag("Dengue", method="hard")
    assert set(h["Predicted_Result"]).issubset({"positive","negative","indeterminate"})
    assert "hard-assignment" in h.iloc[0]["Reason"]

    ma=m.tag("Dengue", method="mahalanobis", min_clusters=3, max_clusters=6)
    assert set(ma["Predicted_Result"]).issubset({"positive","negative","indeterminate"})
    assert m.mahalanobis_metadata_["selected_k"] >= 3
    assert "Mahalanobis-type" in ma.iloc[0]["Reason"]

    for method in ["hard","gaussian","mahalanobis"]:
        ev=m.evalute_tag("Dengue_Outcome",positive_disease="Dengue",positive_label=1,method=method,
                         min_components=3,max_components=6,min_clusters=3,max_clusters=6)
        assert "coverage" in ev and "n_indeterminate" in ev
        assert ev["tag_method"] == method

    p=tmp_path/"gaussian_output.xlsx"
    m.output(p, positive_disease="Dengue", method="gaussian", min_components=3,max_components=6)
    out=pd.read_excel(p)
    assert list(out.columns)[-2:] == ["Predicted_Result","Reason"]
    assert out["Reason"].isna().all()  # v0.7.2: blank until FOL/explanation executes


def test_ground_truth_not_required_for_separation():
    df=_cohort().drop(columns=["Dengue_Outcome"])
    m=CKGModel().hmap(df,interactive=False,disease_hint="Dengue").graphfit(strategy="exhaustive")
    assert not m.tag("Dengue",method="gaussian",min_components=3,max_components=6).empty
    assert not m.tag("Dengue",method="mahalanobis",min_clusters=3,max_clusters=6).empty
