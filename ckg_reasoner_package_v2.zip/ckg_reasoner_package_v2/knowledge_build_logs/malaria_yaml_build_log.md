# Malaria YAML build log — v0.9.3

## Sources inspected
- M1 Bangladesh malaria dataset (2,190 records): Hb, WBC, neutrophils, lymphocytes, eosinophils, PCV/HCT, MCH, MCHC, RDW, platelet count.
- M2 Malaria Disease and Grading System dataset (2,122 records): laboratory diagnosis/RDT, symptoms, complicated/uncomplicated diagnosis and outcome interpretation.
- M3 Hong Kong malaria study (77 records, 118 fields): temperature, Hb, WBC, platelets, bilirubin, ALT, creatinine, urea, lactate, parasitaemia and clinical data.
- M4 Sierra Leone hospitalized malaria dataset (149 records): temperature, Hb, WBC, neutrophils, lymphocytes, PCV, malaria RDT/film and clinical manifestations.

## Structural correction
The prior YAML contained the key `HGB` twice. Standard YAML loading silently retained only the second definition. v0.9.3 replaces the duplicate with one `HGB` feature containing the decreased-Hb trend and a separate severe-threshold metadata field (`max: 8.0`).

## Changes
- Added non-inference `dataset_evidence` metadata.
- Embedded canonical unit + normal-range metadata for supported continuous laboratory components.
- Retained existing clinical evidence weights rather than estimating them from cohort labels.

## Compatibility
- Existing feature codes used by mapping/scoring are preserved.
- The duplicate-key defect is removed.
- Legacy hard-coded ranges remain fallback only.

> **Current v2 clustering state:** standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`; `R(D_j)` is separate from clustering. This note does not rewrite the historical changes documented above.
