# Influenza YAML build log — v0.9.3

## Sources inspected
- I1 Thailand influenza-like illness cohort (4,569 records): PCR confirmation, fever, cough, sore throat, breathing difficulty, headache, malaise, runny nose, generalized aches, chills, diarrhea, pharyngeal/tympanic findings, rapid influenza test.
- X2 literature-derived synthetic INFLUENZA sheet (10,741 records): encoded fever, headache, myalgia, cough, fatigue, chills, diarrhea, nausea/vomiting and other manifestations.

## Changes
- Added non-inference `dataset_evidence` metadata to `influenza_laboratory.yaml`.
- Embedded canonical unit + normal-range metadata for supported continuous laboratory components.
- Preserved the existing I1-compatible PCR and rapid-antigen component names and mappings.
- Did not estimate clinical evidence weights from outcome labels.

## Compatibility
- Existing feature codes and I1 mapping remain unchanged.
- Legacy hard-coded ranges remain fallback only.

> **Current v2 clustering state:** standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`; `R(D_j)` is separate from clustering. This note does not rewrite the historical changes documented above.
