# Reference semantics migration log — v0.9.5

Requested invariant:
1. `DReference` means a disease-favouring numerical criterion/range.
2. `NReference` means a normal physiological range.
3. Any profile component that did not explicitly contain a reference field is not relabelled or reinterpreted.

Migration performed across all bundled Dengue, Malaria, and Influenza YAML files. Only files containing legacy reference keys required textual changes. Fever profile ranges were verified unchanged.

> **Current v2 clustering state:** standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`; `R(D_j)` is separate from clustering. This note does not rewrite the historical changes documented above.
