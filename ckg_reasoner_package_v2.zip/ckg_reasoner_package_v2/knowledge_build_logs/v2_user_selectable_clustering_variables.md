# v2 user-selectable K-means/GMM clustering variables

K-means and Gaussian-mixture clustering now accept an optional `variables` argument selecting any non-empty subset of the four active post-KG S0 coordinates:

- `P_evidence`
- `r`
- `c`
- `Confidence_Score`

`variables=None` preserves the existing four-dimensional behavior. The maximum number of clustering variables is therefore 4. Raw patient variables, ground-truth outcomes, and the disease-ranking score `R(D_j)` remain excluded. Variable selection changes clustering geometry only; the established evidence/similarity ordering used to map discovered groups to negative/intermediate/positive semantics is retained.

Examples:

```python
model.kmeans(variables=["P_evidence", "r", "c"])
model.gaussian(variables=["r", "c"])

model.partition(KMeansPartition(variables=["P_evidence", "Confidence_Score"]), "Dengue")
model.partition(GaussianPartition(variables=["P_evidence", "r", "c"]), "Dengue")
```
