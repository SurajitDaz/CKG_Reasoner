# Dengue YAML build log — v0.9.3

## Sources inspected
- D3 Structured Clinical and Hematological Dataset (1,018 records): platelet count, WBC, fever, fever duration, headache, muscle pain, rash, vomiting.
- D4 Dengue Fever Hematological Dataset (1,523 records): Hb, differential counts, RBC, HCT, MCV/MCH/MCHC/RDW, platelet count, MPV/PDW/PCT, WBC.
- D5 Integrated Dengue Prediction Dataset (1,500 records): NS1, IgG, IgM, platelet count, temperature plus contextual variables.
- D7 Kaggle Dengue Detection Dataset (989 records): Hb, WBC, RBC, platelet count, PDW.
- X2 literature-derived synthetic DENGUE sheet (22,379 records): encoded clinical manifestations and hematological indicators.

## Changes
- Added non-inference `dataset_evidence` metadata to `dengue_laboratory.yaml`.
- Embedded canonical unit + normal-range metadata for supported continuous laboratory components so activation can read the YAML directly.
- Kept existing diagnostic-role/importance/support/contradiction semantics; no outcome-derived fitting was performed.
- Unit normalization remains upstream of component activation.

## Compatibility
- Existing feature codes are unchanged.
- Existing mapping aliases remain valid.
- Legacy hard-coded ranges remain as fallback only.

> **Current v2 clustering state:** standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`; `R(D_j)` is separate from clustering. This note does not rewrite the historical changes documented above.
