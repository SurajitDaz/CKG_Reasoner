# v0.9.3 disease-YAML build logs

These logs document the dataset-derived interoperability changes made on 2026-09-19.
Dataset contents were used to identify available components, headings, units, and representation needs. They were **not** used to fit diagnostic-role, importance, support, or contradiction weights. Existing clinical knowledge attributes were retained unless a structural defect was corrected and logged.

Files:
- `dengue_yaml_build_log.md`
- `malaria_yaml_build_log.md`
- `influenza_yaml_build_log.md`
## Current v2 clustering state
Historical logs below intentionally retain the equations used by their named releases. For the active v2 implementation, clustering uses standardized four-dimensional `S0 = [P_evidence, r, c, Confidence_Score]`; disease-ranking `R(D_j)` is separate and is not a clustering coordinate. See `v2_confidence_s0_and_bounded_retirement.md`.

