# Schema and composite-condition migration log — v0.9.7

Scope: Dengue, Malaria and Influenza laboratory YAML files.

Rules:
1. `processing` is executable (unit, value type, normalization policy, activation function).
2. `metadata` is non-executable maintenance information (source, notes, rationale, review information).
3. `condition` supports recursive `AND`/`OR`.
4. No condition is invented when the knowledge file did not specify one; legacy behaviour is retained.
5. Dengue LEU uses the user-specified `DReference OR trend` alternative.
6. Fever and other profile ranges without a reference key retain their existing semantics.

> **Current v2 clustering state:** standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`; `R(D_j)` is separate from clustering. This note does not rewrite the historical changes documented above.
