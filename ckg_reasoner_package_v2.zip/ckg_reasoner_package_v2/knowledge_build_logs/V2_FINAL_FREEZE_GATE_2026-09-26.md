# CKG Reasoner v2 — Final Freeze Gate (2026-09-26)

- Exact release version: `2`.
- Clean source compilation: PASS.
- Complete regression suite, executed in four deterministic chunks: 105 passed, 0 failed.
- Post-cleanup focused clustering/help/version regression: 13 passed, 0 failed.
- K-means, GMM, and Mahalanobis support `variables=`.
- `variables=None` uses all four eligible post-KG coordinates: `P_evidence`, `r`, `c`, `Confidence_Score`.
- Selectable dimensionality: 1–4 variables.
- Ranking score `R(D_j)` and outcome labels are excluded from clustering geometry.
- K-means diagnostics expose elbow, silhouette, and combined best-k outputs.
- Help surface: `model.help()` and `model.help("clustering")`.
- Release debris/caches removed before packaging.
