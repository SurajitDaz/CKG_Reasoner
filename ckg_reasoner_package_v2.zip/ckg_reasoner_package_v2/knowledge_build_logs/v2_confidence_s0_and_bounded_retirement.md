# v2 — Confidence-aware S0 and bounded-decision retirement

## Active inference change
- The post-KG unsupervised representation is now four-dimensional:
  `S0(D_j) = [P_evidence(D_j), r_j, c_j, Confidence_Score(D_j)]^T`.
- `Confidence_Score` is the existing outcome-label-independent evidence-completeness score from the confidence audit.
- K-means, Gaussian-mixture, and Mahalanobis partitioning use the standardized 4-D S0 representation.
- The disease-ranking score `R(D_j)` and candidate hard-rule score are unchanged and are not clustering coordinates.
- Cluster ordering remains based on the original evidence/similarity ordering quantity (`P_evidence + r + c`); confidence affects geometry, not the semantic direction used to label low/high partitions.

## Bounded-support status
The lower/upper support interval and fixed 0.20/0.80 selective-decision thresholds are no longer part of the recommended active pipeline. The legacy bounded-support API is retained temporarily for backward compatibility and reproducibility of older notebooks, but it is not used by graph fitting, disease ranking, confidence calculation, or K-means/GMM/Mahalanobis partitioning.

## Confidence semantics
Confidence remains an evidence-completeness/audit quantity. Adding it to S0 does not make it a calibrated disease probability and does not change disease ranking. It can, however, change unsupervised cluster geometry and therefore all partition-derived metrics must be rerun.
