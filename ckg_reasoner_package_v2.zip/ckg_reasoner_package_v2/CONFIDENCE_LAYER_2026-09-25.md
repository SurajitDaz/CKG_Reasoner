# Diagnostic confidence / evidence-completeness layer

This revision adds an outcome-label-independent confidence/evidence-completeness layer. Confidence does not change disease ranking or feature-level evidence accumulation, but the current v2 clustering path includes `Confidence_Score` as the fourth post-KG coordinate.

- Missing values remain missing; they are never imputed as zero evidence.
- Existing `P_evidence`, `r`, `c`, disease-ranking `R`, and hard-rule scoring remain unchanged. `S0` is expanded from three to four coordinates by appending `Confidence_Score`, so unsupervised cluster geometry can change.
- `Evidence_Coverage` / `Confidence_Score` is the fraction of canonical diagnostic evidence weight actually observed, including partial component availability.
- Positive diagnostic roles use the reasoner's existing canonical positive contribution `f(1)*max(g,0)*I*S` as the weight.
- Missing Pathognomonic, Hallmark, Major, and Exclusionary evidence is explicitly reported.
- `Confidence_Level` is an interpretive evidence-completeness category: High >= 0.80, Moderate >= 0.50, otherwise Low. It is not a calibrated probability.
- `model.output()` keeps the same public call and appends confidence columns plus `Confidence_Audit` and `Explanation_Trace` sheets.
- `Confidence_Score` **is an input to K-means, GMM, and Mahalanobis partitioning** through standardized 4-D `S0 = [P_evidence, r, c, Confidence_Score]`. It is not an input to disease ranking `R(D_j)` and is not a calibrated disease probability.

## Cohort-evaluable denominator
For `model.output()`, patient evidence coverage is calculated over EFNs that are evaluable in the cohort (observed for at least one record), rather than every stage-specific EFN in the complete disease ontology. This measures patient-level missingness without mechanically penalizing a cohort for ontology concepts that its schema never collects. The full knowledge-graph coverage question remains a separate mapping/provenance issue.
