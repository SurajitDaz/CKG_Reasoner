import pandas as pd
from ckg_reasoner import CKGModel

DATA = "patients.xlsx"
TARGET = "Dengue_Outcome"
DISEASE = "Dengue"

df = pd.read_excel(DATA)
model = CKGModel()
model.hmap(df, interactive=False)
model.graphfit(strategy="exhaustive")

# Automatic exploratory K-means (parallel analysis only)
print("Automatic K:", model.optimal_k_)
model.kmeans(show=True)

# Three selectable post-inference tagging methods
hard = model.tag(DISEASE, method="hard")
gaussian = model.tag(DISEASE, method="gaussian")
mahal = model.tag(DISEASE, method="mahalanobis")

# Patient-level FOL by stable primary key
row = model.row_from_id(1)
print(model.explain(DISEASE, row=row, format="fol"))

# Selective evaluation: indeterminate rows are excluded, coverage is reported
print(model.evalute_tag(TARGET, positive_disease=DISEASE, positive_label=1, method="hard"))
print(model.evalute_tag(TARGET, positive_disease=DISEASE, positive_label=1, method="gaussian"))
print(model.evalute_tag(TARGET, positive_disease=DISEASE, positive_label=1, method="mahalanobis"))

# Final output: choose exactly one method
model.output("patients_CKG_gaussian.xlsx", positive_disease=DISEASE, method="gaussian")
