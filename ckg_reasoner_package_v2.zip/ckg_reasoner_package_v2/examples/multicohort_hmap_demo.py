import pandas as pd
from ckg_reasoner import CKGModel

# Point this at any of the four selected study datasets.
path = "YOUR_DATASET.csv"
df = pd.read_csv(path)
model = CKGModel().hmap(df, interactive=False)
print("Detected:", model.detected_schema_)
print(model.hmap_report().to_string(index=False))
model.graphfit()
print(model.results_.head())
