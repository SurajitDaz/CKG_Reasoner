import pandas as pd
from ckg_reasoner import CKGModel

DATA = "patients.xlsx"  # CSV also supported
TARGET = "Dengue_Outcome"
DISEASE = "Dengue"

model = CKGModel()
model.hmap(DATA, interactive=False)
model.graphfit(strategy="exhaustive")  # auto K-means is computed here

print(model.kmeans_summary_)
model.kmeans(show=True, y_true=TARGET)

record_id = model.df_["id"].iloc[0]
row = model.row_from_id(record_id)
print(model.explain(DISEASE, row=row, format="fol"))

model.output("patients_CKG_output.xlsx", positive_disease=DISEASE)
print(model.evaluate(y_true=TARGET, positive_disease=DISEASE, positive_label=1))
print(model.evalute_tag(y_true=TARGET, positive_disease=DISEASE, positive_label=1))
