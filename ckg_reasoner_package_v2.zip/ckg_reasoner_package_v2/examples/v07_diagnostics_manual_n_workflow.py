"""CKG Reasoner v0.7.0: diagnostics -> manual n -> fit -> visualize -> evaluate -> output."""
import pandas as pd
from ckg_reasoner import CKGModel, KMeansPartition, GaussianPartition, MahalanobisPartition

DATA = "cohort.xlsx"  # change this
TARGET_DISEASE = "Dengue"
OUTCOME = "Dengue_Outcome"

df = pd.read_excel(DATA)
model = CKGModel().hmap(df, interactive=False, disease_hint=TARGET_DISEASE).graphfit(strategy="exhaustive")

# 1) Automatic diagnostics (score vectors only)
kd = model.diagnostics("kmeans", TARGET_DISEASE, min_clusters=2, max_clusters=10, show=True)
gd = model.diagnostics("gaussian", TARGET_DISEASE, min_components=2, max_components=10, show=True)
md = model.diagnostics("mahalanobis", TARGET_DISEASE, min_clusters=2, max_clusters=10, show=True)
print("Advisory counts:", kd.attrs["recommended_n"], gd.attrs["recommended_n"], md.attrs["recommended_n"])

# 2) USER manually chooses n after inspecting plots
N_KMEANS = 4
N_GAUSSIAN = 4
N_MAHALANOBIS = 4

km = model.partition(KMeansPartition(n_clusters=N_KMEANS, min_clusters=2, max_clusters=10), TARGET_DISEASE, show=False)
gm = model.partition(GaussianPartition(n_components=N_GAUSSIAN, min_components=2, max_components=10), TARGET_DISEASE, show=False)
ma = model.partition(MahalanobisPartition(n_clusters=N_MAHALANOBIS, min_clusters=2, max_clusters=10), TARGET_DISEASE, show=False)

# 3) Full post-fit visualization family; y_true is never used for clustering
for method in (km, gm, ma):
    method.visualize(y_true=model.df_[OUTCOME])
    print(method.name, model.evaluate(OUTCOME, positive_disease=TARGET_DISEASE, positive_label=1, method=method))
    print(method.name, model.evaluate_tag(OUTCOME, positive_disease=TARGET_DISEASE, positive_label=1, method=method))
    model.output(f"CKG_{method.name}_output.xlsx", positive_disease=TARGET_DISEASE, method=method)
