import pandas as pd
from ckg_reasoner import (
    CKGModel, HardAssignment, KMeansPartition,
    GaussianPartition, MahalanobisPartition,
)

DATA = "patients.xlsx"
TARGET = "Dengue_Outcome"
DISEASE = "Dengue"
POSITIVE_LABEL = 1

df = pd.read_excel(DATA)
model = CKGModel().hmap(df, interactive=False).graphfit(strategy="exhaustive")

methods = [
    HardAssignment(),
    KMeansPartition(),
    GaussianPartition(),
    MahalanobisPartition(),
]

for method in methods:
    fitted = model.partition(method, positive_disease=DISEASE, show=True)
    print("\n", fitted)
    print("Score dimensions:", fitted.score_dimensions_)
    print("All-record evaluation:", model.evaluate(TARGET, positive_disease=DISEASE, positive_label=POSITIVE_LABEL, method=fitted))
    print("Selective evaluation:", model.evaluate_tag(TARGET, positive_disease=DISEASE, positive_label=POSITIVE_LABEL, method=fitted))
    model.output(f"CKG_{fitted.name}_output.xlsx", positive_disease=DISEASE, method=fitted)
