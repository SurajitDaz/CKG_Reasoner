import pandas as pd
from ckg_reasoner import CKGModel

DATA = "/content/drive/MyDrive/CKG/Data/5_kaggle_bangladesh_Dengue.csv"
df = pd.read_csv(DATA)

model = CKGModel()
model.hmap(df)
model.graphfit()
model.graph.show()

print(model.Continuous_reasoning("Dengue", row=0))
print(model.Deterministic_reasoning("Dengue", row=0))
print(model.Uncertainty("Dengue"))
print(model.evaluate("Dengue_Outcome", positive_disease="Dengue", positive_label=1))

# --- v0.2 formal uncertainty and explanation layer ---
# Patient-specific bounded support. Missing EFNs remain unresolved rather than negative.
print(model.bounded_support("Dengue", row=0))
print(model.Selective_decision("Dengue", row=0))

# FOL-compatible explanation facts and grounded deterministic report.
print(model.explain("Dengue", row=0, format="fol"))
print(model.explainable_layer("Dengue", row=0, format="report"))
print(model.verify_explanation("Dengue", row=0))
