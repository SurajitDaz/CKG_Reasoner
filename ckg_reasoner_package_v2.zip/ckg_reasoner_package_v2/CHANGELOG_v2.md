# CKG Reasoner v2 (2.0.0)

Version 2 release.

- IGG and IGM are no longer excluded from patient activation.
- Legacy `default × actual_patient_value` activation was removed. `default` features now use an explicit patient-reference activation; binary 1/0 inputs represent observed positivity/absence, while numeric/categorical inputs are matched against profile/reference values.
- Repeated EFN codes are retained as independent stage-specific nodes keyed by their full reference key (for example `VOM_manifestation` and `VOM_progression`).
- **Superseded in the 2026-09-25 v2 update:** disease clustering now uses the four-coordinate representation `[P_evidence, r_j, c_j, Confidence_Score]`; the earlier v1.0.9 three-coordinate representation is retained only in historical logs.
- Disease ranking uses the fixed equal-weight additive score `R=(clip(P_evidence,0,1)+r_j+c_j)/3`; it is not used as a clustering coordinate.
- Added PEP 517/621 installation metadata (`pyproject.toml`).
- Added regression tests for IGG/IGM activation, zero-default activation, and stage-specific duplicate EFNs.

Historical pre-confidence validation: 82 tests passed at that revision. This count is not the validation status of the current confidence-aware v2 code.

## 2 (2026-09-25)
- Expanded post-KG S0 from 3-D to 4-D: `[P_evidence, r, c, Confidence_Score]`.
- Confidence Score remains outcome-label-independent and does not enter disease ranking `R(D_j)`.
- Updated K-means, GMM, Mahalanobis partitioning and diagnostics to use standardized 4-D S0.
- Bounded-support 0.20/0.80 selective-decision mechanism retired from the recommended active pipeline; legacy API retained only for backward compatibility.
- Added regression tests for confidence-aware S0. Final freeze verification: package version is `2`; version assertions and clustering-functional tests pass in the current freeze suite.
